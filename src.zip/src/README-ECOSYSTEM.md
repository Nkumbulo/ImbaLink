# ImbaLink ecosystem expansion

The project is now structured around three connected user experiences:

- Tenant marketplace: Home, Search, Saved, Messages, Profile
- Landlord portal: `pages/LandlordDashboardPage.jsx`
- Contractor directory: `pages/ContractorsPage.jsx`

## New folders/files

- `src/components/landlord/ListingForm.jsx`
- `src/pages/LandlordDashboardPage.jsx`
- `src/pages/ContractorsPage.jsx`
- `src/data/contractors.json`

## Data behaviour

Landlord-created listings are stored in browser `localStorage` under
`imbalink_landlord_listings_v1`, so the UI works without a backend.

Contractors are loaded from `src/data/contractors.json`.

## Next backend step

For production, replace the localStorage landlord state and static contractor JSON
with authenticated API/database tables:

- users
- landlord_profiles
- tenant_profiles
- contractor_profiles
- properties
- property_images
- viewing_requests
- conversations/messages
- contractor_quotes/jobs
- verification_records
- payments

The current UI is deliberately ready for that migration: the database access is
centralised in `src/services/database.js`.


## Database stability update

The app now uses a versioned normalized client database with safe migration from v1, bounded message/listing storage, defensive parsing, pagination guards, and separate property/contractor likes. See `services/DATABASE-SCHEMA.md`.


## Data persistence

The application loads `src/data/properties.json` using the `properties` array in that file, so the 200 seed properties are available to the property feed. User-generated records are persisted through `src/services/database.js`: landlord registrations, contractor registrations, landlord listings, likes, saves, viewing requests and messages are stored with stable IDs and user ownership.

The package does not currently contain a remote database URL/key or backend service. The repository layer is intentionally isolated so a PostgreSQL/Supabase/API implementation can replace the local persistence without rewriting the UI.
