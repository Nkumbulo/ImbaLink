# ImbaLink Database Schema v4

The app now uses a normalized repository layer. In the current package the repository persists data locally in browser storage, while keeping database-style records and IDs so a server repository can be attached without changing the UI. No remote database connection or credentials are present in this package.

## Core tables

- `users` — account identity and profile.
- `properties` — rental listings / feed posts.
- `property_likes` — one row per user/property like.
- `property_saves` — one row per user/property save.
- `property_viewing_requests` — viewing requests and statuses.
- `messages` — property conversations, capped client-side at 100 recent messages.
- `contractors` — verified/public contractor directory records.
- `contractor_registrations` — contractor applications and verification data.
- `contractor_likes` — one row per user/contractor like.
- `quote_requests` — tenant/customer requests sent to contractors.
- `landlord_registrations` — landlord identity/authority applications.
- `landlord_listings` — landlord-created listings, including verification state.
- `landlord_registrations` — one registration per user, updated rather than duplicated.

## Contractor registration data

A contractor application stores: full name, business name, phone, email, business address, primary trade, services, service areas, experience, ID type/number, business registration number, licence number, tax/ZIMRA number, description, emergency-service availability, quote availability, terms acceptance, verification status, timestamps and a generated application ID.

## Landlord registration data

A landlord registration stores: legal name, phone, email, landlord type, ID type/number, address, company/agency name and registration number where relevant, legal-authority confirmation, verification status, timestamps and a generated registration ID.

## Property listing data

A listing stores: title, suburb, street/address, city, property type, rent, deposit, bedrooms, bathrooms, bathroom type, furnished state, availability, lease term, description, amenities, rules, electricity, water, security, parking, ownership/authority type and reference, landlord identity, verification state and timestamps.

## Verification rule

Registrations and listings are **pending by default**. The client never automatically grants a verified badge from a new registration. A future admin/moderation service should change `verificationStatus` / `verification` to `verified` after reviewing submitted evidence.

## Crash protection

All persistence reads are JSON-safe, invalid records are normalized, localStorage errors are caught, collection sizes are bounded, and schema migrations preserve v2 user data when upgrading to v3.
