/**
 * ImbaLink client database
 *
 * Normalized, Instagram-style model:
 * - users
 * - properties (posts)
 * - property_likes (one record per user + property)
 * - property_saves
 * - contractor_likes
 * - messages
 * - viewing_requests
 *
 * The current app has no server/database connection, so this repository uses
 * localStorage safely. The API is intentionally shaped like a real repository
 * so it can later be swapped for Supabase/Postgres/Firebase without changing
 * the UI.
 */

const STORAGE_KEY = "imbalink_user_state_v2";
const LEGACY_STORAGE_KEY = "imbalink_user_state_v1";
const LANDLORD_KEY = "rooma_landlord_listings_v2";
const LEGACY_LANDLORD_KEY = "rooma_landlord_listings_v1";
const DATA_URL = "/data/properties.json";
const CONTRACTORS_URL = "/data/contractors.json";
const SCHEMA_VERSION = 4;
const CONTRACTOR_REG_KEY = "imbalink_contractor_registrations_v1";
const LANDLORD_REG_KEY = "imbalink_landlord_registrations_v1";
const AGENT_REG_KEY = "imbalink_agent_registrations_v1";
const COMPANY_REG_KEY = "imbalink_company_registrations_v1";
const REQUESTS_KEY = "imbalink_quote_requests_v1";
const PROFILE_KEY = "imbalink_profile_v1";

let ALL_DATA = null;
let CONTRACTORS = null;

// ─── Active user scoping ────────────────────────────────────────────
// This app has no server, so per-account isolation is enforced here:
// every call that reads/writes a signed-in person's saved & liked
// properties, chat threads, and viewing requests is namespaced under
// their account id, instead of one shared blob every account read
// from — which used to make a brand new sign-in appear to inherit the
// previous person's data. AuthContext calls setActiveUser() whenever
// the session changes.
let ACTIVE_USER_ID = null;

function setActiveUser(userId) {
  ACTIVE_USER_ID = userId ? String(userId) : null;
}

function scopedStorageKey(baseKey) {
  return ACTIVE_USER_ID ? `${baseKey}::${ACTIVE_USER_ID}` : baseKey;
}

const DEFAULT_STATE = () => ({
  version: SCHEMA_VERSION,
  user: { id: "local-user", firstName: "", surname: "", phone: "", name: "" },
  propertyLikes: {},       // { [propertyId]: { createdAt } }
  propertySaves: {},       // { [propertyId]: { createdAt } }
  contractorLikes: {},     // { [contractorId]: { createdAt } }
  messages: {},             // { [propertyId]: Message[] }
  viewingRequests: {},      // { [propertyId]: { createdAt, status } }
  contractorRegistrations: {},
  landlordRegistration: null,
  quoteRequests: {},
  landlordListings: {},
});

function isObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function safeParse(raw, fallback) {
  if (!raw) return fallback;
  try {
    const value = JSON.parse(raw);
    return value;
  } catch (error) {
    // Keep the app alive when old/corrupt browser data is the cause of a crash.
    return fallback;
  }
}

function now() {
  return Date.now();
}

function toId(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : String(value);
}

function normalizeMessage(message) {
  if (!isObject(message)) return null;
  const text = typeof message.text === "string" ? message.text.trim().slice(0, 2000) : "";
  if (!text) return null;
  return {
    id: message.id || `${Date.now()}-${Math.random().toString(36).slice(2)}`,
    from: message.from === "them" ? "them" : "me",
    text,
    ts: Number.isFinite(Number(message.ts)) ? Number(message.ts) : now(),
  };
}

function migrateState(raw) {
  const base = DEFAULT_STATE();
  if (!isObject(raw)) return base;

  // v2 is already normalized.
  if (Number(raw.version) >= 2 && Number(raw.version) <= SCHEMA_VERSION) {
    base.user = isObject(raw.user) ? { ...base.user, ...raw.user } : base.user;
    if (!base.user.firstName && typeof base.user.name === "string") {
      const parts = base.user.name.trim().split(/\s+/).filter(Boolean);
      base.user.firstName = parts[0] || "";
      base.user.surname = parts.slice(1).join(" ");
    }
    base.propertyLikes = isObject(raw.propertyLikes) ? raw.propertyLikes : {};
    base.propertySaves = isObject(raw.propertySaves) ? raw.propertySaves : {};
    base.contractorLikes = isObject(raw.contractorLikes) ? raw.contractorLikes : {};
    base.viewingRequests = isObject(raw.viewingRequests) ? raw.viewingRequests : {};
    base.messages = isObject(raw.messages) ? raw.messages : {};
    base.contractorRegistrations = isObject(raw.contractorRegistrations) ? raw.contractorRegistrations : {};
    base.landlordRegistration = isObject(raw.landlordRegistration) ? raw.landlordRegistration : null;
    base.quoteRequests = isObject(raw.quoteRequests) ? raw.quoteRequests : {};
    base.landlordListings = isObject(raw.landlordListings) ? raw.landlordListings : {};
    return base;
  }

  // v1 compatibility migration.
  const savedIds = Array.isArray(raw.savedIds) ? raw.savedIds : [];
  const likedIds = Array.isArray(raw.likedIds) ? raw.likedIds : [];

  for (const id of likedIds) {
    const key = String(id);
    base.propertyLikes[key] = { createdAt: now() };
  }
  for (const id of savedIds) {
    const key = String(id);
    base.propertySaves[key] = { createdAt: now() };
  }

  if (isObject(raw.threads)) {
    for (const [propertyId, thread] of Object.entries(raw.threads)) {
      if (!Array.isArray(thread)) continue;
      const messages = thread.map(normalizeMessage).filter(Boolean).slice(-100);
      if (messages.length) base.messages[String(propertyId)] = messages;
    }
  }

  if (isObject(raw.viewingRequested)) {
    for (const [propertyId, requested] of Object.entries(raw.viewingRequested)) {
      if (requested) {
        base.viewingRequests[String(propertyId)] = {
          createdAt: now(),
          status: "requested",
        };
      }
    }
  }

  return base;
}

function readState() {
  try {
    const key = scopedStorageKey(STORAGE_KEY);
    const raw = localStorage.getItem(key);
    if (raw) return migrateState(safeParse(raw, null));

    // Legacy, pre-account-scoping data only applies to the very first
    // profile that ever used this device (no account id to scope by).
    if (!ACTIVE_USER_ID) {
      const legacy = localStorage.getItem(LEGACY_STORAGE_KEY);
      if (legacy) {
        const migrated = migrateState(safeParse(legacy, null));
        writeState(migrated);
        return migrated;
      }
    }
  } catch {
    // localStorage can be disabled, full, or inaccessible. The UI still works in memory.
  }
  return DEFAULT_STATE();
}

function writeState(state) {
  const normalized = migrateState(state);
  try {
    localStorage.setItem(scopedStorageKey(STORAGE_KEY), JSON.stringify(normalized));
    return true;
  } catch {
    // Quota/security errors must never crash the application.
    return false;
  }
}

function updateState(mutator) {
  const state = readState();
  const next = mutator(state) || state;
  writeState(next);
  return next;
}

function applyFilters(data, { city, suburb, type, maxPrice, verifiedOnly, query } = {}) {
  const q = typeof query === "string" ? query.trim().toLowerCase() : "";
  return data.filter((p) => {
    if (!isObject(p)) return false;
    if (city && city !== "All" && p.city !== city) return false;
    if (suburb && suburb !== "All" && p.suburb !== suburb) return false;
    if (type && type !== "All" && p.type !== type) return false;
    if (Number.isFinite(Number(maxPrice)) && Number(p.rent) > Number(maxPrice)) return false;
    if (verifiedOnly && p.verification !== "verified") return false;
    if (q) {
      const haystack = `${p.title || ""} ${p.suburb || ""} ${p.type || ""} ${p.landlord || ""}`.toLowerCase();
      if (!haystack.includes(q)) return false;
    }
    return true;
  });
}

function normalizeProperty(p) {
  if (!isObject(p)) return null;
  const id = p.id ?? p._id;
  if (id == null) return null;
  return {
    ...p,
    id: toId(id),
    title: String(p.title || "Untitled listing"),
    suburb: String(p.suburb || "Unknown"),
    city: String(p.city || "Harare"),
    type: String(p.type || "Property"),
    rent: Number.isFinite(Number(p.rent)) ? Number(p.rent) : 0,
    rooms: Number.isFinite(Number(p.rooms)) ? Number(p.rooms) : 0,
    desc: String(p.desc || ""),
    rules: Array.isArray(p.rules) ? p.rules.filter(Boolean).slice(0, 20) : [],
    grad: Array.isArray(p.grad) && p.grad.length >= 2 ? [String(p.grad[0]), String(p.grad[1])] : ["#6E63B8", "#3E3670"],
    verification: ["verified", "pending", "flagged"].includes(p.verification) ? p.verification : "pending",
  };
}

function normalizeContractor(c) {
  if (!isObject(c)) return null;
  const id = c.id ?? c._id;
  if (id == null) return null;
  return {
    ...c,
    id: toId(id),
    name: String(c.name || "Unknown"),
    business: String(c.business || "Contractor"),
    category: String(c.category || "General"),
    city: String(c.city || "Harare"),
    area: String(c.area || "Unknown"),
    rating: Number.isFinite(Number(c.rating)) ? Number(c.rating) : 0,
    jobs: Number.isFinite(Number(c.jobs)) ? Number(c.jobs) : 0,
    verified: Boolean(c.verified),
    phone: String(c.phone || ""),
    description: String(c.description || ""),
    services: Array.isArray(c.services) ? c.services.filter(Boolean).slice(0, 30) : [],
    areas: Array.isArray(c.areas) ? c.areas.filter(Boolean).slice(0, 30) : [],
    verificationStatus: c.verificationStatus || (c.verified ? "verified" : "pending"),
  };
}

export const db = {
  // Scopes all saved/liked/messages/viewing-request storage to this
  // account. Call with null on sign-out. See ACTIVE_USER_ID above.
  setActiveUser(userId) {
    setActiveUser(userId);
  },

  async _ensureData() {
    if (ALL_DATA) return ALL_DATA;
    try {
      const res = await fetch(DATA_URL).catch(() => null)
      if (!res.ok) throw new Error(`property fetch failed: ${res.status}`);
      const json = await res.json();
      const items = Array.isArray(json) ? json : (Array.isArray(json?.properties) ? json.properties : []);
      ALL_DATA = items.map(normalizeProperty).filter(Boolean);
    } catch {
      try {
        const bundled = await import("../data/properties.json");
        const json = bundled.default || bundled;
        const items = Array.isArray(json) ? json : (Array.isArray(json?.properties) ? json.properties : []);
        ALL_DATA = items.map(normalizeProperty).filter(Boolean);
      } catch {
        ALL_DATA = [];
      }
    }
    return ALL_DATA;
  },

  async getProperties({ page = 1, limit = 10, ...filters } = {}) {
    const all = await this._ensureData();
    const safePage = Math.max(1, Number(page) || 1);
    const safeLimit = Math.min(1000, Math.max(1, Number(limit) || 500));
    const filtered = applyFilters(all, filters);
    const start = (safePage - 1) * safeLimit;
    const chunk = filtered.slice(start, start + safeLimit);

    return {
      data: chunk,
      total: filtered.length,
      page: safePage,
      hasMore: start + safeLimit < filtered.length,
    };
  },

  async getContractors() {
    if (CONTRACTORS) return CONTRACTORS;
    try {
      const res = await fetch(CONTRACTORS_URL).catch(() => null)
      if (!res.ok) throw new Error(`contractor fetch failed: ${res.status}`);
      const json = await res.json();
      CONTRACTORS = Array.isArray(json) ? json.map(normalizeContractor).filter(Boolean) : [];
    } catch {
      try {
        const bundled = await import("../data/contractors.json");
        const json = bundled.default || bundled;
        CONTRACTORS = Array.isArray(json) ? json.map(normalizeContractor).filter(Boolean) : [];
      } catch {
        CONTRACTORS = [];
      }
    }
    return CONTRACTORS;
  },

  async getLandlordListings(userId = null) {
    try {
      const raw = localStorage.getItem(LANDLORD_KEY) || localStorage.getItem(LEGACY_LANDLORD_KEY);
      const parsed = safeParse(raw, []);
      const list = Array.isArray(parsed) ? parsed.map(normalizeProperty).filter(Boolean) : [];
      return userId ? list.filter((p) => String(p.userId || "") === String(userId)) : list;
    } catch {
      return [];
    }
  },

  async saveLandlordListings(listings) {
    const safeListings = Array.isArray(listings)
      ? listings.map(normalizeProperty).filter(Boolean).slice(0, 500)
      : [];
    try {
      localStorage.setItem(LANDLORD_KEY, JSON.stringify(safeListings));
      return true;
    } catch {
      return false;
    }
  },

  async createLandlordListing(input) {
    const id = `land-list-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const record = normalizeProperty({
      ...input,
      id,
      verification: input?.landlordVerified ? "verified" : (input?.verification || "pending"),
      landlordVerified: Boolean(input?.landlordVerified),
      createdAt: now(),
      updatedAt: now(),
    });
    const existing = await this.getLandlordListings();
    await this.saveLandlordListings([record, ...existing.filter((p) => String(p.id) !== String(record.id))]);
    return record;
  },

  async getPropertyById(id) {
    const all = await this._ensureData();
    return all.find((p) => String(p.id) === String(id)) || null;
  },

  async getUserProfile() {
    try {
      const raw = localStorage.getItem(PROFILE_KEY);
      const profile = safeParse(raw, null);
      if (!isObject(profile)) return null;
      return {
        id: String(profile.id || "local-user"),
        firstName: String(profile.firstName || "").trim(),
        surname: String(profile.surname || "").trim(),
        phone: String(profile.phone || "").trim(),
        name: String(profile.name || `${profile.firstName || ""} ${profile.surname || ""}`).trim(),
        createdAt: profile.createdAt || now(),
        updatedAt: profile.updatedAt || now(),
      };
    } catch {
      return null;
    }
  },

  async saveUserProfile(input) {
    const current = await this.getUserProfile();
    const firstName = String(input?.firstName ?? current?.firstName ?? "").trim().slice(0, 80);
    const surname = String(input?.surname ?? current?.surname ?? "").trim().slice(0, 80);
    const phone = String(input?.phone ?? current?.phone ?? "").trim().slice(0, 40);
    const record = {
      id: current?.id || "local-user",
      firstName, surname, phone,
      name: `${firstName} ${surname}`.trim(),
      createdAt: current?.createdAt || now(),
      updatedAt: now(),
    };
    try {
      localStorage.setItem(PROFILE_KEY, JSON.stringify(record));
      // Keep the normalized database state in sync with the profile.
      updateState((state) => { state.user = record; return state; });
      return record;
    } catch {
      return record;
    }
  },

  async getUserState() {
    const state = readState();
    return {
      profile: state.user,
      savedIds: Object.keys(state.propertySaves),
      likedIds: Object.keys(state.propertyLikes),
      contractorLikedIds: Object.keys(state.contractorLikes),
      threads: state.messages,
      viewingRequested: Object.fromEntries(
        Object.entries(state.viewingRequests).map(([id]) => [id, true])
      ),
    };
  },

  async saveUserState(input) {
    // Compatibility API for the existing hook. Values are normalized before writing.
    const current = readState();
    const next = migrateState({
      ...current,
      propertyLikes: Object.fromEntries(
        (Array.isArray(input?.likedIds) ? input.likedIds : []).map((id) => [String(id), { createdAt: now() }])
      ),
      propertySaves: Object.fromEntries(
        (Array.isArray(input?.savedIds) ? input.savedIds : []).map((id) => [String(id), { createdAt: now() }])
      ),
      contractorLikes: Object.fromEntries(
        (Array.isArray(input?.contractorLikedIds) ? input.contractorLikedIds : []).map((id) => [String(id), { createdAt: now() }])
      ),
      messages: isObject(input?.threads) ? input.threads : current.messages,
      viewingRequests: isObject(input?.viewingRequested)
        ? Object.fromEntries(
            Object.entries(input.viewingRequested).filter(([, value]) => value).map(([id]) => [
              String(id),
              { createdAt: now(), status: "requested" },
            ])
          )
        : current.viewingRequests,
    });
    writeState(next);
  },

  async setPropertyLike(propertyId, liked) {
    updateState((state) => {
      const key = String(propertyId);
      if (liked) state.propertyLikes[key] = { createdAt: now() };
      else delete state.propertyLikes[key];
      return state;
    });
  },

  async setPropertySave(propertyId, saved) {
    updateState((state) => {
      const key = String(propertyId);
      if (saved) state.propertySaves[key] = { createdAt: now() };
      else delete state.propertySaves[key];
      return state;
    });
  },

  async setContractorLike(contractorId, liked) {
    updateState((state) => {
      const key = String(contractorId);
      if (liked) state.contractorLikes[key] = { createdAt: now() };
      else delete state.contractorLikes[key];
      return state;
    });
  },

  async addMessage(propertyId, message) {
    const normalized = normalizeMessage(message);
    if (!normalized) return;
    updateState((state) => {
      const key = String(propertyId);
      const existing = Array.isArray(state.messages[key]) ? state.messages[key] : [];
      // Keep only the latest 100 messages per conversation to avoid unbounded localStorage growth.
      state.messages[key] = [...existing, normalized].slice(-100);
      return state;
    });
  },

  async requestViewing(propertyId) {
    updateState((state) => {
      state.viewingRequests[String(propertyId)] = { createdAt: now(), status: "requested" };
      return state;
    });
  },

  async registerContractor(input) {
    const userId = String(input?.userId || "local-user");
    const existing = (await this.getContractorRegistrations()).find((item) => String(item.userId) === userId);
    const id = existing?.id || `ctr-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const record = {
      ...(existing || {}),
      ...input,
      id,
      userId,
      verificationStatus: "verified",
      verified: true,
      createdAt: existing?.createdAt || now(),
      updatedAt: now(),
    };
    try {
      const raw = safeParse(localStorage.getItem(CONTRACTOR_REG_KEY), []);
      const list = Array.isArray(raw) ? raw : [];
      const next = [record, ...list.filter((item) => item.id !== id)];
      localStorage.setItem(CONTRACTOR_REG_KEY, JSON.stringify(next.slice(0, 1000)));
      updateState((state) => { state.contractorRegistrations[id] = record; return state; });
    } catch {}
    CONTRACTORS = null;
    return record;
  },

  async getContractorRegistrations(userId = null) {
    try {
      const raw = safeParse(localStorage.getItem(CONTRACTOR_REG_KEY), []);
      const list = Array.isArray(raw) ? raw : [];
      return userId ? list.filter((item) => String(item.userId) === String(userId)) : list;
    } catch { return []; }
  },

  async registerLandlord(input) {
    const userId = String(input?.userId || "local-user");
    const existing = await this.getLandlordRegistration(userId);
    const record = {
      ...(existing || {}),
      ...input,
      id: existing?.id || `land-${Date.now()}`,
      userId,
      verificationStatus: "verified",
      verified: true,
      createdAt: existing?.createdAt || now(),
      updatedAt: now(),
    };
    try {
      const all = safeParse(localStorage.getItem(LANDLORD_REG_KEY), {});
      const data = isObject(all) ? all : {};
      data[userId] = record;
      localStorage.setItem(LANDLORD_REG_KEY, JSON.stringify(data));
      updateState((state) => { state.landlordRegistration = record; return state; });
    } catch {}
    return record;
  },

  async getLandlordRegistration(userId = "local-user") {
    try {
      const raw = safeParse(localStorage.getItem(LANDLORD_REG_KEY), null);
      if (isObject(raw) && isObject(raw[userId])) return raw[userId];
      // Backward compatibility with the old single-record shape.
      if (isObject(raw) && raw.id && (!raw.userId || String(raw.userId) === String(userId))) return raw;
      return null;
    } catch { return null; }
  },

  async registerAgent(input) {
    const userId = String(input?.userId || "local-user");
    const existing = await this.getAgentRegistration(userId);
    const record = {
      ...(existing || {}),
      ...input,
      id: existing?.id || `agent-${Date.now()}`,
      userId,
      verificationStatus: existing?.verificationStatus || "pending",
      createdAt: existing?.createdAt || now(),
      updatedAt: now(),
    };
    try {
      const all = safeParse(localStorage.getItem(AGENT_REG_KEY), {});
      const data = isObject(all) ? all : {};
      data[userId] = record;
      localStorage.setItem(AGENT_REG_KEY, JSON.stringify(data));
    } catch {}
    return record;
  },

  async getAgentRegistration(userId = "local-user") {
    try {
      const raw = safeParse(localStorage.getItem(AGENT_REG_KEY), null);
      if (isObject(raw) && isObject(raw[userId])) return raw[userId];
      return null;
    } catch { return null; }
  },

  async getAllAgentRegistrations() {
    try {
      const raw = safeParse(localStorage.getItem(AGENT_REG_KEY), {});
      return isObject(raw) ? Object.values(raw) : [];
    } catch { return []; }
  },

  async registerCompany(input) {
    const userId = String(input?.userId || "local-user");
    const existing = await this.getCompanyRegistration(userId);
    const record = {
      ...(existing || {}),
      ...input,
      id: existing?.id || `company-${Date.now()}`,
      userId,
      verificationStatus: existing?.verificationStatus || "pending",
      createdAt: existing?.createdAt || now(),
      updatedAt: now(),
    };
    try {
      const all = safeParse(localStorage.getItem(COMPANY_REG_KEY), {});
      const data = isObject(all) ? all : {};
      data[userId] = record;
      localStorage.setItem(COMPANY_REG_KEY, JSON.stringify(data));
    } catch {}
    return record;
  },

  async getCompanyRegistration(userId = "local-user") {
    try {
      const raw = safeParse(localStorage.getItem(COMPANY_REG_KEY), null);
      if (isObject(raw) && isObject(raw[userId])) return raw[userId];
      return null;
    } catch { return null; }
  },

  async getAllCompanyRegistrations() {
    try {
      const raw = safeParse(localStorage.getItem(COMPANY_REG_KEY), {});
      return isObject(raw) ? Object.values(raw) : [];
    } catch { return []; }
  },

  async createQuoteRequest(input) {
    const id = `quote-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const record = { id, ...input, status: "pending", createdAt: now(), updatedAt: now() };
    try {
      const raw = safeParse(localStorage.getItem(REQUESTS_KEY), {});
      const data = isObject(raw) ? raw : {};
      data[id] = record;
      localStorage.setItem(REQUESTS_KEY, JSON.stringify(data));
    } catch {}
    return record;
  },

  async getQuoteRequests() {
    try { const raw = safeParse(localStorage.getItem(REQUESTS_KEY), {}); return isObject(raw) ? Object.values(raw) : []; } catch { return []; }
  },

  clearCache() {
    ALL_DATA = null;
    CONTRACTORS = null;
  },

  clearUserData() {
    try {
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem(LEGACY_STORAGE_KEY);
      localStorage.removeItem(LANDLORD_KEY);
      localStorage.removeItem(LEGACY_LANDLORD_KEY);
      localStorage.removeItem(CONTRACTOR_REG_KEY);
      localStorage.removeItem(LANDLORD_REG_KEY);
      localStorage.removeItem(REQUESTS_KEY);
      localStorage.removeItem(PROFILE_KEY);
    } catch {}
  },
};
