import { MessagingProvider } from "./messagingProvider";
import { createMessage, createConversation, MESSAGE_STATUS } from "./messageModel";
import { db } from "../database";

/**
 * Local, no-backend implementation of the messaging contract.
 *
 * IMPORTANT: this reuses ImbaLink's existing `db` (services/database.js)
 * for persistence instead of inventing a second, parallel store. `db`
 * already scopes every read/write to the signed-in account (see
 * `db.setActiveUser`) and already persists messages under the exact same
 * `contractor_<id>` / `<propertyId>` thread-key convention this provider
 * uses as `conversationId`. That means:
 *
 *   - Messages sent before this refactor are still there, unchanged.
 *   - Anything else in the app that still writes through `db.addMessage`
 *     (there is exactly one such call site, App.jsx's `sendMessage`) stays
 *     perfectly consistent with what the Messages page shows, because
 *     both read the same underlying store.
 *
 * A real provider (Supabase/Firebase/Twilio/custom API) would instead talk
 * to that backend here — the shape returned to callers stays the same.
 */

const REPLY_TEXT = "Thanks for reaching out — happy to answer any questions before a viewing.";
const MIN_LATENCY = 250;
const MAX_LATENCY = 700;
const FAILURE_RATE = 0.06; // ~6% simulated send failures, so retry/failed-state paths are actually exercised

function randomLatency() {
  return MIN_LATENCY + Math.random() * (MAX_LATENCY - MIN_LATENCY);
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function isOnline() {
  return typeof navigator === "undefined" || navigator.onLine !== false;
}

export class MockMessagingProvider extends MessagingProvider {
  constructor() {
    super();
    this._messageListeners = new Map(); // conversationId -> Set<callback>
    this._conversationListeners = new Set();
    this._connectionListeners = new Set();
    this._connectionState = isOnline() ? "online" : "offline";
    this._contractorsCache = null;

    if (typeof window !== "undefined") {
      window.addEventListener("offline", () => this._setConnectionState("offline"));
      window.addEventListener("online", () => {
        // Real reconnects usually need a beat to re-establish a socket —
        // surface that as a distinct "reconnecting" step instead of
        // snapping straight back to "online".
        this._setConnectionState("reconnecting");
        wait(900).then(() => this._setConnectionState("online"));
      });
    }
  }

  _setConnectionState(state) {
    if (this._connectionState === state) return;
    this._connectionState = state;
    this._connectionListeners.forEach((cb) => {
      try {
        cb(state);
      } catch (err) {
        console.warn("messaging connection listener error:", err);
      }
    });
  }

  subscribeToConnectionState(callback) {
    if (typeof callback !== "function") return () => {};
    this._connectionListeners.add(callback);
    callback(this._connectionState);
    return () => this._connectionListeners.delete(callback);
  }

  subscribeToMessages(conversationId, callback) {
    if (!conversationId || typeof callback !== "function") return () => {};
    const key = String(conversationId);
    if (!this._messageListeners.has(key)) this._messageListeners.set(key, new Set());
    this._messageListeners.get(key).add(callback);
    return () => {
      const set = this._messageListeners.get(key);
      if (!set) return;
      set.delete(callback);
      if (!set.size) this._messageListeners.delete(key);
    };
  }

  subscribeToConversations(_userId, callback) {
    if (typeof callback !== "function") return () => {};
    this._conversationListeners.add(callback);
    return () => this._conversationListeners.delete(callback);
  }

  _emitMessageEvent(conversationId, event) {
    const set = this._messageListeners.get(String(conversationId));
    if (!set) return;
    set.forEach((cb) => {
      try {
        cb(event);
      } catch (err) {
        console.warn("messaging listener error:", err);
      }
    });
  }

  _emitConversationEvent(conversation) {
    this._conversationListeners.forEach((cb) => {
      try {
        cb(conversation);
      } catch (err) {
        console.warn("messaging listener error:", err);
      }
    });
  }

  async _getContractors() {
    if (this._contractorsCache) return this._contractorsCache;
    this._contractorsCache = await db.getContractors().catch(() => []);
    return this._contractorsCache;
  }

  async _resolveProperty(propertyId) {
    const direct = await db.getPropertyById(propertyId).catch(() => null);
    if (direct) return direct;
    const listings = await db.getLandlordListings().catch(() => []);
    return listings.find((p) => String(p?.id) === String(propertyId)) || null;
  }

  async _resolveConversationMeta(conversationId) {
    const key = String(conversationId);
    if (key.startsWith("contractor_")) {
      const contractorId = key.slice("contractor_".length);
      const contractors = await this._getContractors();
      const contractor = contractors.find((c) => String(c?.id) === String(contractorId));
      const businessName = contractor?.business || "Contractor";
      return {
        type: "contractor",
        propertyId: null,
        contractorId,
        otherParticipantId: contractorId,
        displayName: businessName,
        displayAvatar: { kind: "wrench" },
        exists: Boolean(contractor),
      };
    }

    const property = await this._resolveProperty(key);
    const landlordName = property?.landlord || "Landlord";
    const otherParticipantId = property ? String(property.landlordRegistrationId ?? property.id) : key;
    return {
      type: "property",
      propertyId: key,
      contractorId: null,
      otherParticipantId,
      displayName: landlordName,
      displayAvatar: { kind: "avatar", grad: property?.grad || null, letter: (landlordName || "?").charAt(0) },
      exists: Boolean(property),
    };
  }

  _toCanonical(legacyMessage, conversationId, userId, otherParticipantId) {
    if (!legacyMessage || typeof legacyMessage !== "object") return null;
    const text = typeof legacyMessage.text === "string" ? legacyMessage.text.trim() : "";
    if (!text) return null;
    const isMine = legacyMessage.from !== "them";
    return createMessage({
      id: legacyMessage.id,
      conversationId,
      senderId: isMine ? userId : otherParticipantId,
      receiverId: isMine ? otherParticipantId : userId,
      text,
      createdAt: legacyMessage.ts,
      status: legacyMessage.status || MESSAGE_STATUS.SENT,
      clientKey: legacyMessage.clientKey || null,
    });
  }

  async _buildConversation(conversationId, userId, rawMessages) {
    const meta = await this._resolveConversationMeta(conversationId);
    const messages = (Array.isArray(rawMessages) ? rawMessages : [])
      .map((m) => this._toCanonical(m, conversationId, userId, meta.otherParticipantId))
      .filter(Boolean);
    const lastMessage = messages[messages.length - 1] || null;
    const otherMessageCount = messages.filter((m) => m.senderId !== String(userId)).length;

    const conversation = createConversation({
      id: conversationId,
      type: meta.type,
      participants: [userId, meta.otherParticipantId],
      propertyId: meta.propertyId,
      contractorId: meta.contractorId,
      lastMessage,
      lastMessageAt: lastMessage?.createdAt ?? null,
      unreadCount: otherMessageCount,
      displayName: meta.displayName,
      displayAvatar: meta.displayAvatar,
      messages,
    });
    // Internal-only flag so getConversations() can drop orphaned threads
    // (e.g. a contractor/property that no longer exists) exactly like the
    // previous UI silently did.
    conversation._exists = meta.exists;
    return conversation;
  }

  async getConversations(userId) {
    await wait(randomLatency());
    if (!isOnline()) throw new Error("You're offline — check your connection and try again.");

    const state = await db.getUserState().catch(() => ({ threads: {} }));
    const threads = state?.threads || {};
    const entries = await Promise.all(
      Object.entries(threads)
        .filter(([, msgs]) => Array.isArray(msgs) && msgs.length > 0)
        .map(([key, msgs]) => this._buildConversation(key, userId, msgs))
    );

    return entries
      .filter((c) => c._exists !== false)
      .sort((a, b) => (b.lastMessageAt || 0) - (a.lastMessageAt || 0));
  }

  async getConversation(conversationId, userId) {
    await wait(randomLatency() * 0.6);
    if (!isOnline()) throw new Error("You're offline — check your connection and try again.");

    const state = await db.getUserState().catch(() => ({ threads: {} }));
    const rawMessages = (state?.threads || {})[String(conversationId)] || [];
    return this._buildConversation(conversationId, userId, rawMessages);
  }

  async sendMessage(conversationId, message) {
    const userId = message?.senderId != null ? String(message.senderId) : "local-user";
    const text = String(message?.text || "").trim();
    if (!text) throw new Error("Cannot send an empty message.");

    await wait(randomLatency());
    if (!isOnline()) throw new Error("You're offline — the message will send once you're back online.");
    if (Math.random() < FAILURE_RATE) throw new Error("Message failed to send. Please try again.");

    // Assign the id up front so the confirmed message handed back to the
    // caller matches exactly what ends up persisted in storage.
    const legacyMessage = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}-me`, from: "me", text, ts: Date.now() };
    await db.addMessage(conversationId, legacyMessage);

    const meta = await this._resolveConversationMeta(conversationId);
    const confirmed = createMessage({
      id: legacyMessage.id,
      conversationId,
      senderId: userId,
      receiverId: meta.otherParticipantId,
      text,
      createdAt: legacyMessage.ts,
      status: MESSAGE_STATUS.SENT,
      clientKey: message?.clientKey || null,
    });

    this._emitMessageEvent(conversationId, { type: "message", message: confirmed });
    this._notifyConversationUpdated(conversationId, userId);

    // Simulate delivery + (for property threads) a landlord auto-reply —
    // the same behaviour the previous inline App.jsx implementation had.
    wait(600).then(() => {
      this._emitMessageEvent(conversationId, {
        type: "message-updated",
        message: { ...confirmed, status: MESSAGE_STATUS.DELIVERED },
      });
    });

    if (meta.type === "property") {
      wait(1100).then(async () => {
        const reply = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}-them`, from: "them", text: REPLY_TEXT, ts: Date.now() };
        await db.addMessage(conversationId, reply).catch(() => {});
        const canonicalReply = createMessage({
          id: reply.id,
          conversationId,
          senderId: meta.otherParticipantId,
          receiverId: userId,
          text: REPLY_TEXT,
          createdAt: reply.ts,
          status: MESSAGE_STATUS.DELIVERED,
        });
        this._emitMessageEvent(conversationId, { type: "message", message: canonicalReply });
        this._notifyConversationUpdated(conversationId, userId);
      });
    }

    return confirmed;
  }

  async _notifyConversationUpdated(conversationId, userId) {
    const conversation = await this.getConversation(conversationId, userId).catch(() => null);
    if (conversation) this._emitConversationEvent(conversation);
  }

  async markMessageAsRead(_messageId) {
    // The mock's persisted message model has no per-message read flag —
    // read state for it is tracked client-side (see the Messages page's
    // own readCounts). A real provider should persist per-message read
    // receipts here and broadcast the "read" status update.
    return true;
  }

  async markConversationAsRead(_conversationId, _userId) {
    return true;
  }

  async createConversation({ participants = [], propertyId = null } = {}) {
    const conversationId = propertyId != null ? String(propertyId) : `conversation-${Date.now()}`;
    const [userId] = participants;
    return this._buildConversation(conversationId, userId, []);
  }

  async deleteMessage(_messageId) {
    throw new Error("deleteMessage() is not supported by the mock provider yet.");
  }

  async uploadAttachment(file) {
    await wait(randomLatency());
    if (!isOnline()) throw new Error("You're offline — try again once you're reconnected.");
    const url = typeof URL !== "undefined" && file ? URL.createObjectURL(file) : null;
    return {
      url,
      name: file?.name || "attachment",
      size: file?.size || 0,
      type: file?.type || "application/octet-stream",
    };
  }
}

export function createMockMessagingProvider() {
  return new MockMessagingProvider();
}
