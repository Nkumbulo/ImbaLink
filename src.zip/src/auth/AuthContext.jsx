import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { db } from "../services/database";

const SESSION_KEY = "imbalink_session_v1";
const PROFILE_KEY = "imbalink_profile_v1"; // last-active profile (back-compat)
const PROFILES_REGISTRY_KEY = "imbalink_profiles_registry_v1"; // every known phone-based profile on this device
const SESSION_DURATION_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

const AuthContext = createContext(null);

function safeParse(raw, fallback) {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function generateToken() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  return `session-${Date.now()}-${Math.random().toString(36).slice(2, 12)}`;
}

// ─── Profile registry ───────────────────────────────────────────────
// Every distinct phone number that has ever registered on this device
// gets its own entry here, so switching between accounts (or a brand
// new person signing up) never collides with someone else's identity
// or data. PROFILE_KEY only ever mirrors the *currently active* one.
function readProfilesRegistry() {
  const registry = safeParse(localStorage.getItem(PROFILES_REGISTRY_KEY), {});
  return registry && typeof registry === "object" ? registry : {};
}

function writeProfilesRegistry(registry) {
  try {
    localStorage.setItem(PROFILES_REGISTRY_KEY, JSON.stringify(registry));
  } catch {
    // localStorage can be disabled/full — keep the app alive.
  }
}

function upsertProfileInRegistry(profile) {
  const normalizedPhone = String(profile?.phone || "").replace(/\D/g, "");
  if (!normalizedPhone) return;
  const registry = readProfilesRegistry();
  registry[normalizedPhone] = profile;
  writeProfilesRegistry(registry);
}

function findProfileByPhone(phone) {
  const normalizedPhone = String(phone || "").replace(/\D/g, "");
  if (!normalizedPhone) return null;
  return readProfilesRegistry()[normalizedPhone] || null;
}

function findProfileById(id) {
  if (!id) return null;
  const registry = readProfilesRegistry();
  return Object.values(registry).find((p) => String(p.id) === String(id)) || null;
}

// Business account registrations (contractor "pro", landlord, agent, company)
// each carry their own username/password captured during their registration
// wizard. General users never have these — they sign in with their phone.
function matchesCredentials(record, normalizedUsername, password) {
  if (!record || !record.username || !record.password) return false;
  return (
    String(record.username).trim().toLowerCase() === normalizedUsername &&
    String(record.password) === password
  );
}

function displayNameFor(record) {
  return (
    record.fullName ||
    record.repName ||
    record.businessName ||
    record.companyName ||
    record.agencyName ||
    ""
  );
}

function readStoredSession() {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    const session = safeParse(raw, null);

    if (!session || !session.user || !session.expiresAt) return null;

    // Expire old sessions automatically
    if (Date.now() > Number(session.expiresAt)) {
      localStorage.removeItem(SESSION_KEY);
      localStorage.removeItem(PROFILE_KEY);
      return null;
    }

    return session;
  } catch {
    return null;
  }
}

function persistSession(session) {
  if (!session) {
    localStorage.removeItem(SESSION_KEY);
    localStorage.removeItem(PROFILE_KEY);
    db.setActiveUser(null);
    return;
  }
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  localStorage.setItem(PROFILE_KEY, JSON.stringify(session.user));
  // Every read/write the database service does from this point on is
  // scoped to this account, so a different account's saved/liked
  // properties, chats, and registrations never leak into this session.
  db.setActiveUser(session.user?.id || null);
}

export function AuthProvider({ children }) {
  const [session, setSession] = useState(() => {
    const initial = readStoredSession();
    db.setActiveUser(initial?.user?.id || null);
    return initial;
  });
  const [loading, setLoading] = useState(false);

  const signIn = useCallback(async (profile) => {
    setLoading(true);
    try {
      const normalizedPhone = String(profile.phone || "").replace(/\D/g, "");
      // Returning phone number on this device? Reuse its existing account
      // and id instead of minting a new one / colliding with "local-user".
      const existing = findProfileByPhone(normalizedPhone);
      const id = existing?.id || profile.id || (normalizedPhone ? `user-${normalizedPhone}` : `user-${Date.now()}`);

      const user = {
        id,
        firstName: String(profile.firstName || "").trim(),
        surname: String(profile.surname || "").trim(),
        phone: String(profile.phone || "").trim(),
        name: `${profile.firstName || ""} ${profile.surname || ""}`.trim(),
        createdAt: existing?.createdAt || profile.createdAt || Date.now(),
      };

      upsertProfileInRegistry(user);

      const newSession = {
        token: generateToken(),
        user,
        createdAt: Date.now(),
        expiresAt: Date.now() + SESSION_DURATION_MS,
      };

      persistSession(newSession);
      setSession(newSession);
      return user;
    } finally {
      setLoading(false);
    }
  }, []);

  const logIn = useCallback(async (phone) => {
    setLoading(true);
    try {
      const normalizedPhone = String(phone || "").replace(/\D/g, "");

      if (!normalizedPhone) {
        throw new Error("PHONE_REQUIRED");
      }

      const storedProfile = findProfileByPhone(normalizedPhone);

      if (!storedProfile) {
        throw new Error("NOT_FOUND");
      }

      const newSession = {
        token: generateToken(),
        user: storedProfile,
        createdAt: Date.now(),
        expiresAt: Date.now() + SESSION_DURATION_MS,
      };

      persistSession(newSession);
      setSession(newSession);
      return storedProfile;
    } finally {
      setLoading(false);
    }
  }, []);

  // Business accounts (pro/contractor, landlord, agent, company) sign in
  // with the username + password they set during their registration wizard,
  // instead of the general user's phone number.
  const logInWithCredentials = useCallback(async (username, password) => {
    setLoading(true);
    try {
      const normalizedUsername = String(username || "").trim().toLowerCase();
      const pass = String(password || "");

      if (!normalizedUsername || !pass) {
        throw new Error("CREDENTIALS_REQUIRED");
      }

      const [contractors, landlord, agents, companies] = await Promise.all([
        db.getContractorRegistrations(),
        db.getLandlordRegistration(),
        db.getAllAgentRegistrations(),
        db.getAllCompanyRegistrations(),
      ]);

      const candidates = [
        ...(Array.isArray(contractors) ? contractors : []).map((r) => ({ ...r, accountType: "contractor" })),
        ...(landlord ? [{ ...landlord, accountType: "landlord" }] : []),
        ...(Array.isArray(agents) ? agents : []).map((r) => ({ ...r, accountType: "agent" })),
        ...(Array.isArray(companies) ? companies : []).map((r) => ({ ...r, accountType: "company" })),
      ];

      const match = candidates.find((record) => matchesCredentials(record, normalizedUsername, pass));

      if (!match) {
        throw new Error("NOT_FOUND");
      }

      // If this business account's userId also has a general (phone-based)
      // profile registered on this device, pull in their name/phone too.
      const linkedProfile = findProfileById(match.userId);

      const user = {
        id: match.userId || `biz-${match.accountType}-${match.id || Date.now()}`,
        firstName: linkedProfile?.firstName || "",
        surname: linkedProfile?.surname || "",
        phone: linkedProfile?.phone || match.phone || "",
        name: linkedProfile?.name || displayNameFor(match),
        accountType: match.accountType,
        businessName: match.businessName || match.companyName || match.agencyName || null,
        createdAt: linkedProfile?.createdAt || Date.now(),
      };

      const newSession = {
        token: generateToken(),
        user,
        createdAt: Date.now(),
        expiresAt: Date.now() + SESSION_DURATION_MS,
      };

      persistSession(newSession);
      setSession(newSession);
      return user;
    } finally {
      setLoading(false);
    }
  }, []);

  const signOut = useCallback(() => {
    persistSession(null);
    setSession(null);
  }, []);

  const updateProfile = useCallback((updates) => {
    setSession((current) => {
      if (!current) return current;

      const user = {
        ...current.user,
        ...updates,
        name: `${updates.firstName || current.user.firstName} ${updates.surname || current.user.surname}`.trim(),
      };

      const updated = {
        ...current,
        user,
        updatedAt: Date.now(),
      };

      upsertProfileInRegistry(user);
      persistSession(updated);
      return updated;
    });
  }, []);

  // Sync across browser tabs
  useEffect(() => {
    const handleStorage = (event) => {
      if (event.key === SESSION_KEY) {
        const next = readStoredSession();
        db.setActiveUser(next?.user?.id || null);
        setSession(next);
      }
    };

    window.addEventListener("storage", handleStorage);
    return () => window.removeEventListener("storage", handleStorage);
  }, []);

  const value = {
    user: session?.user || null,
    token: session?.token || null,
    isAuthenticated: Boolean(session?.user),
    loading,
    signIn,
    logIn,
    logInWithCredentials,
    signOut,
    updateProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used inside AuthProvider");
  }
  return context;
}

export function RequireAuth({ children }) {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? children : null;
}
