import GlobalStyles from "../styles/GlobalStyles";
import { T } from "../styles/tokens";
export default function PhoneFrame({ children }){
  return (<div className="w-full min-h-screen flex items-center justify-center py-8" style={{background:"#0B120E"}}><GlobalStyles/><div className="relative w-full mx-auto overflow-hidden" style={{background:T.ink,boxShadow:"0 30px 60px -20px rgba(0,0,0,0.6), 0 0 0 8px #0B120E",maxWidth:400,borderRadius:36}}>{children}</div></div>);
}
