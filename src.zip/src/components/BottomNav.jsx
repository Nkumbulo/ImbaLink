import { HomeIcon, Search, MessageCircle, User, Wrench } from "lucide-react";
import { T } from "../styles/tokens";

export default function BottomNav({ tab, setTab, unreadCount = 0 }) {
  const NavItem = ({ id, icon: Icon, label, badge }) => (
    <button
      onClick={() => {
        window.scrollTo({ top: 0, left: 0, behavior: "smooth" });
        setTab(id);
      }}
      className="flex flex-col items-center gap-1 flex-1 py-2 relative"
    >
      {/* Icon wrapper – relative for badge positioning */}
      <div className="relative">
        <Icon
          size={19}
          color={tab === id ? T.paper : "#7A8C80"}
          strokeWidth={tab === id ? 2.3 : 1.9}
        />
        {/* Badge – only shown for messages tab and when unreadCount > 0 */}
        {id === "messages" && badge > 0 && (
          <div
            className="absolute -top-1 -right-2 flex items-center justify-center"
            style={{
              minWidth: badge > 9 ? 20 : 18,
              height: 18,
              borderRadius: 999,
              background: T.jacaranda,
              color: T.paper,
              fontSize: 10,
              fontWeight: 600,
              padding: badge > 9 ? "0 5px" : "0 4px",
              boxShadow: "0 2px 8px rgba(108,56,255,0.5)",
              lineHeight: 1,
            }}
          >
            {badge > 9 ? "9+" : badge}
          </div>
        )}
      </div>
      <span
        className="f-body font-medium"
        style={{
          color: tab === id ? T.paper : "#7A8C80",
          fontSize: 9.2,
        }}
      >
        {label}
      </span>
    </button>
  );

  return (
    <div
      className="app-nav flex items-center justify-center gap-2 px-6"
      style={{
        background: T.ink,
        borderBottom: "1px solid rgba(245,240,228,0.08)",
      }}
    >
      <div className="app-nav-inner flex items-center justify-center gap-1 w-full max-w-6xl">
        <NavItem id="home" icon={HomeIcon} label="Home" badge={0} />
        <NavItem id="search" icon={Search} label="Explore" badge={0} />
        <NavItem id="messages" icon={MessageCircle} label="Messages" badge={unreadCount} />
        <NavItem id="contractors" icon={Wrench} label="Services" badge={0} />
        <NavItem id="profile" icon={User} label="Profile" badge={0} />
      </div>
    </div>
  );
}