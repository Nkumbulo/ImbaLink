import { useState, useRef, useEffect } from "react";
import { Send } from "lucide-react";
import { T } from "../../styles/tokens";
import { formatRelative } from "../../utils/formatters";
export default function Chat({ p, thread, onSend }){
  const [text,setText]=useState(""); const endRef=useRef(null);
  useEffect(()=>{ endRef.current?.scrollIntoView({behavior:"smooth"}); },[thread]);
  const submit=()=>{ if(text.trim()){ onSend(text.trim()); setText(""); } };
  return (<div className="flex flex-col h-full"><div className="flex-1 overflow-y-auto noscroll px-4 py-3 space-y-2.5">{thread.length===0 && (<div className="text-center py-10 f-body" style={{color:T.ink60,fontSize:12.5}}>Say hello to {p.landlord} — ask about availability, move-in date, or the deposit.</div>)}{thread.map((m,i)=>(<div key={i} className={`fade flex flex-col ${m.from==="me"?"items-end":"items-start"}`}><div className="f-body px-3 py-2 rounded-2xl" style={{background:m.from==="me"?T.jacaranda:T.paperDim,color:m.from==="me"?T.paper:T.ink,borderBottomRightRadius:m.from==="me"?4:16,borderBottomLeftRadius:m.from==="me"?16:4,fontSize:13,maxWidth:"75%"}}>{m.text}</div><span className="f-body mt-0.5 px-1" style={{color:T.ink60,fontSize:9.5}}>{formatRelative(m.ts)}</span></div>))}<div ref={endRef}/></div><div className="flex items-center gap-2 px-3 py-3" style={{borderTop:`1px solid ${T.line}`}}><input value={text} onChange={e=>setText(e.target.value)} onKeyDown={e=>{ if(e.key==="Enter") submit(); }} placeholder={`Message ${p.landlord}`} className="f-body flex-1 px-3 py-2 rounded-full outline-none" style={{background:T.paperDim,color:T.ink,fontSize:13}}/><button onClick={submit} className="w-9 h-9 rounded-full flex items-center justify-center shrink-0" style={{background:T.brick}}><Send size={14} color={T.paper}/></button></div></div>);
}
