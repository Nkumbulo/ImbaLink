import { ShieldCheck, DollarSign, Bed, HomeIcon, Building2 } from "lucide-react";
import { T } from "../../styles/tokens";
import QuickFilterBubble from "./QuickFilterBubble";
export default function QuickFiltersRail({ filters, setFilters, onShortcut }){
  const setAndJump=(updater)=>{ setFilters(updater); onShortcut(); };
  const shortcuts=[
    {key:"verified",label:"Verified",icon:ShieldCheck,active:filters.verifiedOnly,onClick:()=>setAndJump(f=>({...f,verifiedOnly:!f.verifiedOnly}))},
    {key:"under60",label:"Under $60",icon:DollarSign,active:filters.maxPrice===60,onClick:()=>setAndJump(f=>({...f,maxPrice:f.maxPrice===60?1000:60}))},
    {key:"under100",label:"Under $100",icon:DollarSign,active:filters.maxPrice===100,onClick:()=>setAndJump(f=>({...f,maxPrice:f.maxPrice===100?1000:100}))},
    {key:"room",label:"Single room",icon:Bed,active:filters.type==="Single room",onClick:()=>setAndJump(f=>({...f,type:f.type==="Single room"?"All":"Single room"}))},
    {key:"cottage",label:"Cottage",icon:HomeIcon,active:filters.type==="Cottage",onClick:()=>setAndJump(f=>({...f,type:f.type==="Cottage"?"All":"Cottage"}))},
    {key:"flat",label:"Flat",icon:Building2,active:filters.type==="Flat",onClick:()=>setAndJump(f=>({...f,type:f.type==="Flat"?"All":"Flat"}))},
    {key:"house",label:"House",icon:HomeIcon,active:filters.type==="House",onClick:()=>setAndJump(f=>({...f,type:f.type==="House"?"All":"House"}))},
  ];
  return (<div className="flex items-center gap-3.5 px-3.5 py-3 overflow-x-auto noscroll" style={{borderBottom:`1px solid ${T.line}`}}>{shortcuts.map(s=>(<QuickFilterBubble key={s.key} icon={s.icon} label={s.label} active={s.active} onClick={s.onClick}/>))}</div>);
}
