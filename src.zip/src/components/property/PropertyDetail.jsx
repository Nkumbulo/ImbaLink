import { useState, useEffect, useRef, useCallback } from "react";
import { createPortal } from "react-dom";
import {
  ChevronLeft,
  Heart,
  Bookmark,
  MapPin,
  Check,
  Bed,
  Zap,
  Droplets,
  Car,
  ShieldCheck,
  HomeIcon,
  Maximize2,
  Minimize2,
  X,
  ZoomIn,
  ZoomOut,
  ChevronRight,
  ChevronLeft as ChevronLeftIcon,
  Phone,
  MessageCircle,
  Facebook,
  Instagram,
} from "lucide-react";
import { T } from "../../styles/tokens";
import Avatar from "../common/Avatar";
import VerifiedBadge from "../common/VerifiedBadge";
import PhotoCarousel from "../common/PhotoCarousel";
import SegmentedTabs from "../common/SegmentedTabs";
import AmenityChip from "../common/AmenityChip";
import Receipt from "../common/Receipt";
import { photosFor, interestCount } from "../../utils/propertyHelpers";
import { formatDaysAgo } from "../../utils/formatters";

const TAP_HINT_STYLES = (
  <style>{`
    @keyframes tapHintFadeIn {
      from { opacity: 0; transform: translateX(-50%) translateY(10px); }
      to   { opacity: 1; transform: translateX(-50%) translateY(0); }
    }
    @keyframes tapHintFadeOut {
      from { opacity: 1; transform: translateX(-50%) translateY(0); }
      to   { opacity: 0; transform: translateX(-50%) translateY(-6px); }
    }
    @keyframes tapHintFloat {
      0%, 100% { transform: translateX(-50%) translateY(0); }
      50%      { transform: translateX(-50%) translateY(-5px); }
    }
    @keyframes tapHintRingPulse {
      0%   { box-shadow: 0 0 0 0 rgba(255,255,255,0.5); }
      70%  { box-shadow: 0 0 0 9px rgba(255,255,255,0); }
      100% { box-shadow: 0 0 0 0 rgba(255,255,255,0); }
    }
    @keyframes skeletonPulse {
      0%, 100% { opacity: 0.35; }
      50%      { opacity: 0.7; }
    }
    @keyframes viewerFadeIn {
      from { opacity: 0; }
      to   { opacity: 1; }
    }
    @keyframes overlayFadeIn {
      from { opacity: 0; }
      to   { opacity: 1; }
    }
    @keyframes panelSlideUp {
      from {
        transform: translateY(40px);
        opacity: 0;
      }
      to {
        transform: translateY(0);
        opacity: 1;
      }
    }
    .tap-hint-wrap {
      animation:
        tapHintFadeIn .4s ease both,
        tapHintFloat 2.2s ease-in-out .4s infinite;
    }
    .tap-hint-wrap.leaving {
      animation: tapHintFadeOut .35s ease both;
    }
    .tap-hint-ring {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 22px;
      height: 22px;
      border-radius: 9999px;
      background: rgba(255,255,255,0.16);
      animation: tapHintRingPulse 1.8s ease-out infinite;
    }
    .img-skeleton {
      animation: skeletonPulse 1.3s ease-in-out infinite;
    }
    .viewer-img-enter {
      animation: viewerFadeIn 0.3s ease;
    }

    .detail-photo-layer,
    .detail-photo-layer * {
      box-sizing: border-box;
    }
    .detail-photo-layer img {
      width: 100% !important;
      height: 100% !important;
      object-fit: cover !important;
      object-position: center !important;
    }
    .detail-photo-layer [style*="background-image"] {
      background-size: cover !important;
      background-position: center !important;
    }

    .detail-panel-scroll {
      scrollbar-width: thin;
      scrollbar-color: ${T.line} transparent;
    }
    .detail-panel-scroll::-webkit-scrollbar {
      width: 6px;
    }
    .detail-panel-scroll::-webkit-scrollbar-thumb {
      background: ${T.line};
      border-radius: 999px;
    }

    @media (prefers-reduced-motion: reduce) {
      .tap-hint-wrap, .tap-hint-wrap.leaving, .tap-hint-ring, .img-skeleton, .viewer-img-enter,
      .overlay-fade-in, .panel-slide-up { animation: none !important; }
    }
  `}</style>
);

const MIN_ZOOM = 1;
const MAX_ZOOM = 4;
const DOUBLE_TAP_ZOOM = 2.5;

const digitsOnly = (v) => (v ? String(v).replace(/[^\d]/g, "") : "");
const telDigits = (v) => {
  if (!v) return "";
  const trimmed = String(v).trim();
  const hasPlus = trimmed.startsWith("+");
  return (hasPlus ? "+" : "") + trimmed.replace(/[^\d]/g, "");
};
const stripHandle = (v) => (v ? String(v).replace(/^@/, "").trim() : "");

function buildContactMethods(p) {
  const methods = [];
  const phone = p.phone || p.phoneNumber || "";
  const waSource = p.whatsapp || p.whatsappNumber || phone;
  const messenger = p.messenger || p.messengerUsername || p.facebook || "";
  const instagram = p.instagram || p.instagramHandle || "";

  if (phone) {
    methods.push({
      id: "call",
      label: "Call",
      value: phone,
      href: `tel:${telDigits(phone)}`,
      Icon: Phone,
      iconBg: T.ink,
    });
  }
  if (waSource) {
    const text = encodeURIComponent(
      `Hi ${p.landlord || "there"}, I'm interested in your listing "${p.title || ""}" on ImbaLink.`
    );
    methods.push({
      id: "whatsapp",
      label: "WhatsApp",
      value: phone || waSource,
      href: `https://wa.me/${digitsOnly(waSource)}?text=${text}`,
      Icon: MessageCircle,
      iconBg: "#25D366",
    });
  }
  if (messenger) {
    methods.push({
      id: "messenger",
      label: "Messenger",
      value: `@${stripHandle(messenger)}`,
      href: `https://m.me/${stripHandle(messenger)}`,
      Icon: Facebook,
      iconBg: "#0084FF",
    });
  }
  if (instagram) {
    methods.push({
      id: "instagram",
      label: "Instagram",
      value: `@${stripHandle(instagram)}`,
      href: `https://instagram.com/${stripHandle(instagram)}`,
      Icon: Instagram,
      iconBg: "linear-gradient(135deg, #F58529, #DD2A7B, #8134AF, #515BD4)",
    });
  }
  return methods;
}

function ContactRow({ method }) {
  const { label, value, href, Icon, iconBg } = method;
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center gap-3 active:scale-[0.98] transition-transform"
      style={{
        padding: "12px 14px",
        borderRadius: 16,
        background: T.paperDim,
        textDecoration: "none",
      }}
    >
      <span
        className="flex items-center justify-center shrink-0"
        style={{ width: 38, height: 38, borderRadius: 12, background: iconBg }}
      >
        <Icon size={18} color={T.white} strokeWidth={2} />
      </span>
      <div className="flex-1 min-w-0">
        <div className="f-body font-semibold" style={{ color: T.ink, fontSize: 13 }}>
          {label}
        </div>
        <div className="f-body truncate" style={{ color: T.ink60, fontSize: 11.5 }}>
          {value}
        </div>
      </div>
      <ChevronRight size={16} color={T.ink60} />
    </a>
  );
}

// 🔥 Helper to safely check listing verification (prevents crash from boolean values)
const isListingVerified = (p) =>
  p?.verification === "verified" || p?.verified === true || p?.verificationStatus === "verified";

export default function PropertyDetail({
  p,
  initialTab,
  onClose,
  liked,
  saved,
  onToggleLike,
  onToggleSave,
  viewingRequested,
  onRequestViewing,
  onOpenLister,
  onOpenMessage,
}) {
  // Desktop/tablet gets its own simple centered-card layout (built below)
  // instead of trying to reshape the mobile full-bleed sheet with CSS
  // overrides, which kept leaving mismatched/misplaced pieces behind.
  const [isDesktop, setIsDesktop] = useState(
    typeof window !== "undefined" ? window.matchMedia("(min-width: 768px)").matches : false
  );
  useEffect(() => {
    if (typeof window === "undefined") return;
    const mq = window.matchMedia("(min-width: 768px)");
    const update = () => setIsDesktop(mq.matches);
    update();
    mq.addEventListener?.("change", update);
    return () => mq.removeEventListener?.("change", update);
  }, []);

  const [tab, setTab] = useState(initialTab === "message" ? "contact" : initialTab || "overview");
  const [burst, setBurst] = useState(0);
  const [photoExpanded, setPhotoExpanded] = useState(false);
  const [viewportH, setViewportH] = useState(
    typeof window !== "undefined" ? window.innerHeight : 800
  );
  const [viewerIndex, setViewerIndex] = useState(null);
  const [sentFlash, setSentFlash] = useState(false);
  const sentTimerRef = useRef(null);
  const [isClosing, setIsClosing] = useState(false);
  const closeTimeoutRef = useRef(null);

  const [hintVisible, setHintVisible] = useState(true);
  const [hintLeaving, setHintLeaving] = useState(false);
  const hintTimers = useRef([]);

  const overlayRef = useRef(null);
  const scrollableRef = useRef(null);
  const panelRef = useRef(null);
  const touchStartYRef = useRef(null);
  const touchActionDoneRef = useRef(false);
  const gestureStartInPanelRef = useRef(false);

  const lastTapRef = useRef(0);
  const lastTapPosRef = useRef({ x: 0, y: 0 });

  const COLLAPSED_PANEL_TOP = 294;

  useEffect(() => {
    const hideTimer = setTimeout(() => setHintLeaving(true), 4000);
    const removeTimer = setTimeout(() => setHintVisible(false), 4350);
    hintTimers.current.push(hideTimer, removeTimer);
    return () => hintTimers.current.forEach(clearTimeout);
  }, []);

  useEffect(() => {
    return () => {
      if (sentTimerRef.current) clearTimeout(sentTimerRef.current);
      if (closeTimeoutRef.current) clearTimeout(closeTimeoutRef.current);
    };
  }, []);

  const dismissHint = useCallback(() => {
    hintTimers.current.forEach(clearTimeout);
    setHintLeaving(true);
    setTimeout(() => setHintVisible(false), 350);
  }, []);

  const photos = (p.images && p.images.length > 0) ? p.images : photosFor(p.id);
  const contactMethods = buildContactMethods(p);

  const [loadedMap, setLoadedMap] = useState({});
  const markLoaded = useCallback((i) => {
    setLoadedMap((m) => (m[i] ? m : { ...m, [i]: true }));
  }, []);

  useEffect(() => {
    if (typeof window === "undefined" || typeof window.Image === "undefined") return;
    let cancelled = false;
    photos.forEach((src, i) => {
      const img = new window.Image();
      img.decoding = "async";
      img.onload = () => { if (!cancelled) markLoaded(i); };
      img.onerror = () => { if (!cancelled) markLoaded(i); };
      img.src = src;
    });
    return () => { cancelled = true; };
  }, [photos.join("|")]);

  useEffect(() => {
    const scrollY = window.scrollY;
    const body = document.body;
    const prev = {
      position: body.style.position,
      top: body.style.top,
      left: body.style.left,
      right: body.style.right,
      width: body.style.width,
      overflow: body.style.overflow,
    };

    body.style.position = "fixed";
    body.style.top = `-${scrollY}px`;
    body.style.left = "0";
    body.style.right = "0";
    body.style.width = "100%";
    body.style.overflow = "hidden";

    return () => {
      body.style.position = prev.position;
      body.style.top = prev.top;
      body.style.left = prev.left;
      body.style.right = prev.right;
      body.style.width = prev.width;
      body.style.overflow = prev.overflow;
      window.scrollTo(0, scrollY);
    };
  }, []);

  useEffect(() => {
    const preventBackgroundScroll = (e) => {
      if (overlayRef.current && !overlayRef.current.contains(e.target)) {
        e.preventDefault();
      }
    };

    document.addEventListener('wheel', preventBackgroundScroll, { passive: false });
    document.addEventListener('touchmove', preventBackgroundScroll, { passive: false });

    return () => {
      document.removeEventListener('wheel', preventBackgroundScroll);
      document.removeEventListener('touchmove', preventBackgroundScroll);
    };
  }, []);

  useEffect(() => {
    const overlay = overlayRef.current;
    if (!overlay) return;
    // The swipe/scroll-to-expand-or-dismiss gesture only makes sense for the
    // mobile full-bleed sheet. On desktop/tablet the photo and panel are a
    // static side-by-side layout, so skip wiring it up there — otherwise an
    // ordinary scroll inside the info panel can trigger onClose().
    if (typeof window !== "undefined" && window.innerWidth >= 768) return;

    const handleWheel = (e) => {
      const scrollable = scrollableRef.current;
      const targetInsideScrollable = scrollable && scrollable.contains(e.target);
      const targetInsidePanel = panelRef.current && panelRef.current.contains(e.target);
      const atTop = scrollable ? scrollable.scrollTop <= 0 : true;

      if (!targetInsidePanel) return;

      if (targetInsideScrollable && (!atTop || (e.deltaY < 0 && photoExpanded))) return;

      e.preventDefault();

      if (e.deltaY < 0 && !photoExpanded) {
        setPhotoExpanded(true);
      } else if (e.deltaY > 0) {
        if (photoExpanded && (!targetInsideScrollable || atTop)) {
          setPhotoExpanded(false);
        } else if (!photoExpanded) {
          onClose();
        }
      }
    };

    const handleTouchStart = (e) => {
      if (e.touches.length === 1) {
        const scrollable = scrollableRef.current;
        const startedInScrollable = scrollable && scrollable.contains(e.target);
        touchStartYRef.current = e.touches[0].clientY;
        touchActionDoneRef.current = false;
        gestureStartInPanelRef.current =
          (panelRef.current?.contains(e.target) ?? false) && !startedInScrollable;
      }
    };

    const handleTouchMove = (e) => {
      if (e.touches.length !== 1 || touchStartYRef.current === null || touchActionDoneRef.current) return;

      if (!gestureStartInPanelRef.current) return;

      e.preventDefault();

      const deltaY = e.touches[0].clientY - touchStartYRef.current;

      if (Math.abs(deltaY) < 1) return;

      if (deltaY < 0 && !photoExpanded) {
        setPhotoExpanded(true);
        touchActionDoneRef.current = true;
      } else if (deltaY > 0) {
        if (photoExpanded) {
          setPhotoExpanded(false);
          touchActionDoneRef.current = true;
        } else {
          onClose();
          touchActionDoneRef.current = true;
        }
      }
    };

    overlay.addEventListener('wheel', handleWheel, { passive: false });
    overlay.addEventListener('touchstart', handleTouchStart, { passive: true });
    overlay.addEventListener('touchmove', handleTouchMove, { passive: false });

    return () => {
      overlay.removeEventListener('wheel', handleWheel);
      overlay.removeEventListener('touchstart', handleTouchStart);
      overlay.removeEventListener('touchmove', handleTouchMove);
    };
  }, [photoExpanded, onClose]);

  const doubleTap = (e) => {
    e.stopPropagation();
    if (!liked) onToggleLike(p.id);
    setBurst(Date.now());
  };

  const togglePhotoExpand = (e) => {
    e.stopPropagation();
    setPhotoExpanded((v) => !v);
  };

  const handleTabChange = (nextTab) => {
    setTab(nextTab);
    setPhotoExpanded(true);
  };

  const handlePanelClick = (e) => {
    if (
      e.target.closest("button, a, input, textarea, [data-no-toggle], .noscroll")
    ) {
      return;
    }
    togglePhotoExpand(e);
  };

  useEffect(() => {
    const onResize = () => setViewportH(window.innerHeight);
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isInteracting, setIsInteracting] = useState(false);
  const imgWrapRef = useRef(null);
  const pointers = useRef(new Map());
  const gesture = useRef({ mode: null, startX: 0, startY: 0, originX: 0, originY: 0, startDist: 0, startZoom: 1 });

  const clampPan = useCallback((next, z) => {
    const el = imgWrapRef.current;
    if (!el) return next;
    const rect = el.getBoundingClientRect();
    const maxX = Math.max(0, (rect.width * (z - 1)) / 2);
    const maxY = Math.max(0, (rect.height * (z - 1)) / 2);
    return {
      x: Math.min(maxX, Math.max(-maxX, next.x)),
      y: Math.min(maxY, Math.max(-maxY, next.y)),
    };
  }, []);

  const applyZoom = useCallback((nextZoom, anchorPan) => {
    const clamped = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, nextZoom));
    setZoom(clamped);
    setPan((prev) => {
      const base = anchorPan || prev;
      return clamped <= MIN_ZOOM ? { x: 0, y: 0 } : clampPan(base, clamped);
    });
  }, [clampPan]);

  const resetZoom = useCallback(() => { setZoom(1); setPan({ x: 0, y: 0 }); }, []);
  const zoomIn = () => applyZoom(zoom + 0.5);
  const zoomOut = () => applyZoom(zoom - 0.5);

  const handleDoubleClick = (e) => {
    e.stopPropagation();
    if (zoom > MIN_ZOOM) {
      resetZoom();
    } else {
      applyZoom(DOUBLE_TAP_ZOOM, { x: 0, y: 0 });
    }
  };

  const handleWheel = (e) => {
    if (viewerIndex === null) return;
    const delta = e.deltaY > 0 ? -0.25 : 0.25;
    applyZoom(zoom + delta);
  };

  const distanceBetween = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

  const onImgPointerDown = (e) => {
    e.currentTarget.setPointerCapture?.(e.pointerId);
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (pointers.current.size === 2) {
      const pts = [...pointers.current.values()];
      gesture.current = {
        mode: "pinch",
        startDist: distanceBetween(pts[0], pts[1]),
        startZoom: zoom,
        originX: pan.x,
        originY: pan.y,
      };
      setIsInteracting(true);
    } else if (pointers.current.size === 1) {
      if (zoom > MIN_ZOOM) {
        gesture.current = {
          mode: "drag",
          startX: e.clientX,
          startY: e.clientY,
          originX: pan.x,
          originY: pan.y,
        };
        setIsInteracting(true);
      } else {
        gesture.current = {
          mode: "swipe",
          startX: e.clientX,
          startY: e.clientY,
        };
      }
    }
  };

  const onImgPointerMove = (e) => {
    if (!pointers.current.has(e.pointerId)) return;
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (gesture.current.mode === "pinch" && pointers.current.size === 2) {
      const pts = [...pointers.current.values()];
      const dist = distanceBetween(pts[0], pts[1]);
      const ratio = dist / (gesture.current.startDist || dist);
      const nextZoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, gesture.current.startZoom * ratio));
      setZoom(nextZoom);
      setPan(clampPan({ x: gesture.current.originX, y: gesture.current.originY }, nextZoom));
    } else if (gesture.current.mode === "drag" && pointers.current.size === 1) {
      const dx = e.clientX - gesture.current.startX;
      const dy = e.clientY - gesture.current.startY;
      setPan(clampPan({ x: gesture.current.originX + dx, y: gesture.current.originY + dy }, zoom));
    }
  };

  const endPointer = (e) => {
    pointers.current.delete(e.pointerId);

    if (pointers.current.size === 0) {
      let movementDistance = 0;
      if (gesture.current.startX !== undefined && gesture.current.startY !== undefined) {
        movementDistance = Math.hypot(e.clientX - gesture.current.startX, e.clientY - gesture.current.startY);
      }

      const isTap = movementDistance < 10;

      if (isTap) {
        const now = Date.now();
        const lastPos = lastTapPosRef.current;
        const distanceFromLastTap = Math.hypot(e.clientX - lastPos.x, e.clientY - lastPos.y);
        if (now - lastTapRef.current < 300 && distanceFromLastTap < 30) {
          handleDoubleClick(e);
          lastTapRef.current = 0;
          lastTapPosRef.current = { x: 0, y: 0 };
        } else {
          lastTapRef.current = now;
          lastTapPosRef.current = { x: e.clientX, y: e.clientY };
        }
      }

      if (!isTap && gesture.current.mode === "swipe") {
        const dx = e.clientX - gesture.current.startX;
        const dy = e.clientY - gesture.current.startY;
        if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.5) {
          if (dx > 0) {
            prevPhoto();
          } else {
            nextPhoto();
          }
        }
      }

      gesture.current = { mode: null };
      setIsInteracting(false);
      setPan((prev) => clampPan(prev, zoom));
    } else if (pointers.current.size === 1) {
      const [remaining] = [...pointers.current.entries()];
      const [, point] = remaining;
      gesture.current = {
        mode: zoom > MIN_ZOOM ? "drag" : "swipe",
        startX: point.x,
        startY: point.y,
        originX: pan.x,
        originY: pan.y,
      };
    }
  };

  const openViewer = (e) => {
    e.stopPropagation();
    dismissHint();
    setViewerIndex(0);
    resetZoom();
  };

  const closeViewer = () => { setViewerIndex(null); resetZoom(); };
  const nextPhoto = () => { setViewerIndex((i) => (i + 1) % photos.length); resetZoom(); };
  const prevPhoto = () => { setViewerIndex((i) => (i - 1 + photos.length) % photos.length); resetZoom(); };

  const FloatBtn = ({ onClick, children }) => (
    <button
      onClick={onClick}
      className="w-9 h-9 rounded-full flex items-center justify-center active:scale-90 transition-transform"
      style={{ background: "rgba(20,32,26,0.55)", backdropFilter: "blur(8px)" }}
    >
      {children}
    </button>
  );

  const PanelBtn = ({ onClick, children }) => (
    <button
      onClick={onClick}
      className="w-9 h-9 rounded-full flex items-center justify-center active:scale-90 transition-transform"
      style={{ background: T.paperDim }}
    >
      {children}
    </button>
  );

  const handleBottomAction = () => {
    if (sentFlash) return;

    if (viewingRequested) {
      onOpenMessage?.(p.id);
      setIsClosing(true);
      if (closeTimeoutRef.current) clearTimeout(closeTimeoutRef.current);
      closeTimeoutRef.current = setTimeout(() => {
        onClose();
      }, 350);
      return;
    }

    setSentFlash(true);
    onRequestViewing?.();
    if (sentTimerRef.current) clearTimeout(sentTimerRef.current);
    sentTimerRef.current = setTimeout(() => {
      setSentFlash(false);
    }, 1800);
  };

  const overlayStyle = {
    background: T.ink,
    animation: "overlayFadeIn 0.3s ease",
    transition: "transform 0.35s cubic-bezier(0.25, 0.8, 0.25, 1), opacity 0.35s ease",
    transform: isClosing ? "translateY(100%)" : "translateY(0)",
    opacity: isClosing ? 0 : 1,
  };

  const panelInner = (
    <>
      {/* Header section */}
        <div className="px-4 pt-2 shrink-0">
          {(() => {
            const rawTitle = String(p.title || "Property");
            const [titlePart, ...locationParts] = rawTitle.split(",");
            const displayTitle = titlePart.trim();
            const displayLocation =
              locationParts.join(",").trim() ||
              p.location ||
              p.area ||
              p.suburb ||
              "";

            return (
              <div
                className="relative overflow-hidden rounded-[24px] px-4 py-3.5"
                style={{
                  background: T.paper,
                  border: `1px solid ${T.line}`,
                  boxShadow: "0 4px 18px rgba(20,32,26,0.05)",
                }}
              >
                <div className="flex items-center gap-3">
                  <div
                    className="shrink-0 flex items-center justify-center rounded-full"
                    style={{
                      width: 46,
                      height: 46,
                      background: T.paperDim,
                      border: `1px solid ${T.line}`,
                    }}
                  >
                    <Bed size={22} color={T.ink} strokeWidth={1.8} />
                  </div>

                  <div className="min-w-0 flex-1">
                    <div
                      className="f-display font-bold"
                      style={{
                        color: T.ink,
                        fontSize: 17,
                        lineHeight: 1.25,
                        letterSpacing: "-0.01em",
                        whiteSpace: "normal",
                        overflowWrap: "break-word",
                      }}
                    >
                      {displayTitle}
                    </div>

                    {displayLocation && (
                      <div
                        className="f-body flex items-center gap-1.5 mt-1"
                        style={{
                          color: T.ink60,
                          fontSize: 12.5,
                          lineHeight: 1.2,
                        }}
                      >
                        <MapPin size={13} color={T.brick} strokeWidth={2} />
                        <span className="truncate">{displayLocation}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Landlord card */}
          <div
            className="flex items-center gap-2.5 mt-4 px-3 py-2.5 rounded-2xl cursor-pointer"
            style={{ background: T.paperDim }}
            onClick={() =>
              onOpenLister?.({
                id: p.landlordRegistrationId ?? p.id,
                name: p.landlord,
                grad: p.grad,
                verified: p.landlordVerified,
              })
            }
          >
            <Avatar grad={p.grad} letter={(p.landlord || "?")[0]} size={32} />
            <div className="flex-1 min-w-0">
              <div className="f-body font-semibold truncate" style={{ color: T.ink, fontSize: 13 }}>
                {p.landlord || "Landlord"}
              </div>
              <div className="f-body" style={{ color: T.brick, fontSize: 10.5, fontWeight: 500 }}>
                View listings
              </div>
            </div>
            <VerifiedBadge status={p.landlordVerified ? "verified" : "pending"} compact size={32} />
          </div>

          {/* Tabs */}
          <div className="mt-4">
            <SegmentedTabs
              tabs={[
                { id: "overview", label: "overview" },
                { id: "cost", label: "cost" },
                { id: "contact", label: "contact" },
              ]}
              active={tab}
              onChange={handleTabChange}
            />
          </div>
        </div>

        {/* Scrollable content */}
        <div
          ref={scrollableRef}
          className="flex-1 overflow-y-auto noscroll min-h-0 detail-panel-scroll"
          style={{ overscrollBehavior: "contain" }}
        >
          {tab === "overview" && (
            <div className="px-4 py-5 space-y-5 fade">
              <p className="f-body leading-relaxed" style={{ color: T.ink, fontSize: 13 }}>
                {p.desc}
              </p>
              <div className="flex items-center gap-1 f-body" style={{ color: T.ink60, fontSize: 12, marginTop: 16 }}>
                <MapPin size={12} className="shrink-0" />
                <span>
                  {p.distanceKm} km away · listed {formatDaysAgo(p.postedDaysAgo).toLowerCase()} ·{" "}
                  {interestCount(p.id) + (liked ? 1 : 0)} interested
                </span>
              </div>
              <div>
                <div className="f-mono mb-3" style={{ color: T.ink60, fontSize: 10, letterSpacing: "0.2em" }}>
                  AMENITIES
                </div>
                <div className="flex flex-wrap gap-2">
                  <AmenityChip icon={Bed} text={p.bathroom + " bathroom"} />
                  <AmenityChip icon={Zap} text={p.electricity} />
                  <AmenityChip icon={Droplets} text={p.water} />
                  <AmenityChip icon={Car} text={p.parking ? "Parking available" : "No parking"} />
                  <AmenityChip icon={ShieldCheck} text={p.security} />
                  <AmenityChip icon={HomeIcon} text={p.furnished ? "Furnished" : "Unfurnished"} />
                </div>
              </div>
              <div>
                <div className="f-mono mb-3" style={{ color: T.ink60, fontSize: 10, letterSpacing: "0.2em" }}>
                  HOUSE RULES
                </div>
                <div className="rounded-2xl p-4 space-y-3" style={{ background: T.paperDim }}>
                  {(p.rules || []).map((r, i) => (
                    <div key={i} className="f-body flex items-start gap-2" style={{ color: T.ink, fontSize: 12.5 }}>
                      <Check size={13} style={{ color: T.msasa, marginTop: 1.5, flexShrink: 0 }} />
                      {r}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
          {tab === "cost" && (
            <div className="px-4 py-5 fade">
              <Receipt p={p} />
              <p className="f-body mt-4 leading-relaxed" style={{ color: T.ink60, fontSize: 11.5 }}>
                This is the full cost shown to you before you commit. The platform fee is fixed — never a percentage of your rent.
              </p>
            </div>
          )}
          {tab === "contact" && (
            <div className="px-4 py-5 fade">
              {contactMethods.length > 0 ? (
                <>
                  <div className="f-mono mb-3" style={{ color: T.ink60, fontSize: 10, letterSpacing: "0.2em" }}>
                    REACH OUT
                  </div>
                  <div className="flex flex-col gap-2">
                    {contactMethods.map((m) => (
                      <ContactRow key={m.id} method={m} />
                    ))}
                  </div>
                  <p className="f-body mt-4 leading-relaxed" style={{ color: T.ink60, fontSize: 11.5 }}>
                    Tapping a button above opens that app directly with them — nothing is sent through ImbaLink.
                  </p>
                </>
              ) : (
                <div className="text-center py-10 f-body" style={{ color: T.ink60, fontSize: 12.5 }}>
                  No contact details added yet.
                </div>
              )}
            </div>
          )}
        </div>

        {/* Bottom action button */}
        {tab !== "contact" && (
          <div className="p-4 shrink-0" style={{ background: T.paper, boxShadow: "0 -4px 16px rgba(0,0,0,0.06)" }}>
            <button
              onClick={handleBottomAction}
              disabled={sentFlash}
              className="w-full py-3.5 rounded-full f-display font-semibold flex items-center justify-center gap-1.5 active:scale-95 transition-transform"
              style={{
                background: viewingRequested || sentFlash ? T.msasa : T.brick,
                color: T.paper,
                opacity: sentFlash ? 0.9 : 1,
                fontSize: 13.5,
                boxShadow: viewingRequested || sentFlash ? "none" : `0 6px 16px -4px ${T.brick}66`,
              }}
            >
              {sentFlash ? (
                <>
                  <Check size={15} /> Message sent
                </>
              ) : viewingRequested ? (
                <>
                  <MessageCircle size={15} /> Open chat
                </>
              ) : (
                "Request a viewing"
              )}
            </button>
          </div>
        )}
    </>
  );

  const photoViewer = viewerIndex !== null ? (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black"
          onClick={(e) => {
            if (e.target === e.currentTarget) closeViewer();
          }}
          onWheel={handleWheel}
        >
          <button
            onClick={closeViewer}
            className="absolute top-5 right-5 z-10 w-10 h-10 rounded-full flex items-center justify-center bg-white/20 backdrop-blur"
          >
            <X size={24} color="white" />
          </button>

          <div className="absolute bottom-5 right-5 flex gap-2 z-10">
            <button
              onClick={(e) => { e.stopPropagation(); zoomOut(); }}
              className="w-10 h-10 rounded-full flex items-center justify-center bg-white/20 backdrop-blur"
              disabled={zoom <= MIN_ZOOM}
              style={{ opacity: zoom <= MIN_ZOOM ? 0.4 : 1 }}
            >
              <ZoomOut size={20} color="white" />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); zoomIn(); }}
              className="w-10 h-10 rounded-full flex items-center justify-center bg-white/20 backdrop-blur"
              disabled={zoom >= MAX_ZOOM}
              style={{ opacity: zoom >= MAX_ZOOM ? 0.4 : 1 }}
            >
              <ZoomIn size={20} color="white" />
            </button>
          </div>

          <div
            ref={imgWrapRef}
            className="w-full h-full flex items-center justify-center overflow-hidden"
            style={{ touchAction: "none" }}
            onClick={(e) => e.stopPropagation()}
            onPointerDown={onImgPointerDown}
            onPointerMove={onImgPointerMove}
            onPointerUp={endPointer}
            onPointerCancel={endPointer}
            onPointerLeave={endPointer}
          >
            {!loadedMap[viewerIndex] && (
              <div
                className="img-skeleton absolute"
                style={{
                  width: "70%",
                  height: "55%",
                  borderRadius: 16,
                  background: "rgba(255,255,255,0.08)",
                }}
              />
            )}
            <img
              key={viewerIndex}
              src={photos[viewerIndex]}
              alt={`Property photo ${viewerIndex + 1}`}
              className="max-w-full max-h-full object-contain viewer-img-enter"
              draggable={false}
              decoding="async"
              onLoad={() => markLoaded(viewerIndex)}
              style={{
                transform: `translate3d(${pan.x}px, ${pan.y}px, 0) scale(${zoom})`,
                transition: isInteracting ? "none" : "transform .25s cubic-bezier(0.2,0.8,0.2,1)",
                cursor: zoom > MIN_ZOOM ? (isInteracting ? "grabbing" : "grab") : "zoom-in",
                touchAction: "none",
                opacity: loadedMap[viewerIndex] ? 1 : 0,
                willChange: "transform",
              }}
            />
          </div>

          {photos.length > 1 && (
            <>
              <button
                onClick={(e) => { e.stopPropagation(); prevPhoto(); }}
                className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full flex items-center justify-center bg-white/20 backdrop-blur"
              >
                <ChevronLeftIcon size={24} color="white" />
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); nextPhoto(); }}
                className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full flex items-center justify-center bg-white/20 backdrop-blur"
              >
                <ChevronRight size={24} color="white" />
              </button>
            </>
          )}

          <div className="absolute bottom-5 left-5 text-white text-sm font-medium">
            {viewerIndex + 1} / {photos.length}
          </div>
        </div>
  ) : null;

  const mobileOverlay = (
    <div
      ref={overlayRef}
      className="fixed inset-0 z-40 overlay-fade-in"
      style={overlayStyle}
    >
      {TAP_HINT_STYLES}

      {/* Photo layer */}
      <div
        className="absolute inset-0 detail-photo-layer"
        style={{
          borderTopLeftRadius: 20,
          borderTopRightRadius: 20,
          overflow: "hidden",
          zIndex: 0,
          height: COLLAPSED_PANEL_TOP,
        }}
        onClick={openViewer}
      >
        <PhotoCarousel
          photos={photos}
          height={COLLAPSED_PANEL_TOP}
          onDoubleTap={doubleTap}
          burstKey={burst}
          badge={<VerifiedBadge status={isListingVerified(p) ? "verified" : "pending"} />}
          showDots={false}
        />

        <div
          style={{
            position: "absolute",
            bottom: 0,
            left: 0,
            right: 0,
            height: 24,
            background: `linear-gradient(to bottom, transparent, ${T.paper})`,
            zIndex: 5,
            pointerEvents: "none",
          }}
        />

        {hintVisible && !photoExpanded && viewerIndex === null && (
          <div
            className={`absolute tap-hint-wrap${hintLeaving ? " leaving" : ""}`}
            style={{ top: 96, left: "50%", zIndex: 15, pointerEvents: "none" }}
          >
            <div
              className="flex items-center gap-2"
              style={{
                padding: "6px 14px 6px 6px",
                borderRadius: 999,
                background: "rgba(20,32,26,0.55)",
                backdropFilter: "blur(8px)",
              }}
            >
              <span className="tap-hint-ring">
                <ZoomIn size={13} color={T.white} />
              </span>
              <span className="f-body" style={{ color: T.white, fontSize: 11.5, fontWeight: 500 }}>
                Tap photo to view
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Close button */}
      <div className="absolute top-3 left-3" style={{ zIndex: 20 }}>
        <FloatBtn onClick={onClose}>
          <ChevronLeft size={18} color={T.white} />
        </FloatBtn>
      </div>

      {/* Like/save when collapsed */}
      {!photoExpanded && (
        <div
          className="absolute flex flex-col gap-2.5"
          style={{ top: 155, right: 12, transform: "translateY(-50%)", zIndex: 20 }}
        >
          <FloatBtn onClick={() => onToggleLike(p.id)}>
            <Heart
              size={16}
              color={liked ? T.brick : T.white}
              fill={liked ? T.brick : "none"}
              strokeWidth={2}
            />
          </FloatBtn>
          <FloatBtn onClick={() => onToggleSave(p.id)}>
            <Bookmark
              size={15}
              color={T.white}
              fill={saved ? T.white : "none"}
              strokeWidth={2}
            />
          </FloatBtn>
        </div>
      )}

      {/* Panel */}
      <div
        ref={panelRef}
        className="absolute left-0 right-0 bottom-0 flex flex-col min-h-0 panel-slide-up"
        style={{
          top: photoExpanded ? 0 : COLLAPSED_PANEL_TOP,
          background: T.paper,
          borderTopLeftRadius: 0,
          borderTopRightRadius: 0,
          boxShadow: "0 -8px 24px rgba(0,0,0,0.18)",
          zIndex: 10,
          transition: "top 0.3s cubic-bezier(0.25, 0.8, 0.25, 1)",
          animation: "panelSlideUp 0.4s cubic-bezier(0.4, 0, 0.2, 1)",
          willChange: "top",
        }}
        onClick={handlePanelClick}
      >
        {/* Handle bar */}
        <div className="w-9 h-1 rounded-full mx-auto mt-2.5" style={{ background: T.line }} />

        {/* Top control row */}
        <div className="flex items-center justify-end gap-2 px-4 pt-2 pb-1" data-no-toggle>
          <div
            style={{
              opacity: photoExpanded ? 1 : 0,
              pointerEvents: photoExpanded ? "auto" : "none",
              transition: "opacity 0.2s ease",
              display: "flex",
              gap: 8,
            }}
          >
            <PanelBtn onClick={() => onToggleLike(p.id)}>
              <Heart
                size={16}
                color={liked ? T.brick : T.ink}
                fill={liked ? T.brick : "none"}
                strokeWidth={2}
              />
            </PanelBtn>
            <PanelBtn onClick={() => onToggleSave(p.id)}>
              <Bookmark
                size={15}
                color={saved ? T.jacaranda : T.ink}
                fill={saved ? T.jacaranda : "none"}
                strokeWidth={2}
              />
            </PanelBtn>
          </div>

          <PanelBtn onClick={togglePhotoExpand}>
            {photoExpanded ? <Minimize2 size={16} color={T.ink} /> : <Maximize2 size={16} color={T.ink} />}
          </PanelBtn>
          <PanelBtn onClick={onClose}>
            <X size={18} color={T.ink} />
          </PanelBtn>
        </div>

        {panelInner}
      </div>

      {photoViewer}
    </div>
  );

  const desktopOverlay = (
    <div
      ref={overlayRef}
      className="fixed inset-0 z-40 flex items-center justify-center"
      style={{
        background: "rgba(20,32,26,0.55)",
        backdropFilter: "blur(10px)",
        WebkitBackdropFilter: "blur(10px)",
        padding: 24,
        boxSizing: "border-box",
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      {TAP_HINT_STYLES}

      <div
        style={{
          width: "min(980px, calc(100vw - 48px))",
          height: "min(760px, calc(100vh - 48px))",
          borderRadius: 24,
          overflow: "hidden",
          background: T.paper,
          boxShadow: "0 28px 80px rgba(20,32,26,0.30)",
          display: "flex",
          position: "relative",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Photo column */}
        <div style={{ position: "relative", width: "44%", height: "100%", flexShrink: 0, background: "#111" }}>
          <img
            src={photos[0]}
            alt={p.title || "Property"}
            draggable={false}
            onClick={openViewer}
            style={{
              width: "100%",
              height: "100%",
              objectFit: "cover",
              objectPosition: "center",
              display: "block",
              cursor: "pointer",
            }}
          />
          <div style={{ position: "absolute", top: 16, right: 16, zIndex: 2 }}>
            <VerifiedBadge status={isListingVerified(p) ? "verified" : "pending"} />
          </div>
          <div style={{ position: "absolute", top: 16, left: 16, zIndex: 2 }}>
            <FloatBtn onClick={onClose}>
              <ChevronLeft size={18} color={T.white} />
            </FloatBtn>
          </div>
          <div
            style={{
              position: "absolute",
              top: "42%",
              right: 16,
              transform: "translateY(-50%)",
              display: "flex",
              flexDirection: "column",
              gap: 10,
              zIndex: 2,
            }}
          >
            <FloatBtn onClick={() => onToggleLike(p.id)}>
              <Heart
                size={16}
                color={liked ? T.brick : T.white}
                fill={liked ? T.brick : "none"}
                strokeWidth={2}
              />
            </FloatBtn>
            <FloatBtn onClick={() => onToggleSave(p.id)}>
              <Bookmark
                size={15}
                color={T.white}
                fill={saved ? T.white : "none"}
                strokeWidth={2}
              />
            </FloatBtn>
          </div>
        </div>

        {/* Info column */}
        <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", minHeight: 0 }}>
          {panelInner}
        </div>
      </div>

      {photoViewer}
    </div>
  );

  return createPortal(isDesktop ? desktopOverlay : mobileOverlay, document.body);
}