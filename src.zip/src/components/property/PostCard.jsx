import { memo, useState, useRef, useEffect, useCallback, useMemo } from "react";
import { MapPin, Bookmark, Link as LinkIcon, Check, X, Clock3, MessageCircle } from "lucide-react";
import { T } from "../../styles/tokens";
import Avatar from "../common/Avatar";
import VerifiedBadge from "../common/VerifiedBadge";
import PhotoCarousel from "../common/PhotoCarousel";
import PriceTag from "../common/PriceTag";
import { interestCount, photosFor } from "../../utils/propertyHelpers";
import { formatDaysAgo } from "../../utils/formatters";

// Helper: find all scrollable ancestors of an element
function getScrollableAncestors(element) {
  const ancestors = [];
  let current = element?.parentElement;
  while (current && current !== document.body) {
    const style = window.getComputedStyle(current);
    const overflowY = style.overflowY;
    if (
      (overflowY === 'auto' || overflowY === 'scroll') &&
      current.scrollHeight > current.clientHeight
    ) {
      ancestors.push(current);
    }
    current = current.parentElement;
  }
  const docEl = document.documentElement;
  const body = document.body;
  if (docEl.scrollHeight > window.innerHeight) {
    ancestors.push(docEl);
  }
  if (body.scrollHeight > window.innerHeight) {
    ancestors.push(body);
  }
  return ancestors;
}

// Same robust listing verification check used in ListerProfile
const isListingVerified = (p) =>
  p?.verification === "verified" || p?.verified === true || p?.verificationStatus === "verified";

// Fires a short, light haptic buzz the instant the button is tapped.
const triggerHaptic = () => {
  if (typeof navigator !== "undefined" && typeof navigator.vibrate === "function") {
    navigator.vibrate(15);
  }
};

// Updated stylesheet: pulse animation for the bookmark icon
const LIKE_ANIM_STYLES = `
@keyframes interestPulse {
  0% { transform: scale(1); }
  30% { transform: scale(1.35); }
  60% { transform: scale(0.9); }
  100% { transform: scale(1); }
}
.interest-pulse {
  animation: interestPulse 0.5s cubic-bezier(0.34, 1.56, 0.64, 1);
}
@keyframes interestTextFloat {
  0% { opacity: 0; transform: translateY(3px); }
  15% { opacity: 1; transform: translateY(0); }
  80% { opacity: 1; transform: translateY(0); }
  100% { opacity: 0; transform: translateY(-4px); }
}
.interest-toast-text {
  animation: interestTextFloat 1.6s ease forwards;
  white-space: nowrap;
}
`;

const PostCard = memo(function PostCard({
  p,
  index,
  liked,
  saved,
  onToggleLike,
  onToggleSave,
  onOpen,
  onOpenLister,
  viewingRequested,
  onRequestViewing,
  onSend,
  onOpenMessage,
  showDistance = true,
  hideCard = false,
  autoOpen = false,
  scrollLockElement = null,
  onSheetClose,
  compactDesktop = false,
}) {
  const [burst, setBurst] = useState(0);
  const [burstAction, setBurstAction] = useState("added"); // "added" or "removed"
  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const [sentFlash, setSentFlash] = useState(false);
  const sentTimerRef = useRef(null);

  const [likeAnim, setLikeAnim] = useState(false);
  const likeAnimTimerRef = useRef(null);

  const [linkPressed, setLinkPressed] = useState(false);
  const [linkMorphed, setLinkMorphed] = useState(false);
  const [toastVisible, setToastVisible] = useState(false);
  const [toastText, setToastText] = useState("");
  const morphTimerRef = useRef(null);
  const toastTimerRef = useRef(null);

  const photos = useMemo(() => {
    if (Array.isArray(p?.images) && p.images.length > 0) return p.images;
    return photosFor(p?.id);
  }, [p?.images, p?.id]);
  const lastTapRef = useRef(0);
  const cardRef = useRef(null);

  const onSheetCloseRef = useRef(onSheetClose);
  useEffect(() => {
    onSheetCloseRef.current = onSheetClose;
  }, [onSheetClose]);

  // Lock scroll when popup open
  useEffect(() => {
    if (!isSheetOpen) return;
    const baseEl = scrollLockElement || cardRef.current;
    const scrollableAncestors = getScrollableAncestors(baseEl);
    const originalOverflows = scrollableAncestors.map((el) => ({
      el,
      overflow: el.style.overflow,
      overflowY: el.style.overflowY,
    }));
    scrollableAncestors.forEach((el) => {
      el.style.overflow = 'hidden';
      el.style.overflowY = 'hidden';
    });
    return () => {
      originalOverflows.forEach(({ el, overflow, overflowY }) => {
        el.style.overflow = overflow;
        el.style.overflowY = overflowY;
      });
    };
  }, [isSheetOpen, scrollLockElement]);

  // Cleanup timers
  useEffect(() => {
    return () => {
      if (sentTimerRef.current) clearTimeout(sentTimerRef.current);
      if (morphTimerRef.current) clearTimeout(morphTimerRef.current);
      if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
      if (likeAnimTimerRef.current) clearTimeout(likeAnimTimerRef.current);
    };
  }, []);

  const openSheet = useCallback(() => setIsSheetOpen(true), []);

  useEffect(() => {
    if (autoOpen) openSheet();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const closeSheet = useCallback((afterClose) => {
    setIsSheetOpen(false);
    afterClose?.();
    onSheetCloseRef.current?.();
  }, []);

  const triggerLike = useCallback(() => {
    const wasLiked = liked;
    onToggleLike(p?.id);

    // Determine action for photo burst and label
    setBurstAction(wasLiked ? "removed" : "added");

    // Trigger pulse animation
    setLikeAnim(true);
    if (likeAnimTimerRef.current) clearTimeout(likeAnimTimerRef.current);
    likeAnimTimerRef.current = setTimeout(() => setLikeAnim(false), 1600);

    // Trigger photo carousel burst
    setBurst(Date.now());
  }, [liked, onToggleLike, p?.id]);

  const handleLinkTap = useCallback(() => {
    triggerHaptic();
    const wasSaved = saved;
    onToggleSave(p?.id);

    if (morphTimerRef.current) clearTimeout(morphTimerRef.current);
    if (!wasSaved) {
      setLinkMorphed(true);
      morphTimerRef.current = setTimeout(() => {
        setLinkMorphed(false);
      }, 2000);
    } else {
      setLinkMorphed(false);
    }

    setToastText(
      !wasSaved
        ? "Got it! We'll show you more like this."
        : "Removed from your saved list."
    );
    setToastVisible(true);
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    toastTimerRef.current = setTimeout(() => {
      setToastVisible(false);
    }, 3000);
  }, [onToggleSave, p?.id, saved]);

  const handlePhotoTap = useCallback(() => {
    const now = Date.now();
    if (now - lastTapRef.current < 300) {
      lastTapRef.current = 0;
      triggerLike();
    } else {
      lastTapRef.current = now;
    }
  }, [triggerLike]);

  const handleRequestViewing = useCallback(() => {
    if (viewingRequested || sentFlash) return;
    setSentFlash(true);
    if (typeof onSend === "function") {
      onSend(p.id, "I would like to request a viewing.");
    }
    if (typeof onRequestViewing === "function") {
      onRequestViewing();
    }
    if (sentTimerRef.current) clearTimeout(sentTimerRef.current);
    sentTimerRef.current = setTimeout(() => setSentFlash(false), 1800);
  }, [onRequestViewing, onSend, p.id, sentFlash, viewingRequested]);

  const handleOpenLister = useCallback((e) => {
    e.stopPropagation();
    if (typeof onOpenLister === "function") {
      onOpenLister({
        id: p.landlordRegistrationId ?? p.id,
        name: p.landlord,
        grad: p.grad,
        verified: p.landlordVerified,
        verificationStatus:
          p.landlordVerificationStatus ||
          (p.landlordVerified === true ? "verified" :
           p.landlordVerified === false ? "pending" : undefined),
        verification:
          p.landlordVerification ||
          (p.landlordVerified === true ? "verified" :
           p.landlordVerified === false ? "pending" : undefined),
      });
    } else {
      onOpen(p);
    }
  }, [onOpen, onOpenLister, p]);

  if (!p) return null;

  const listingVerified = isListingVerified(p);
  const linkButtonScale = linkPressed ? 0.9 : 1.1;
  const linkIconColor = saved ? T.jacaranda : T.ink;

  // No more ring; pulse class is applied directly to Bookmark when likeAnim is true

  return (
    <>
      <style>{LIKE_ANIM_STYLES}</style>

      {!hideCard && (
        <div
          ref={cardRef}
          className={`rise ${compactDesktop ? "post-card-compact" : ""}`}
          style={{
            background: T.paper,
            animationDelay: `${index * 40}ms`,
            borderBottom: `1px solid ${T.line}`,
          }}
        >
          {/* Header */}
          <div className={`flex items-center justify-between ${compactDesktop ? "px-3 py-1.5" : "px-3.5 py-2"}`}>
            <div className="flex items-center gap-2 min-w-0 cursor-pointer" onClick={handleOpenLister}>
              <Avatar grad={p.grad || ''} letter={(p.landlord?.[0] || '?')} ring={p.postedDaysAgo <= 1} />
              <div className="min-w-0 leading-tight">
                <span className="f-body font-semibold truncate block" style={{ color: T.ink, fontSize: compactDesktop ? 12 : 13 }}>
                  {p.landlord || ''}
                </span>
                <div className="flex items-center gap-1 f-body mt-0.5" style={{ color: T.ink60, fontSize: 11 }}>
                  <MapPin size={10} />
                  {p.suburb || ''}
                  {showDistance && <span> · {p.distanceKm} km</span>}
                </div>
              </div>
            </div>
            <div className="flex flex-col items-end gap-1">
              <span className="f-body" style={{ color: T.ink60, fontSize: 11 }}>
                {formatDaysAgo(p.postedDaysAgo || 0)}
              </span>
              <VerifiedBadge status={listingVerified ? "verified" : "pending"} />
            </div>
          </div>

          {/* Photo carousel */}
          <div
            className="select-none"
            onClick={(e) => {
              handlePhotoTap();
              openSheet();
            }}
            style={{ touchAction: "manipulation", cursor: "pointer" }}
          >
            <PhotoCarousel
              height={compactDesktop ? 220 : 380}
              photos={photos}
              priceTag={<PriceTag rent={p.rent || ''} onClick={openSheet} />}
              burstKey={burst}
              burstAction={burstAction}
              burstLabel={burstAction === "removed" ? "Removed from interested" : "Added to interested"}
            />
          </div>

          {/* Actions & description */}
          <div className={compactDesktop ? "px-3 pt-1.5 pb-2" : "px-3.5 pt-2 pb-3.5"}>
            {p.title && (
              <div className={`f-body font-semibold ${compactDesktop ? "mb-1" : "mb-2"}`} style={{ color: T.ink, fontSize: 13 }}>
                {p.title}
              </div>
            )}

            <div className="flex items-center justify-between">
              <div className="relative flex items-center gap-2">
                <button
                  onClick={triggerLike}
                  className="relative active:scale-90 transition-transform"
                  style={{ overflow: "visible" }}
                  aria-label={liked ? "Remove interest" : "Mark interested"}
                >
                  <Bookmark
                    size={compactDesktop ? 20 : 23}
                    color={liked ? T.msasa : T.ink}
                    fill={liked ? T.msasa : "none"}
                    strokeWidth={1.8}
                    className={likeAnim ? "interest-pulse" : ""}
                  />
                </button>
                <span className="f-body font-semibold" style={{ color: T.ink, fontSize: compactDesktop ? 11 : 12 }}>
                  {(interestCount(p?.id) || 0) + (liked ? 1 : 0)} interested
                </span>
              </div>

              {/* Link icon (save link) */}
              <button
                onClick={handleLinkTap}
                onPointerDown={() => setLinkPressed(true)}
                onPointerUp={() => setLinkPressed(false)}
                onPointerLeave={() => setLinkPressed(false)}
                onPointerCancel={() => setLinkPressed(false)}
                className="relative flex items-center justify-center"
                style={{ WebkitTapHighlightColor: "transparent", touchAction: "manipulation" }}
                aria-label={saved ? "Remove saved link" : "Copy link"}
              >
                <span
                  style={{
                    display: "inline-flex",
                    transform: `scale(${linkButtonScale})`,
                    transition: "transform 0.18s cubic-bezier(0.34, 1.56, 0.64, 1)",
                  }}
                >
                  {linkMorphed ? (
                    <Check key="check" size={compactDesktop ? 19 : 21} color={T.msasa} strokeWidth={2.4} className="pop" />
                  ) : (
                    <LinkIcon key="link" size={compactDesktop ? 19 : 21} color={linkIconColor} strokeWidth={1.8} />
                  )}
                </span>
              </button>
            </div>

            {/* Tags */}
            <div className={`flex flex-wrap ${compactDesktop ? "gap-1 mt-1.5" : "gap-1.5 mt-2"}`}>
              <span className="f-body font-medium px-2.5 py-1 rounded-full" style={{ background: T.paperDim, color: T.ink60, fontSize: compactDesktop ? 9.5 : 10.5 }}>
                {p.type}
              </span>
              <span className="f-body font-medium px-2.5 py-1 rounded-full" style={{ background: T.paperDim, color: T.ink60, fontSize: compactDesktop ? 9.5 : 10.5 }}>
                {p.bathroom} bathroom
              </span>
              {p.furnished && (
                <span className="f-body font-medium px-2.5 py-1 rounded-full" style={{ background: "rgba(47,122,85,0.12)", color: T.msasa, fontSize: compactDesktop ? 9.5 : 10.5 }}>
                  Furnished
                </span>
              )}
              {p.parking && (
                <span className="f-body font-medium px-2.5 py-1 rounded-full" style={{ background: T.paperDim, color: T.ink60, fontSize: compactDesktop ? 9.5 : 10.5 }}>
                  Parking
                </span>
              )}
            </div>

            {/* Action buttons */}
            <div className={`flex items-center gap-2 ${compactDesktop ? "mt-2" : "mt-3"}`}>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  if (viewingRequested) {
                    if (typeof onOpenMessage === "function") onOpenMessage(p.id);
                  } else {
                    handleRequestViewing();
                  }
                }}
                disabled={sentFlash}
                className="flex-1 flex items-center justify-center gap-1.5 f-body font-semibold rounded-full active:scale-95 transition-transform"
                style={{
                  background: viewingRequested || sentFlash ? T.msasa : T.brick,
                  color: T.paper,
                  fontSize: compactDesktop ? 10.5 : 12.5,
                  paddingTop: compactDesktop ? 7 : 10,
                  paddingBottom: compactDesktop ? 7 : 10,
                  opacity: sentFlash ? 0.9 : 1,
                  boxShadow: viewingRequested || sentFlash ? "none" : `0 6px 16px -4px ${T.brick}66`,
                }}
              >
                {sentFlash ? (
                  <><Check size={14} /> Message sent</>
                ) : viewingRequested ? (
                  <><MessageCircle size={14} /> Open chat</>
                ) : (
                  <><Clock3 size={14} strokeWidth={2} /> Request a viewing</>
                )}
              </button>
              <button
                onClick={openSheet}
                className="flex items-center justify-center f-body font-semibold rounded-full active:scale-95 transition-transform"
                style={{ background: T.paperDim, color: T.ink, fontSize: compactDesktop ? 10.5 : 12.5, paddingTop: compactDesktop ? 7 : 10, paddingBottom: compactDesktop ? 7 : 10, paddingLeft: compactDesktop ? 11 : 16, paddingRight: compactDesktop ? 11 : 16, border: `1px solid ${T.line}` }}
              >
                Details
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Details popup */}
      {isSheetOpen && (
        <div
          className="fixed inset-0 z-[1000] flex items-end md:items-center md:justify-center fade"
          onClick={(e) => { if (e.target === e.currentTarget) closeSheet(); }}
          style={{ background: "rgba(20,32,26,0.55)", backdropFilter: "blur(3px)", WebkitBackdropFilter: "blur(3px)" }}
        >
          <div
            className="w-full md:max-w-lg rise noscroll"
            style={{
              background: T.paper,
              maxHeight: "88vh",
              overflowY: "auto",
              borderTopLeftRadius: 28,
              borderTopRightRadius: 28,
              boxShadow: "0 -10px 40px rgba(0,0,0,0.18)",
              position: "relative",
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => closeSheet()}
              aria-label="Close details"
              className="absolute top-3 right-3 flex items-center justify-center rounded-full z-10"
              style={{ width: 36, height: 36, border: `1px solid ${T.line}`, background: T.paperDim, color: T.ink, cursor: "pointer" }}
            >
              <X size={19} />
            </button>

            <div className="p-5 space-y-4">
              {/* Title & location */}
              <div className="flex items-start justify-between pr-12">
                <div>
                  <h3 className="text-lg font-bold" style={{ color: T.ink }}>{p.title || ''}</h3>
                  <div className="flex items-center gap-1 text-sm" style={{ color: T.ink60 }}>
                    <MapPin size={14} />
                    {p.suburb || ''}
                    {showDistance && <span> · {p.distanceKm} km</span>}
                  </div>
                </div>
              </div>

              {/* Price */}
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-bold" style={{ color: T.brick }}>${p.rent || ''}</span>
                <span className="text-sm" style={{ color: T.ink60 }}>/ month</span>
              </div>

              {/* Lister info */}
              <div className="flex items-center gap-2 cursor-pointer" onClick={handleOpenLister}>
                <Avatar grad={p.grad || ''} letter={(p.landlord?.[0] || '?')} ring={p.postedDaysAgo <= 1} />
                <div className="min-w-0 leading-tight">
                  <div className="flex items-center gap-1">
                    <span className="text-sm font-semibold truncate" style={{ color: T.ink }}>{p.landlord || ''}</span>
                    <VerifiedBadge status={listingVerified ? "verified" : "pending"} />
                  </div>
                  <span className="text-xs" style={{ color: T.ink60 }}>Posted {formatDaysAgo(p.postedDaysAgo || 0)}</span>
                </div>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 rounded-full text-xs" style={{ background: T.paperDim, color: T.ink60 }}>{p.type}</span>
                <span className="px-3 py-1 rounded-full text-xs" style={{ background: T.paperDim, color: T.ink60 }}>{p.bathroom} bathroom</span>
                {p.furnished && (
                  <span className="px-3 py-1 rounded-full text-xs" style={{ background: "rgba(47,122,85,0.12)", color: T.msasa }}>Furnished</span>
                )}
                {p.parking && (
                  <span className="px-3 py-1 rounded-full text-xs" style={{ background: T.paperDim, color: T.ink60 }}>Parking</span>
                )}
              </div>

              {/* Description */}
              {(p.desc || p.title) && (
                <div className="rounded-xl px-3 py-2.5" style={{ background: T.paperDim }}>
                  {p.title && (
                    <div className="f-body font-semibold mb-0.5" style={{ color: T.ink, fontSize: 13 }}>{p.title}</div>
                  )}
                  <p className="f-body leading-relaxed" style={{ color: T.ink60, fontSize: 12.5 }}>{p.desc || ''}</p>
                </div>
              )}

              {/* Bookmark + link actions */}
              <div className="flex items-center justify-between pt-2 border-t" style={{ borderColor: T.line }}>
                <div className="relative flex items-center gap-2">
                  <span className="relative inline-flex" style={{ overflow: "visible" }}>
                    <Bookmark
                      size={24}
                      color={liked ? T.msasa : T.ink60}
                      fill={liked ? T.msasa : "none"}
                      strokeWidth={1.8}
                      onClick={(e) => {
                        e.stopPropagation();
                        triggerLike();
                      }}
                      className={`cursor-pointer active:scale-90 ${likeAnim ? "interest-pulse" : ""}`}
                    />
                  </span>
                  <span className="text-sm" style={{ color: T.ink60 }}>
                    {(interestCount(p?.id) || 0) + (liked ? 1 : 0)} interested
                  </span>
                  {likeAnim && (
                    <div
                      className="interest-toast-text absolute left-0"
                      style={{
                        top: "100%",
                        marginTop: 3,
                        color: liked ? T.msasa : T.brick,
                        fontSize: 11,
                        fontWeight: 600,
                      }}
                    >
                      {liked ? "Added to interested" : "Removed from interested"}
                    </div>
                  )}
                </div>

                {/* Link button */}
                <button
                  onClick={(e) => { e.stopPropagation(); handleLinkTap(); }}
                  onPointerDown={() => setLinkPressed(true)}
                  onPointerUp={() => setLinkPressed(false)}
                  onPointerLeave={() => setLinkPressed(false)}
                  onPointerCancel={() => setLinkPressed(false)}
                  className="relative flex items-center justify-center"
                  style={{ WebkitTapHighlightColor: "transparent", touchAction: "manipulation" }}
                  aria-label={saved ? "Remove saved link" : "Copy link"}
                >
                  <span
                    style={{
                      display: "inline-flex",
                      transform: `scale(${linkButtonScale})`,
                      transition: "transform 0.18s cubic-bezier(0.34, 1.56, 0.64, 1)",
                    }}
                  >
                    {linkMorphed ? (
                      <Check key="check" size={22} color={T.msasa} strokeWidth={2.4} className="pop" />
                    ) : (
                      <LinkIcon key="link" size={22} color={linkIconColor} strokeWidth={1.8} />
                    )}
                  </span>
                </button>
              </div>

              {/* Bottom buttons */}
              <div className="flex gap-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (viewingRequested) {
                      if (typeof onOpenMessage === "function") onOpenMessage(p.id);
                    } else {
                      handleRequestViewing();
                    }
                  }}
                  disabled={sentFlash}
                  className="flex-1 flex items-center justify-center gap-2 py-3 rounded-full font-semibold active:scale-95 transition"
                  style={{
                    background: viewingRequested || sentFlash ? T.msasa : T.brick,
                    color: T.paper,
                    fontSize: 14,
                    boxShadow: viewingRequested || sentFlash ? "none" : `0 6px 16px -4px ${T.brick}66`,
                  }}
                >
                  {sentFlash ? (
                    <><Check size={16} /> Message sent</>
                  ) : viewingRequested ? (
                    <><MessageCircle size={16} /> Open chat</>
                  ) : (
                    <><Clock3 size={16} strokeWidth={2} /> Request a viewing</>
                  )}
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); closeSheet(() => onOpen(p)); }}
                  className="flex-1 flex items-center justify-center gap-2 py-3 rounded-full font-semibold active:scale-95 transition"
                  style={{ background: T.paperDim, color: T.ink, fontSize: 14, border: `1px solid ${T.line}` }}
                >
                  View full details
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      {toastVisible && (
        <div
          className="fixed left-1/2 z-[1100] fade"
          style={{
            bottom: "calc(env(safe-area-inset-bottom, 0px) + 24px)",
            transform: "translateX(-50%)",
            pointerEvents: "none",
          }}
        >
          <div
            className="rise flex items-center gap-2 px-4 py-2.5 rounded-full"
            style={{
              background: "rgba(20,32,26,0.92)",
              color: T.paper,
              fontSize: 12.5,
              fontWeight: 600,
              boxShadow: "0 8px 24px rgba(0,0,0,0.24)",
              whiteSpace: "nowrap",
            }}
          >
            {toastText}
          </div>
        </div>
      )}
    </>
  );
});

export default PostCard;