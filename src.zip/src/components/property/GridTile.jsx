import { T } from "../../styles/tokens";
import VerifiedBadge from "../common/VerifiedBadge";
import { photosFor } from "../../utils/propertyHelpers";

export default function GridTile({ p, onOpen, onSuburbClick, activeSuburb, compactDesktop = false }) {
  const photos = photosFor(p.id);
  const isSuburbActive = activeSuburb && activeSuburb === p.suburb;

  return (
    <button
      onClick={() => onOpen(p)}
      className="rise text-left rounded-2xl overflow-hidden active:scale-95 transition-transform"
      style={{
        background: T.paper,
        border: `1px solid ${T.line}`,
      }}
    >
      <div
        className="relative overflow-hidden"
        style={{ background: T.paperDim, aspectRatio: compactDesktop ? "4 / 3" : "4 / 5" }}
      >
        <img
          src={photos[0]}
          alt=""
          className="w-full h-full object-cover"
          draggable={false}
        />
        <div className="absolute top-2 right-2">
          <VerifiedBadge status={p.verification} />
        </div>
        <div className="absolute bottom-2 left-2 right-2 flex items-end justify-between gap-1">
          <span
            className="f-mono font-semibold px-2 py-1 rounded-full shrink-0"
            style={{
              background: "rgba(20,32,26,0.82)",
              color: T.white,
              fontSize: 11,
            }}
          >
            ${p.rent}
            <span className="opacity-70">/mo</span>
          </span>

          {/* Suburb pill – now purple when active */}
          <span
            onClick={(e) => {
              e.stopPropagation();
              if (onSuburbClick) {
                onSuburbClick(p.suburb);
              } else {
                onOpen(p);
              }
            }}
            className="f-body truncate px-2 py-1 rounded-full cursor-pointer"
            style={{
              background: isSuburbActive
                ? T.jacaranda
                : "rgba(251,248,240,0.92)",
              color: isSuburbActive ? T.paper : T.ink,
              fontSize: 9.5,
              transition: "background 0.2s ease",
            }}
          >
            {p.suburb}
          </span>
        </div>
      </div>
      <div className="px-2.5 pt-2 pb-2.5">
        <div
          className="f-body font-semibold truncate"
          style={{ color: T.ink, fontSize: 12 }}
        >
          {p.title}
        </div>
        <div
          className="f-body mt-0.5 truncate"
          style={{ color: T.ink60, fontSize: 10.5 }}
        >
          {p.type} · {p.rooms}rm · {p.bathroom}
        </div>
      </div>
    </button>
  );
}