import { useState } from "react";
import { UserRound, Phone, ArrowRight, CheckCircle2, LogIn, Briefcase, KeyRound } from "lucide-react";
import { T } from "../../styles/tokens";
import { useAuth } from "../../auth/AuthContext"; // adjust path

export default function UserOnboarding() {
  const { signIn, logIn, logInWithCredentials, loading } = useAuth();

  const [accountKind, setAccountKind] = useState("general"); // "general" | "business"
  const [mode, setMode] = useState("register"); // "register" | "login" (general only)
  const [form, setForm] = useState({
    firstName: "",
    surname: "",
    phone: "",
    username: "",
    password: "",
  });
  const [error, setError] = useState("");

  const update = (key, value) =>
    setForm((current) => ({ ...current, [key]: value }));

  const switchMode = (nextMode) => {
    setMode(nextMode);
    setError("");
  };

  const switchAccountKind = (nextKind) => {
    setAccountKind(nextKind);
    setError("");
  };

  const submitRegister = async () => {
    const firstName = form.firstName.trim();
    const surname = form.surname.trim();
    const phone = form.phone.trim();

    if (!firstName || !surname || !phone) {
      setError("Fill in your first name, surname and phone number to continue.");
      return;
    }

    if (phone.replace(/\D/g, "").length < 7) {
      setError("That phone number doesn't look right — please double-check it.");
      return;
    }

    setError("");

    try {
      await signIn({ firstName, surname, phone });
    } catch {
      setError("Something went wrong saving your profile. Please try again.");
    }
  };

  const submitLogin = async () => {
    const phone = form.phone.trim();

    if (!phone) {
      setError("Enter the phone number you registered with.");
      return;
    }

    if (phone.replace(/\D/g, "").length < 7) {
      setError("That phone number doesn't look right — please double-check it.");
      return;
    }

    setError("");

    try {
      await logIn(phone);
    } catch {
      setError("We couldn't find an account with that number on this device. Try registering instead.");
    }
  };

  const submitBusinessLogin = async () => {
    const username = form.username.trim();
    const password = form.password;

    if (!username || !password) {
      setError("Enter your username and password to continue.");
      return;
    }

    setError("");

    try {
      await logInWithCredentials(username, password);
    } catch {
      setError(
        "We couldn't find a pro, agent, landlord or company account with those details on this device."
      );
    }
  };

  const submit = (event) => {
    event.preventDefault();
    if (accountKind === "business") {
      submitBusinessLogin();
    } else if (mode === "register") {
      submitRegister();
    } else {
      submitLogin();
    }
  };

  const input = "w-full rounded-xl px-3 py-3 f-body outline-none";
  const style = {
    background: T.paperDim,
    color: T.ink,
    border: `1px solid ${T.line}`,
    fontSize: 16,
  };

  const isLogin = mode === "login";
  const isBusiness = accountKind === "business";

  return (
    <div
      // fixed (not absolute) so the overlay always pins to the viewport instead of
      // stretching to match a tall/scrollable ancestor — that mismatch was what
      // made everything look stretched. overflow-y-auto lets the backdrop itself
      // scroll if the card is ever taller than the viewport (small screens).
      className="fixed inset-0 z-50 flex items-center justify-center p-5 overflow-y-auto"
      style={{ background: T.ink }}
    >
      <style>{`
        @keyframes wave-gesture {
          0%, 60%, 100% { transform: rotate(0deg); }
          10% { transform: rotate(14deg); }
          20% { transform: rotate(-8deg); }
          30% { transform: rotate(14deg); }
          40% { transform: rotate(-4deg); }
          50% { transform: rotate(10deg); }
        }
        .wave-emoji {
          display: inline-block;
          transform-origin: 70% 70%;
          animation: wave-gesture 2.2s ease-in-out 0.3s 1;
        }
      `}</style>
      <form
        onSubmit={submit}
        className="w-full rounded-3xl p-5 rise"
        style={{
          background: T.paper,
          // constrain the card so it doesn't stretch edge-to-edge on wide/web viewports
          maxWidth: 420,
          maxHeight: "90vh",
          overflowY: "auto",
          margin: "auto",
        }}
      >
        {/* Header */}
        <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-4" style={{ background: T.ink }}>
          {isBusiness ? (
            <Briefcase size={25} color={T.paper} />
          ) : isLogin ? (
            <LogIn size={25} color={T.paper} />
          ) : (
            <UserRound size={25} color={T.paper} />
          )}
        </div>

        {isBusiness ? (
          <div className="f-display" style={{ color: T.ink, fontSize: 23, lineHeight: 1.15 }}>
            <span className="font-bold" style={{ fontWeight: 800 }}>Pro</span>{" "}
            <span className="font-bold" style={{ fontWeight: 800, color: T.brick }}>sign in</span>
          </div>
        ) : isLogin ? (
          <div className="f-display" style={{ color: T.ink, fontSize: 23, lineHeight: 1.15 }}>
            <span className="font-bold" style={{ fontWeight: 800 }}>Welcome</span>{" "}
            <span className="font-bold" style={{ fontWeight: 800, color: T.brick }}>back</span>
          </div>
        ) : (
          <div className="f-display" style={{ color: T.ink, fontSize: 23, lineHeight: 1.15 }}>
            <span className="font-bold" style={{ fontWeight: 800 }}>Welcome</span>{" "}
            <span className="wave-emoji" style={{ fontSize: 20 }}>👋</span>
            <br/>
            <span className="font-bold" style={{ fontWeight: 800, color: T.brick }}>to ImbaLink</span>
          </div>
        )}

        <div className="f-body mt-2 leading-relaxed" style={{ color: T.ink60, fontSize: 11.5 }}>
          {isBusiness
            ? "Sign in to your pro, agent, landlord or company account with the username and password you set during registration."
            : isLogin
            ? "Enter the phone number linked to your profile on this device to sign back in."
            : "Let's get you set up. A few quick details create your profile — you can always add landlord or contractor details later."}
        </div>

        {/* Account kind toggle */}
        <div className="flex gap-1.5 mt-4 p-1 rounded-full" style={{ background: T.paperDim }}>
          <button
            type="button"
            onClick={() => switchAccountKind("general")}
            className="flex-1 py-2 rounded-full f-body font-semibold"
            style={{
              background: !isBusiness ? T.ink : "transparent",
              color: !isBusiness ? T.paper : T.ink60,
              fontSize: 10.5,
            }}
          >
            General user
          </button>
          <button
            type="button"
            onClick={() => switchAccountKind("business")}
            className="flex-1 py-2 rounded-full f-body font-semibold"
            style={{
              background: isBusiness ? T.ink : "transparent",
              color: isBusiness ? T.paper : T.ink60,
              fontSize: 10.5,
            }}
          >
            Pro / Agent / Landlord / Company
          </button>
        </div>

        {/* Form */}
        <div className="space-y-3 mt-5">
          {isBusiness ? (
            <>
              <label className="block">
                <span className="f-body font-semibold block mb-1.5" style={{ color: T.ink60, fontSize: 10 }}>
                  USERNAME *
                </span>
                <input
                  autoFocus
                  name="username"
                  className={input}
                  style={style}
                  value={form.username}
                  onChange={(e) => update("username", e.target.value)}
                  placeholder="Your business login username"
                  autoComplete="username"
                />
              </label>

              <label className="block">
                <span className="f-body font-semibold block mb-1.5" style={{ color: T.ink60, fontSize: 10 }}>
                  PASSWORD *
                </span>
                <div className="relative">
                  <KeyRound
                    size={15}
                    className="absolute left-3 top-1/2 -translate-y-1/2"
                    style={{ color: T.ink60 }}
                  />
                  <input
                    type="password"
                    name="password"
                    className={`${input} pl-9`}
                    style={style}
                    value={form.password}
                    onChange={(e) => update("password", e.target.value)}
                    placeholder="Your password"
                    autoComplete="current-password"
                  />
                </div>
              </label>
            </>
          ) : (
            <>
              {!isLogin && (
                <>
                  <label className="block">
                    <span className="f-body font-semibold block mb-1.5" style={{ color: T.ink60, fontSize: 10 }}>
                      FIRST NAME *
                    </span>
                    <input
                      autoFocus
                      name="firstName"
                      className={input}
                      style={style}
                      value={form.firstName}
                      onChange={(e) => update("firstName", e.target.value)}
                      placeholder="e.g. Tinashe"
                      autoComplete="given-name"
                    />
                  </label>

                  <label className="block">
                    <span className="f-body font-semibold block mb-1.5" style={{ color: T.ink60, fontSize: 10 }}>
                      SURNAME *
                    </span>
                    <input
                      name="surname"
                      className={input}
                      style={style}
                      value={form.surname}
                      onChange={(e) => update("surname", e.target.value)}
                      placeholder="e.g. Moyo"
                      autoComplete="family-name"
                    />
                  </label>
                </>
              )}

              <label className="block">
                <span className="f-body font-semibold block mb-1.5" style={{ color: T.ink60, fontSize: 10 }}>
                  PHONE NUMBER *
                </span>
                <div className="relative">
                  <Phone
                    size={15}
                    className="absolute left-3 top-1/2 -translate-y-1/2"
                    style={{ color: T.ink60 }}
                  />
                  <input
                    type="tel"
                    name="phone"
                    autoFocus={isLogin}
                    className={`${input} pl-9`}
                    style={style}
                    value={form.phone}
                    onChange={(e) => update("phone", e.target.value)}
                    placeholder="+263 7X XXX XXXX"
                    autoComplete="tel"
                  />
                </div>
              </label>
            </>
          )}
        </div>

        {/* Error */}
        {error && (
          <div
            className="mt-3 rounded-xl p-3 f-body"
            style={{ background: "rgba(184,61,49,.1)", color: T.brick, fontSize: 10.5 }}
          >
            {error}
          </div>
        )}

        {/* Info */}
        {isBusiness ? (
          <div className="flex items-start gap-2 mt-5" style={{ color: T.ink60 }}>
            <CheckCircle2 size={15} style={{ color: T.msasa, flexShrink: 0 }} />
            <span className="f-body" style={{ fontSize: 10.5 }}>
              New pro, agent, landlord or company account? Sign in as a general user with your phone first, then register from your profile.
            </span>
          </div>
        ) : !isLogin ? (
          <div className="flex items-start gap-2 mt-5" style={{ color: T.ink60 }}>
            <CheckCircle2 size={15} style={{ color: T.msasa, flexShrink: 0 }} />
            <span className="f-body" style={{ fontSize: 10.5 }}>
              Your details are stored securely, and you'll stay signed in on this device.
            </span>
          </div>
        ) : null}

        {/* Submit */}
        <button
          type="submit"
          disabled={loading}
          className="w-full mt-5 py-3.5 rounded-full f-display font-semibold flex items-center justify-center gap-2 disabled:opacity-60"
          style={{ background: T.brick, color: T.paper, fontSize: 12 }}
        >
          {loading
            ? (isBusiness ? "Signing you in…" : isLogin ? "Signing you in…" : "Setting up your profile…")
            : (isBusiness ? "Log in" : isLogin ? "Log in" : "Get started")}
          {!loading && <ArrowRight size={15} />}
        </button>

        {/* Mode toggle (general users only) */}
        {!isBusiness && (
          <button
            type="button"
            onClick={() => switchMode(isLogin ? "register" : "login")}
            className="w-full mt-3 py-2 f-body text-center"
            style={{ color: T.ink60, fontSize: 11 }}
          >
            {isLogin ? (
              <>Don't have a profile yet? <span style={{ color: T.brick, fontWeight: 600 }}>Register</span></>
            ) : (
              <>Already registered? <span style={{ color: T.brick, fontWeight: 600 }}>Log in</span></>
            )}
          </button>
        )}
      </form>
    </div>
  );
}
