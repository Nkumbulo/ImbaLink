import { T } from "../../styles/tokens";
export default function StatusBar({ city, onCityClick }){
  return (<div className="f-mono flex items-center justify-between px-5 pt-3 pb-1" style={{color:T.paper,fontSize:11}}><span>9:41</span><button onClick={onCityClick} className="tracking-widest opacity-80 active:scale-95 transition-transform" style={{background:"transparent",border:"none",color:"inherit",font:"inherit",cursor:"pointer"}}>{city?.toUpperCase()}</button><span>••••</span></div>);
}
