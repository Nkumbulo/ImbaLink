import { T } from "../../styles/tokens";
export default function AmenityChip({ icon: Icon, text }){
  return (<div className="flex items-center gap-2 pl-1.5 pr-3 py-1.5 rounded-full f-body font-medium" style={{background:T.paperDim,color:T.ink,fontSize:11}}>
    <span className="flex items-center justify-center rounded-full shrink-0" style={{width:22,height:22,background:T.white}}><Icon size={12} style={{color:T.jacarandaDeep}}/></span>{text}</div>);
}
