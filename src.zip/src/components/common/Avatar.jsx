import { T, GRADIENT } from "../../styles/tokens";
export default function Avatar({ grad, letter, size = 34, ring }){
  return (<div className="rounded-full shrink-0 flex items-center justify-center f-display font-semibold" style={{width:size,height:size,padding:ring?2:0,background:ring?GRADIENT:"transparent"}}>
    <div className="rounded-full w-full h-full flex items-center justify-center" style={{background:`linear-gradient(135deg, ${grad[0]}, ${grad[1]})`,border:ring?`2px solid ${T.paper}`:"none"}}>
      <span style={{color:T.paper,fontSize:size*0.36}}>{letter}</span>
    </div></div>);
}
