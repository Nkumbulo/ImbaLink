import { useState, useEffect, useCallback, useRef } from "react";
import { db } from "../services/database";

export default function useDatabase({
  city = "All",
  filters = {},
  query = "",
  limit = 500,
  userId = null, // the currently signed-in account's id (null when signed out)
} = {}) {
  const [loaded, setLoaded] = useState(false);
  const [properties, setProperties] = useState([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);

  const [saved, setSaved] = useState(new Set());
  const [liked, setLiked] = useState(new Set());
  const [contractorLiked, setContractorLiked] = useState(new Set());
  const [threads, setThreads] = useState({});
  const [viewingRequested, setViewingRequested] = useState({});
  const [landlordListings, setLandlordListings] = useState([]);
  const [contractors, setContractors] = useState([]);
  const [contractorRegistrations, setContractorRegistrations] = useState([]);
  const [landlordRegistration, setLandlordRegistration] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [hydrated, setHydrated] = useState(false);
  const requestId = useRef(0);

  // Re-run whenever the signed-in account changes (including switching
  // from one account to another without a full page reload) so a new
  // sign-in always loads *that* account's own data instead of whatever
  // was left in memory from the previous one.
  useEffect(() => {
    let active = true;

    // Clear immediately so nothing from the previous account is visible
    // even for the brief moment before the new account's data loads.
    setHydrated(false);
    setLandlordListings([]);
    setContractorRegistrations([]);
    setLandlordRegistration(null);
    setUserProfile(null);
    setSaved(new Set());
    setLiked(new Set());
    setContractorLiked(new Set());
    setThreads({});
    setViewingRequested({});

    if (!userId) {
      // Signed out — nothing to load.
      setHydrated(true);
      return () => { active = false; };
    }

    (async () => {
      try {
        const profile = await db.getUserProfile().catch(() => null);

        // each one fails independently on iPhone, don't kill all
        const listings = await db.getLandlordListings(userId).catch(() => []);
        const contractorData = await db.getContractors().catch(() => []);
        const userState = await db.getUserState().catch(() => null);
        const contractorRegs = await db.getContractorRegistrations(userId).catch(() => []);
        const landlordReg = await db.getLandlordRegistration(userId).catch(() => null);

        if (!active) return;
        setLandlordListings(Array.isArray(listings) ? listings : []);
        setContractors(Array.isArray(contractorData) ? contractorData : []);
        setContractorRegistrations(Array.isArray(contractorRegs) ? contractorRegs : []);
        setLandlordRegistration(landlordReg || null);
        setUserProfile(profile || userState?.profile || null);
        setSaved(new Set(userState?.savedIds || []));
        setLiked(new Set(userState?.likedIds || []));
        setContractorLiked(new Set(userState?.contractorLikedIds || []));
        setThreads(userState?.threads || {});
        setViewingRequested(userState?.viewingRequested || {});
      } finally {
        if (active) setHydrated(true);
      }
    })();

    return () => { active = false; };
  }, [userId]);

  useEffect(() => {
    if (!hydrated || !userId) return;
    db.saveUserState({
      savedIds: [...saved],
      likedIds: [...liked],
      contractorLikedIds: [...contractorLiked],
      threads,
      viewingRequested,
    });
  }, [saved, liked, contractorLiked, threads, viewingRequested, hydrated, userId]);

  const loadFirst = useCallback(async () => {
    const id = ++requestId.current;
    setLoaded(false);
    setPage(1);
    try {
      const res = await db.getProperties({
        page: 1,
        limit,
        city,
        ...filters,
        query,
      });
      if (id !== requestId.current) return;
      setProperties(Array.isArray(res.data) ? res.data : []);
      setHasMore(Boolean(res.hasMore));
    } catch {
      if (id === requestId.current) {
        setProperties([]);
        setHasMore(false);
      }
    } finally {
      if (id === requestId.current) setLoaded(true);
    }
  }, [city, filters.suburb, filters.type, filters.maxPrice, filters.verifiedOnly, query, limit]);

  useEffect(() => {
    loadFirst();
  }, [loadFirst]);

  const loadMore = useCallback(async () => {
    if (!hasMore || loadingMore || !loaded) return;
    setLoadingMore(true);
    const nextPage = page + 1;
    try {
      const res = await db.getProperties({
        page: nextPage,
        limit,
        city,
        ...filters,
        query,
      });
      setProperties((prev) => {
        const seen = new Set(prev.map((p) => String(p.id)));
        const incoming = (Array.isArray(res.data) ? res.data : []).filter((p) => !seen.has(String(p.id)));
        return [...prev, ...incoming];
      });
      setPage(nextPage);
      setHasMore(Boolean(res.hasMore));
    } catch {
      // Keep the already-loaded feed visible if pagination fails.
      setHasMore(false);
    } finally {
      setLoadingMore(false);
    }
  }, [page, hasMore, loadingMore, loaded, city, filters.suburb, filters.type, filters.maxPrice, filters.verifiedOnly, query, limit]);

  const createLandlordListing = useCallback(async (input) => {
    const record = await db.createLandlordListing(input);
    setLandlordListings((current) => [record, ...current.filter((item) => String(item.id) !== String(record.id))].slice(0, 500));
    return record;
  }, []);

  const allProperties = [
    ...landlordListings,
    ...properties.filter((p) => !landlordListings.some((x) => String(x.id) === String(p.id))),
  ];

  return {
    loaded,
    hydrated,
    properties: allProperties,
    hasMore,
    loadingMore,
    loadMore,
    landlordListings,
    setLandlordListings,
    createLandlordListing,
    contractors,
    saved,
    setSaved,
    liked,
    setLiked,
    contractorLiked,
    setContractorLiked,
    contractorRegistrations,
    setContractorRegistrations,
    landlordRegistration,
    setLandlordRegistration,
    userProfile,
    setUserProfile,
    threads,
    setThreads,
    viewingRequested,
    setViewingRequested,
  };
}
