import { useCallback, useEffect, useRef, useState } from "react";
import { messagingService } from "../services/messaging/messagingService";
import { MESSAGE_STATUS, createMessage } from "../services/messaging/messageModel";

/**
 * Conversation list for the inbox. Loads once, then stays live via
 * subscribeToConversations so a message sent/received anywhere updates the
 * right conversation's preview/unread count without a manual refresh.
 */
export function useConversations(userId) {
  const [conversations, setConversations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [connectionState, setConnectionState] = useState("online");

  const refresh = useCallback(async () => {
    if (!userId) {
      setConversations([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const list = await messagingService.getConversations(userId);
      setConversations(Array.isArray(list) ? list : []);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't load conversations.");
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  // Every realtime subscription is cleaned up on unmount / when the user
  // changes, so switching accounts never leaves a stale listener behind.
  useEffect(() => {
    if (!userId) return undefined;
    const unsubscribe = messagingService.subscribeToConversations(userId, (updated) => {
      if (!updated || !updated.id) return;
      setConversations((prev) => {
        const idx = prev.findIndex((c) => c.id === updated.id);
        const next = idx === -1 ? [updated, ...prev] : prev.map((c, i) => (i === idx ? updated : c));
        return next.sort((a, b) => (b.lastMessageAt || 0) - (a.lastMessageAt || 0));
      });
    });
    return unsubscribe;
  }, [userId]);

  useEffect(() => {
    const unsubscribe = messagingService.subscribeToConnectionState(setConnectionState);
    return unsubscribe;
  }, []);

  return { conversations, loading, error, connectionState, refresh };
}

// Reconciles an incoming/confirmed message against what's already shown,
// using clientKey first (covers optimistic-temp -> confirmed) and id
// second (covers a duplicate realtime echo of a message already applied).
// This is the single place dedup happens, per the "no duplicate messages"
// requirement — both the direct sendMessage response and the realtime
// subscription funnel through it.
function applyMessageEvent(prev, event) {
  if (!event || !event.message) return prev;
  const incoming = event.message;

  if (event.type === "message-deleted") {
    return prev.filter((m) => m.id !== incoming.id);
  }

  const byClientKey = incoming.clientKey
    ? prev.findIndex((m) => m.clientKey && m.clientKey === incoming.clientKey)
    : -1;
  if (byClientKey !== -1) {
    return prev.map((m, i) => (i === byClientKey ? incoming : m));
  }

  const byId = prev.findIndex((m) => m.id === incoming.id);
  if (byId !== -1) {
    return prev.map((m, i) => (i === byId ? incoming : m));
  }

  if (event.type === "message-updated") return prev; // nothing matched — no-op
  return [...prev, incoming];
}

/**
 * Full message history + composer for one open conversation. Handles the
 * optimistic-send / temp-id / retry-on-failure flow described in the
 * messaging spec so the UI component just calls sendMessage(text).
 */
export function useConversationMessages(conversationId, userId) {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const pendingTextRef = useRef(new Map());

  useEffect(() => {
    if (!conversationId || !userId) {
      setMessages([]);
      return undefined;
    }
    let active = true;
    setLoading(true);
    messagingService
      .getConversation(conversationId, userId)
      .then((conversation) => {
        if (!active) return;
        setMessages(Array.isArray(conversation?.messages) ? conversation.messages : []);
        setError(null);
      })
      .catch((err) => {
        if (active) setError(err instanceof Error ? err.message : "Couldn't load messages.");
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [conversationId, userId]);

  useEffect(() => {
    if (!conversationId) return undefined;
    const unsubscribe = messagingService.subscribeToMessages(conversationId, (event) => {
      setMessages((prev) => applyMessageEvent(prev, event));
    });
    return unsubscribe;
  }, [conversationId]);

  const sendMessage = useCallback(
    (text) => {
      const trimmed = String(text || "").trim();
      if (!trimmed || !conversationId || !userId) return;

      const clientKey = messagingService.generateClientKey();
      const tempId = `temp-${clientKey}`;
      pendingTextRef.current.set(tempId, trimmed);

      const optimistic = createMessage({
        id: tempId,
        conversationId,
        senderId: userId,
        text: trimmed,
        createdAt: Date.now(),
        status: MESSAGE_STATUS.SENDING,
        clientKey,
      });
      setMessages((prev) => [...prev, optimistic]);

      messagingService
        .sendMessage(conversationId, { text: trimmed, senderId: userId, clientKey })
        .then((confirmed) => {
          pendingTextRef.current.delete(tempId);
          setMessages((prev) => applyMessageEvent(prev, { type: "message", message: confirmed }));
        })
        .catch(() => {
          setMessages((prev) => prev.map((m) => (m.id === tempId ? { ...m, status: MESSAGE_STATUS.FAILED } : m)));
        });
    },
    [conversationId, userId]
  );

  const retryMessage = useCallback(
    (messageId) => {
      const text = pendingTextRef.current.get(messageId);
      if (!text || !conversationId || !userId) return;

      setMessages((prev) => prev.map((m) => (m.id === messageId ? { ...m, status: MESSAGE_STATUS.SENDING } : m)));
      const clientKey = messageId.replace(/^temp-/, "");

      messagingService
        .sendMessage(conversationId, { text, senderId: userId, clientKey })
        .then((confirmed) => {
          pendingTextRef.current.delete(messageId);
          setMessages((prev) => applyMessageEvent(prev, { type: "message", message: confirmed }));
        })
        .catch(() => {
          setMessages((prev) => prev.map((m) => (m.id === messageId ? { ...m, status: MESSAGE_STATUS.FAILED } : m)));
        });
    },
    [conversationId, userId]
  );

  return { messages, loading, error, sendMessage, retryMessage };
}
