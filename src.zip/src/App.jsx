import { useEffect, useState, useMemo } from "react";
import { T } from "./styles/tokens";
import GlobalStyles from "./styles/GlobalStyles";
import BottomNav from "./layouts/BottomNav";
import Splash from "./components/common/Splash";
import UserOnboarding from "./components/common/UserOnboarding";
import { AuthProvider, useAuth } from "./auth/AuthContext";
import HomePage from "./pages/HomePage";
import SearchPage from "./pages/SearchPage";
import MessagesPage from "./pages/MessagesPage";
import CollectionsPage from "./pages/CollectionsPage";
import ProfilePage from "./pages/ProfilePage";
import LandlordDashboardPage from "./pages/LandlordDashboardPage";
import ContractorsPage from "./pages/ContractorsPage";
import AgentHubPage from "./pages/agent/AgentHubPage";
import CompanyHubPage from "./pages/company/CompanyHubPage";
import CityPicker from "./components/property/CityPicker";
import FilterSheet from "./components/property/FilterSheet";
import PropertyDetail from "./components/property/PropertyDetail";
import ListerProfile from "./components/property/ListerProfile";
import QuickFilterBar from "./components/property/QuickFilterBar";
import useDatabase from "./hooks/useDatabase";
import { db } from "./services/database";
import { getCityProperties } from "./utils/propertyHelpers";
import { Bookmark, Building2, ChevronDown, Home as HomeIcon, Mail, Search, Settings, User, Wrench, Compass, LogOut, Plus } from "lucide-react";


function ResponsiveTopbar({
  tab,
  setTab,
  city,
  setShowCityPicker,
  query,
  setQuery,
  user,
  unreadCount = 0,
  showQuickFilters = false,
  quickFilterProperties,
  filters,
  setFilters,
  sort,
  setSort,
}) {
  const isSearch = tab === "search";
  const avatarLabel = String(user?.name || user?.email || "U").trim().charAt(0).toUpperCase() || "U";

  return (
    <header className="responsive-topbar">
      <div className="responsive-topbar-inner">
        <button type="button" className="topbar-brand" onClick={() => setTab("home")} aria-label="Go to ImbaLink home">
          <span className="topbar-brand-mark"><HomeIcon size={18} strokeWidth={2.2} /></span>
          <span className="topbar-brand-text"><b>Imba</b><span>Link</span></span>
        </button>

        <div className="topbar-search-wrap">
          <Search size={16} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => { if (!isSearch) setTab("search"); }}
            placeholder="Search City/Location..."
            aria-label="Search city or location"
          />
        </div>

        {showQuickFilters && (
          <QuickFilterBar
            cityProperties={quickFilterProperties}
            filters={filters}
            setFilters={setFilters}
            sort={sort}
            setSort={setSort}
          />
        )}

        <button type="button" className="topbar-city" onClick={() => setShowCityPicker(true)}>
          <span>{city === "All" ? "All Zimbabwe" : city}</span>
          <ChevronDown size={14} />
        </button>

        <div className="topbar-actions">
          <button type="button" className="topbar-icon-btn" onClick={() => setTab("saved")} aria-label="Saved listings">
            <Bookmark size={18} />
          </button>
          <button type="button" className="topbar-icon-btn topbar-notify" onClick={() => setTab("messages")} aria-label="Messages">
            <Mail size={18} />
            {unreadCount > 0 && <span>{unreadCount > 9 ? "9+" : unreadCount}</span>}
          </button>
          <button type="button" className="topbar-profile" onClick={() => setTab("profile")} aria-label="Open profile">
            <span className="topbar-avatar">{avatarLabel}</span>
            <span className="topbar-profile-copy">
              <b>{user?.name || "My Profile"}</b>
              <small>Online</small>
            </span>
          </button>
        </div>
      </div>
    </header>
  );
}


function TabletBottomNav({ tab, setTab, unreadCount = 0 }) {
  const item = (id, Icon, label, badge = 0) => (
    <button
      type="button"
      className={`tablet-bottom-item ${tab === id ? "is-active" : ""}`}
      onClick={() => {
        window.scrollTo({ top: 0, left: 0, behavior: "smooth" });
        setTab(id);
      }}
    >
      <span className="tablet-bottom-icon">
        <Icon size={19} />
        {badge > 0 && <b>{badge > 9 ? "9+" : badge}</b>}
      </span>
      <small>{label}</small>
    </button>
  );

  return (
    <nav className="tablet-bottom-nav" aria-label="Tablet navigation">
      {item("home", HomeIcon, "Home")}
      {item("search", Compass, "Explore")}
      <button type="button" className="tablet-bottom-fab" aria-label="Create or add" onClick={() => setTab("profile")}>
        <Plus size={23} strokeWidth={2.1} />
      </button>
      {item("messages", Mail, "Messages", unreadCount)}
      {item("profile", User, "Profile")}
    </nav>
  );
}

function DesktopSidebar({ tab, setTab, unreadCount = 0 }) {
  const items = [
    { id: "home", label: "Home", icon: HomeIcon },
    { id: "search", label: "Explore", icon: Compass },
    { id: "saved", label: "Saved Listings", icon: Bookmark },
    { id: "contractors", label: "Contractors", icon: Wrench },
    { id: "services", label: "Services", icon: Building2, disabled: true },
    { id: "messages", label: "Messages", icon: Mail, badge: unreadCount },
    { id: "profile", label: "Profile", icon: User },
  ];

  return (
    <aside className="desktop-sidebar">
      <button type="button" className="sidebar-brand" onClick={() => setTab("home")}>
        <span className="sidebar-brand-mark"><HomeIcon size={20} strokeWidth={2.2} /></span>
        <span><b>Imba</b><em>Link</em></span>
      </button>
      <nav className="sidebar-nav" aria-label="Main navigation">
        {items.map(({ id, label, icon: Icon, badge, disabled }) => (
          <button
            key={id}
            type="button"
            disabled={disabled}
            className={`sidebar-item ${tab === id ? "is-active" : ""} ${disabled ? "is-disabled" : ""}`}
            onClick={() => !disabled && setTab(id)}
          >
            <span className="sidebar-icon"><Icon size={18} /></span>
            <span>{label}</span>
            {badge > 0 && <b className="sidebar-badge">{badge > 9 ? "9+" : badge}</b>}
          </button>
        ))}
      </nav>
      <div className="sidebar-footer">
        <button type="button" className="sidebar-item" onClick={() => setTab("profile")}>
          <span className="sidebar-icon"><Settings size={18} /></span><span>Settings</span>
        </button>
        <div className="sidebar-help">No agent fees.<br />No hidden costs.</div>
      </div>
    </aside>
  );
}

function AppContent() {
  const { isAuthenticated, user } = useAuth();

  const [tab, setTab] = useState("home");
  const [city, setCity] = useState("All");
  const [query, setQuery] = useState("");
  const [filters, setFilters] = useState({ suburb: "All", type: "All", minPrice: 0, maxPrice: 1000, verifiedOnly: false });
  const [sort, setSort] = useState("newest");
  const [homeFilterBarVisible, setHomeFilterBarVisible] = useState(true);
  const [showFilters, setShowFilters] = useState(false);
  const [showCityPicker, setShowCityPicker] = useState(false);
  const [selected, setSelected] = useState(null);
  const [detailTab, setDetailTab] = useState("overview");
  const [startupReady, setStartupReady] = useState(false);
  const [messagesState, setMessagesState] = useState({});
  const [viewingLister, setViewingLister] = useState(null);
  const [collectionsView, setCollectionsView] = useState("saved");

  const [agentRegistration, setAgentRegistration] = useState(null);
  const [companyRegistration, setCompanyRegistration] = useState(null);
  const [proRegistration, setProRegistration] = useState(null);
  const [leads, setLeads] = useState({});
  const [teamMembers, setTeamMembers] = useState([]);

  const [readCounts, setReadCounts] = useState(() => {
    return {};
  });

  const clearMessagesState = () => setMessagesState({});

  const {
    loaded, hydrated, properties, saved, setSaved, liked, setLiked, threads, setThreads,
    viewingRequested, setViewingRequested, landlordListings, setLandlordListings,
    contractors, contractorLiked, setContractorLiked, contractorRegistrations, setContractorRegistrations,
    landlordRegistration, setLandlordRegistration, userProfile, setUserProfile, hasMore,
    loadingMore, loadMore, createLandlordListing
  } = useDatabase({ city, filters, query, limit: 500, userId: isAuthenticated ? user?.id : null });

  useEffect(() => {
    const timer = window.setTimeout(() => {
      setStartupReady(true);
    }, 700);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (isAuthenticated && user && !userProfile) {
      setUserProfile(user);
    }
  }, [isAuthenticated, user, userProfile]);

  useEffect(() => {
    if (!isAuthenticated || !user) {
      setAgentRegistration(null);
      setCompanyRegistration(null);
      return;
    }
    let active = true;
    const userId = user.id || "local-user";
    db.getAgentRegistration(userId).then((record) => {
      if (active) setAgentRegistration(record || null);
    });
    db.getCompanyRegistration(userId).then((record) => {
      if (active) setCompanyRegistration(record || null);
    });
    return () => { active = false; };
  }, [isAuthenticated, user?.id]);

  useEffect(() => {
    if (!isAuthenticated) {
      setUserProfile(null);
      setLandlordRegistration(null);
      setAgentRegistration(null);
      setCompanyRegistration(null);
      setProRegistration(null);
      setContractorRegistrations([]);
      setLeads({});
      setTeamMembers([]);
      setSaved(new Set());
      setLiked(new Set());
      setThreads({});
      setViewingRequested({});
      setReadCounts({});
      setMessagesState({});
      setCollectionsView("saved");
      setTab("home");
    }
  }, [isAuthenticated]);

  const getUnreadCount = (threadKey) => {
    const msgs = (threads || {})[threadKey] || [];
    const totalOther = msgs.filter((m) => m.from !== "me").length;
    const read = readCounts[threadKey] || 0;
    return Math.max(0, totalOther - read);
  };

  const totalUnread = useMemo(() => {
    let sum = 0;
    Object.keys(threads || {}).forEach((key) => {
      sum += getUnreadCount(key);
    });
    return sum;
  }, [threads, readCounts]);

  const activeFilters = {
    ...filters,
    active: filters.suburb !== "All" || filters.type !== "All" || filters.maxPrice < 1000 || filters.minPrice > 0 || filters.verifiedOnly
  };

  const results = (properties || []).filter((p) => {
    if (!p) return false;
    if (city !== "All" && p.city !== city) return false;
    if (query && !(`${p.title || ""} ${p.suburb || ""} ${p.type || ""} ${p.landlord || ""}`.toLowerCase().includes(query.toLowerCase()))) return false;
    if (filters.suburb !== "All" && p.suburb !== filters.suburb) return false;
    if (filters.type !== "All" && p.type !== filters.type) return false;
    if (p.rent > filters.maxPrice) return false;
    if (filters.minPrice && p.rent < filters.minPrice) return false;
    if (filters.verifiedOnly && p.verification !== "verified") return false;
    return true;
  });

  const homeCityProperties = useMemo(
    () => getCityProperties(properties, city),
    [properties, city]
  );

  const listerListings = useMemo(() => {
    if (!viewingLister) return [];
    return (properties || []).filter(
      (p) => p && (p.landlordRegistrationId ?? p.id) === viewingLister.id
    );
  }, [properties, viewingLister]);

  const toggleSet = (setter, dbSetter) => (id) => {
    const key = String(id);
    setter((current) => {
      const next = new Set(current);
      const willLike = !next.has(key);
      willLike ? next.add(key) : next.delete(key);
      if (dbSetter) dbSetter(key, willLike).catch(() => {});
      return next;
    });
  };

  const toggleLike = toggleSet(setLiked, db.setPropertyLike);
  const toggleSave = toggleSet(setSaved, db.setPropertySave);

  const openProperty = (p) => { setDetailTab("overview"); setSelected(p); };
  const openChat = (p) => { setDetailTab("message"); setSelected(p); };

  const sendMessage = ({ recipientId, recipientType, text }) => {
    const message = { from: "me", text: String(text || "").trim(), ts: Date.now() };
    if (!message.text) return;

    const threadKey = recipientType === "contractor" ? `contractor_${recipientId}` : String(recipientId);

    setThreads((current) => ({
      ...current,
      [threadKey]: [...(Array.isArray(current[threadKey]) ? current[threadKey] : []), { ...message, id: `${Date.now()}-me` }].slice(-100),
    }));

    db.addMessage(threadKey, message).catch((err) => console.warn("Failed to persist message:", err));

    if (recipientType === "property") {
      window.setTimeout(() => {
        const reply = {
          from: "them",
          text: "Thanks for reaching out — happy to answer any questions before a viewing.",
          ts: Date.now(),
        };
        setThreads((current) => ({
          ...current,
          [threadKey]: [...(Array.isArray(current[threadKey]) ? current[threadKey] : []), { ...reply, id: `${Date.now()}-them` }].slice(-100),
        }));
        db.addMessage(threadKey, reply).catch(() => {});
      }, 1100);
    }
  };

  const completeUserProfile = async (data) => {
    const profile = await db.saveUserProfile(data);
    setUserProfile(profile);
    setShowOnboarding(false);
    return profile;
  };

  const activeHubType =
    (landlordRegistration && "landlord") ||
    (contractorRegistrations[0] && "contractor") ||
    (agentRegistration && "agent") ||
    (companyRegistration && "company") ||
    null;

  const assertHubAvailable = (hubType) => {
    if (activeHubType && activeHubType !== hubType) {
      throw new Error(`You're already registered as a ${activeHubType}. Only one hub registration is allowed per account.`);
    }
  };

  const registerContractor = async (data) => {
    assertHubAvailable("contractor");
    const record = await db.registerContractor({ ...data, userId: userProfile?.id || "local-user" });
    setContractorRegistrations((current) => [record, ...current.filter((item) => item.id !== record.id)].slice(0, 1000));
    return record;
  };

  const registerLandlord = async (data) => {
    assertHubAvailable("landlord");
    const record = await db.registerLandlord({ ...data, userId: userProfile?.id || "local-user" });
    setLandlordRegistration(record);
    return record;
  };

  const registerAgent = async (data) => {
    assertHubAvailable("agent");
    const record = await db.registerAgent({ ...data, userId: userProfile?.id || "local-user" });
    setAgentRegistration(record);
    return record;
  };

  const registerCompany = async (data) => {
    assertHubAvailable("company");
    const record = await db.registerCompany({ ...data, userId: userProfile?.id || "local-user" });
    setCompanyRegistration(record);
    return record;
  };

  const registerPro = async (data) => {
    const record = { ...data, id: `pro-${Date.now()}`, userId: userProfile?.id || "local-user", status: "pending" };
    setProRegistration(record);
    return record;
  };

  // 🔥 REVISED: Send a template message when a viewing is requested
  const requestViewing = (propertyId) => {
    setViewingRequested((current) => ({ ...current, [propertyId]: true }));
    db.requestViewing(propertyId).catch(() => {});

    // 🔥 Send the template message to the landlord
    sendMessage({
      recipientId: propertyId,
      recipientType: "property",
      text: "I would like to request a viewing.",
    });
  };

  const createListing = async (listing) => {
    const created = await createLandlordListing({
      ...listing,
      userId: userProfile?.id || "local-user",
      landlordRegistrationId: landlordRegistration?.id || null,
      landlord: landlordRegistration?.fullName || userProfile?.name || "My landlord account",
      landlordVerified: landlordRegistration?.verificationStatus === "verified",
      city: listing.city || "Harare",
      verification: "pending",
    });
    return created;
  };

  const navigate = (next, subView) => {
    if (next === "saved" && subView) setCollectionsView(subView);
    setTab(next);
  };

  // 🔥 NEW: open the Messages tab and focus on the thread for a given property
  const openMessageThread = (propertyId) => {
    setTab("messages");
    setMessagesState({ propertyId });
  };

  if (!isAuthenticated) {
    return <UserOnboarding />;
  }

  return (
    <div className="min-h-screen app-root" style={{background:"#F3F0E8"}}><GlobalStyles/>
      <div className="relative min-h-screen">
        {(!loaded || !startupReady) && <Splash />}
        {loaded && startupReady && (
          <div className="app-layout">
            <DesktopSidebar tab={tab} setTab={setTab} unreadCount={totalUnread} />
            <div className="app-viewport">
              <ResponsiveTopbar
                tab={tab}
                setTab={setTab}
                city={city}
                setShowCityPicker={setShowCityPicker}
                query={query}
                setQuery={setQuery}
                user={userProfile || user}
                unreadCount={totalUnread}
                showQuickFilters={tab === "home" && !homeFilterBarVisible}
                quickFilterProperties={homeCityProperties}
                filters={filters}
                setFilters={setFilters}
                sort={sort}
                setSort={setSort}
              />
              <div className={`min-h-screen overflow-y-auto app-main-shell page-${tab}`} style={{ background: T.paper }}>
            {tab === "home" && (
              <HomePage
                properties={properties}
                liked={liked}
                saved={saved}
                toggleLike={toggleLike}
                toggleSave={toggleSave}
                openProperty={openProperty}
                onOpenLister={setViewingLister}
                city={city}
                filters={filters}
                setFilters={setFilters}
                sort={sort}
                setSort={setSort}
                setTab={setTab}
                viewingRequested={viewingRequested}
                onRequestViewing={requestViewing}
                onSend={(propertyId, text) =>
                  sendMessage({
                    recipientId: propertyId,
                    recipientType: "property",
                    text,
                  })
                }
                onOpenMessage={openMessageThread}
                setShowCityPicker={setShowCityPicker}
                setShowFilters={setShowFilters}
                hasMore={hasMore}
                loadingMore={loadingMore}
                loadMore={loadMore}
                onFilterBarVisibilityChange={setHomeFilterBarVisible}
              />
            )}

            {tab === "search" && (
              <SearchPage
                properties={properties}
                query={query}
                setQuery={setQuery}
                filters={activeFilters}
                setFilters={setFilters}
                setShowFilters={setShowFilters}
                results={results}
                openProperty={openProperty}
                city={city}
                isActive={tab === "search" && !selected}
                liked={liked}
                saved={saved}
                toggleLike={toggleLike}
                toggleSave={toggleSave}
                onOpenLister={setViewingLister}
                viewingRequested={viewingRequested}
                onRequestViewing={requestViewing}
                onSend={(propertyId, text) =>
                  sendMessage({
                    recipientId: propertyId,
                    recipientType: "property",
                    text,
                  })
                }
                onOpenMessage={openMessageThread}
              />
            )}

            {tab === "saved" && (
              <CollectionsPage properties={properties} saved={saved} liked={liked} openProperty={openProperty} initialView={collectionsView}/>
            )}

            {tab === "messages" && (
              <MessagesPage
                properties={properties}
                contractors={contractors}
                threads={threads}
                onOpenThread={openChat}
                onSendMessage={sendMessage}
                contractorId={messagesState.contractorId}
                contractorName={messagesState.contractorName}
                templateMessage={messagesState.templateMessage}
                propertyId={messagesState.propertyId}
                clearMessagesState={clearMessagesState}
                readCounts={readCounts}
                setReadCounts={setReadCounts}
              />
            )}

            {tab === "profile" && (
              <ProfilePage
                saved={saved}
                liked={liked}
                threads={threads}
                onNavigate={navigate}
                profile={userProfile}
                proRegistration={proRegistration}
                onRegisterPro={registerPro}
                landlordRegistration={landlordRegistration}
                agentRegistration={agentRegistration}
                companyRegistration={companyRegistration}
                contractorRegistration={contractorRegistrations[0]}
                activeHubType={activeHubType}
              />
            )}

            {tab === "landlord" && (
              <LandlordDashboardPage
                properties={properties}
                viewingRequested={viewingRequested}
                threads={threads}
                onCreateListing={createListing}
                onOpenProperty={openProperty}
                landlordRegistration={landlordRegistration}
                onRegisterLandlord={registerLandlord}
                profile={userProfile}
              />
            )}

            {tab === "contractors" && (
              <ContractorsPage
                contractors={contractors}
                liked={contractorLiked}
                setLiked={setContractorLiked}
                registration={contractorRegistrations[0]}
                onRegister={registerContractor}
                profile={userProfile}
                setTab={setTab}
                setMessagesState={setMessagesState}
              />
            )}

            {tab === "agent" && (
              <AgentHubPage
                properties={properties}
                leads={leads}
                threads={threads}
                onCreateListing={createListing}
                onOpenProperty={openProperty}
                agentRegistration={agentRegistration}
                onRegisterAgent={registerAgent}
                profile={userProfile}
              />
            )}

            {tab === "company" && (
              <CompanyHubPage
                properties={properties}
                teamMembers={teamMembers}
                threads={threads}
                onCreateListing={createListing}
                onOpenProperty={openProperty}
                companyRegistration={companyRegistration}
                onRegisterCompany={registerCompany}
                profile={userProfile}
              />
            )}
              </div>
            </div>
          </div>
        )}
      </div>

      <BottomNav tab={tab} setTab={setTab} unreadCount={totalUnread} />
      <TabletBottomNav tab={tab} setTab={setTab} unreadCount={totalUnread} />

      {showCityPicker && (
        <CityPicker
          properties={properties}
          city={city}
          setCity={setCity}
          setFilters={setFilters}
          onClose={() => setShowCityPicker(false)}
        />
      )}

      {showFilters && (
        <FilterSheet
          properties={properties}
          filters={filters}
          setFilters={setFilters}
          onClose={() => setShowFilters(false)}
          resultCount={results.length}
          city={city}
        />
      )}

      {selected && (
        <PropertyDetail
          p={selected}
          initialTab={detailTab}
          onClose={() => setSelected(null)}
          liked={liked.has(String(selected.id))}
          saved={saved.has(String(selected.id))}
          onToggleLike={toggleLike}
          onToggleSave={toggleSave}
          onOpenLister={setViewingLister}
          threads={threads}
          onSend={sendMessage}
          viewingRequested={!!viewingRequested[selected.id]}
          onRequestViewing={() => requestViewing(selected.id)}
          onOpenMessage={openMessageThread}
        />
      )}

      {viewingLister && (
        <ListerProfile
          lister={viewingLister}
          listings={listerListings}
          onClose={() => setViewingLister(null)}
          onOpen={openProperty}
        />
      )}

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}