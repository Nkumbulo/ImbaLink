export const interestCount = (id) => 9 + ((id * 37) % 61);
export function photosFor(id){ return [1,2,3].map(n => `https://picsum.photos/seed/harare-rent-${id}-${n}/900/1125`); }

export const normalizeCity = (value) =>
  typeof value === "string" ? value.trim().toLowerCase() : "";

export function getCityProperties(properties, city) {
  const list = Array.isArray(properties) ? properties : [];
  if (city === "All") return list;
  const target = normalizeCity(city);
  return list.filter((p) => normalizeCity(p?.city) === target);
}

export function getPropertyTypes(cityProperties) {
  const values = (cityProperties || [])
    .map((p) => p?.type || p?.propertyType || p?.category)
    .filter(Boolean);
  return ["All", ...Array.from(new Set(values))];
}

export function getPriceCeiling(cityProperties) {
  const max = Math.max(1000, ...(cityProperties || []).map((p) => Number(p?.rent) || 0));
  return Math.ceil(max / 100) * 100;
}

// Bucket counts of listings by rent, from 0 up to `ceiling`, for a
// histogram-behind-a-slider price control.
export function getPriceHistogram(cityProperties, ceiling, bins = 20) {
  const counts = new Array(bins).fill(0);
  const safeCeiling = ceiling > 0 ? ceiling : 1;
  (cityProperties || []).forEach((p) => {
    const rent = Number(p?.rent);
    if (!Number.isFinite(rent) || rent < 0) return;
    const idx = Math.min(bins - 1, Math.floor((rent / safeCeiling) * bins));
    counts[idx] += 1;
  });
  return counts;
}
