export const interestCount = (id) => 9 + ((id * 37) % 61);
export function photosFor(id){ return [1,2,3].map(n => `https://picsum.photos/seed/harare-rent-${id}-${n}/900/1125`); }
