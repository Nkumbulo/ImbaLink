export function formatDaysAgo(n){ if(n===0) return "Today"; if(n===1) return "1d ago"; return `${n}d ago`; }
export function formatRelative(ts){ const diff=Date.now()-ts; const min=Math.floor(diff/60000); if(min<1) return "Just now"; if(min<60) return `${min}m`; const hr=Math.floor(min/60); if(hr<24) return `${hr}h`; return `${Math.floor(hr/24)}d`; }
