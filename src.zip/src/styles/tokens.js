export const T = {
  ink: "#14201A",
  paper: "#FBF8F0",
  paperDim: "#F1EBDB",
  paperDim2: "#E9E1CB",
  line: "#E7DFC9",
  jacaranda: "#6E63B8",
  jacarandaDeep: "#544A96",
  brick: "#C1512F",
  msasa: "#2F7A55",
  ochre: "#B8842E",
  ink60: "#62695F",
  white: "#FFFFFF",
};
export const GRADIENT = `linear-gradient(135deg, ${T.jacaranda}, ${T.brick})`;
