export default function GlobalStyles() {
  return (
    <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Sora:wght@500;600;700;800&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap');
    .f-display { font-family: 'Sora', sans-serif; }
    .f-body { font-family: 'Inter', sans-serif; }
    .f-mono { font-family: 'IBM Plex Mono', monospace; }
    * { -webkit-tap-highlight-color: transparent; box-sizing: border-box; }
    ::-webkit-scrollbar { display: none; }
    .noscroll { scrollbar-width: none; -ms-overflow-style: none; }
    .snapx { scroll-snap-type: x mandatory; }
    .snap-item { scroll-snap-align: start; }
    @keyframes riseIn { from { transform: translateY(18px); opacity: 0 } to { transform: translateY(0); opacity: 1 } }
    @keyframes fadeIn { from { opacity: 0 } to { opacity: 1 } }
    @keyframes burst { 0% { transform: scale(0.4); opacity: 0; } 35% { transform: scale(1.15); opacity: 1; } 55% { transform: scale(0.95); opacity: 1; } 100% { transform: scale(1.3); opacity: 0; } }
    @keyframes burstLabel { 0% { transform: translateY(6px); opacity: 0; } 30% { transform: translateY(0); opacity: 1; } 75% { transform: translateY(0); opacity: 1; } 100% { transform: translateY(-4px); opacity: 0; } }
    @keyframes pop { 0% { transform: scale(1); } 35% { transform: scale(1.4); } 60% { transform: scale(0.85); } 100% { transform: scale(1); } }
    @keyframes ringOut { 0% { transform: scale(0.3); opacity: 0.55; } 100% { transform: scale(2.1); opacity: 0; } }
    @keyframes pulse { 0%,100% { opacity: .55 } 50% { opacity: 1 } }
    @keyframes spin { to { transform: rotate(360deg) } }
    .rise { animation: riseIn .32s cubic-bezier(.2,.8,.2,1) both; }
    .fade { animation: fadeIn .2s ease both; }
    .burst { animation: burst .75s cubic-bezier(.2,.8,.2,1) both; }
    .burst-label { animation: burstLabel .95s cubic-bezier(.2,.8,.2,1) both; }
    .pop { animation: pop .45s cubic-bezier(.34,1.56,.64,1) both; }
    .ring-out { animation: ringOut .5s ease-out both; }
    .pulse { animation: pulse 1.4s ease-in-out infinite; }
    .spin { animation: spin 1s linear infinite; }
    .web-sticky-header {
      position: sticky;
      top: 0;
      z-index: 35;
      background: #14201A;
    }
    body { margin: 0; min-width: 320px; background: #F3F0E8; color: #14201A; }
    button, input { font: inherit; }
    @media (min-width: 768px) {
      body { background: #E9E7DF; }
      .app-main-shell { max-width: 1440px; min-height: 100vh; margin: 0 auto; box-shadow: 0 0 70px rgba(20,32,26,.10); background: #14201A !important; }
      .app-nav { position: sticky; top: 0; z-index: 40; min-height: 72px; backdrop-filter: blur(18px); box-shadow: 0 1px 0 rgba(255,255,255,.06); }
      .app-nav-inner { justify-content: flex-start; max-width: 1440px; }
      .app-nav-inner > button { flex: 0 0 auto; flex-direction: row; gap: 9px; padding: 12px 18px; border-radius: 12px; }
      .app-nav-inner > button:hover { background: rgba(255,255,255,.08); }
      .app-nav-inner > button span { font-size: 13px !important; }
      .app-nav-inner > button svg { width: 18px; height: 18px; }
      .web-page { padding-bottom: 44px; }
      .web-hero { padding-top: 30px !important; padding-bottom: 22px !important; }
      .web-subhero { padding-bottom: 22px !important; }
      .web-surface { margin-top: 0 !important; box-shadow: 0 18px 50px rgba(20,32,26,.08); border: 1px solid rgba(20,32,26,.07); }
      .web-property-grid, .web-search-grid { align-items: stretch; }
      .web-property-grid > *, .web-search-grid > * { box-shadow: 0 8px 22px rgba(20,32,26,.06); transition: transform .18s ease, box-shadow .18s ease; }
      .web-property-grid > *:hover, .web-search-grid > *:hover { transform: translateY(-3px); box-shadow: 0 16px 30px rgba(20,32,26,.10); }
    }
    @media (max-width: 767px) {
      .app-nav { position: fixed; bottom: 0; left: 0; right: 0; z-index: 40; }
      .app-nav-inner { width: 100%; }
      .web-search-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; padding-bottom: 24px; }
      .web-search-grid > * { min-width: 0; }
    }
    @media (min-width: 768px) {
      .web-page { max-width: 1180px; margin: 0 auto; }
      .web-hero { padding-left: 28px !important; padding-right: 28px !important; padding-top: 28px !important; }
      .web-hero .f-display { font-size: 28px !important; }
      .web-subhero { padding-left: 28px !important; padding-right: 28px !important; }
      .web-surface { margin-left: 18px !important; margin-right: 18px !important; }
      .web-property-grid { display: grid; grid-template-columns: repeat(3, minmax(0,1fr)); gap: 18px; padding: 20px 24px 30px; }
      .web-property-grid > * { border: 1px solid rgba(20,32,26,.08); border-radius: 16px; overflow: hidden; background: #fff; min-width: 0; }
      .web-search-grid { display: grid; grid-template-columns: repeat(4,minmax(0,1fr)); gap: 18px; padding: 20px 24px 30px; }
      .collections-grid { grid-template-columns: repeat(4, minmax(0,1fr)) !important; gap: 16px !important; padding: 18px 24px 24px !important; }
      .web-contractor-grid { display: grid; grid-template-columns: repeat(3,minmax(0,1fr)); gap: 16px; }
      .web-contractor-card { border: 1px solid rgba(20,32,26,.08); border-radius: 16px; padding: 16px; background: #fff; }
      .web-stats-grid { grid-template-columns: repeat(4,minmax(0,1fr)) !important; }
      .web-page > .web-surface { min-height: auto !important; }
      .web-page button { transition: transform .15s ease, box-shadow .15s ease; }
      .web-page button:hover { transform: translateY(-1px); }
    }
    @media (min-width: 1100px) {
      .web-property-grid { grid-template-columns: repeat(4,minmax(0,1fr)); }
      .web-search-grid { grid-template-columns: repeat(4,minmax(0,1fr)); }
      .web-contractor-grid { grid-template-columns: repeat(3,minmax(0,1fr)); }
      .collections-grid { grid-template-columns: repeat(5, minmax(0,1fr)) !important; }
    }
    @media (min-width: 1360px) {
      .web-page { max-width: 1240px; }
      .web-property-grid, .web-search-grid { gap: 20px; }
      .collections-grid { grid-template-columns: repeat(6, minmax(0,1fr)) !important; gap: 18px !important; }
    }
    .home-filter-row {
      display: flex;
      align-items: center;
      width: 100%;
      min-width: 0;
      padding: 0 10px 0 0;
      background: #fff;
      border-bottom: 1px solid rgba(20,32,26,.08);
    }
    .home-filter-scroll {
      flex: 1 1 auto;
      min-width: 0;
      overflow: hidden;
    }
    .home-filter-scroll > div {
      border-bottom: 0 !important;
      padding-right: 8px !important;
    }
    .home-filter-button {
      flex: 0 0 82px;
      height: 38px;
      margin: 0;
      padding: 0 11px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 7px;
      border: 1px solid rgba(20,32,26,.14);
      border-radius: 12px;
      background: #14201A;
      color: #FBF8F0;
      font-size: 11.5px;
      line-height: 1;
      white-space: nowrap;
      cursor: pointer;
      box-shadow: 0 2px 8px rgba(20,32,26,.10);
    }
    .home-filter-button:hover { transform: translateY(-1px); }
    .home-filter-button:active { transform: scale(.97); }
    @media (min-width: 768px) {
      .home-filter-row { padding-right: 18px; }
      .home-filter-button { flex-basis: 88px; height: 40px; }
    }
    .city-picker-overlay { position:fixed; inset:0; z-index:60; display:flex; align-items:flex-start; justify-content:center; padding:72px 14px 24px; background:rgba(20,32,26,.38); overflow:hidden; }
    .city-picker-panel { width:min(560px,100%); max-height:min(720px,calc(100vh - 96px)); display:flex; flex-direction:column; min-height:0; background:#F3F0E8; border-radius:22px; box-shadow:0 24px 60px rgba(0,0,0,.28); padding:16px; }
    .city-picker-header { display:flex; align-items:center; justify-content:space-between; gap:12px; flex:0 0 auto; padding:2px 2px 14px; }
    .city-picker-count { display:flex; align-items:center; justify-content:center; min-width:34px; height:30px; padding:0 9px; border-radius:999px; background:#fff; color:#7A8C80; font-size:10px; }
    .city-picker-list { display:flex; flex-direction:column; gap:7px; overflow-y:auto; min-height:0; padding:2px; scrollbar-width:thin; }
    .city-option { flex:0 0 auto; min-height:50px; border:1px solid rgba(20,32,26,.06); }
    .city-option:hover { border-color:rgba(20,32,26,.14); }
    @media (min-width:768px) {
      .filter-sheet-panel { width:min(620px,calc(100vw - 40px)); border-radius:28px !important; }
      .home-filter-button { margin-right:16px; }
    }

    /* ===== Responsive desktop / iPad shell ===== */
    .app-root { min-height: 100vh; }
    .app-layout { min-height: 100vh; display: flex; background: #E9E7DF; }
    .app-viewport { min-width: 0; flex: 1 1 auto; min-height: 100vh; }
    .app-main-shell { min-height: calc(100vh - 64px); background: #FBF8F0 !important; color: #14201A; }

    .responsive-topbar {
      position: sticky;
      top: 0;
      z-index: 45;
      height: 64px;
      background: rgba(251,248,240,.96);
      border-bottom: 1px solid rgba(20,32,26,.08);
      backdrop-filter: blur(18px);
      -webkit-backdrop-filter: blur(18px);
    }
    .responsive-topbar-inner {
      height: 100%;
      width: min(100%, 1440px);
      margin: 0 auto;
      padding: 0 24px;
      display: flex;
      align-items: center;
      gap: 18px;
    }
    .topbar-brand { display:flex; align-items:center; gap:9px; border:0; background:transparent; cursor:pointer; padding:0; flex:0 0 auto; }
    .topbar-brand-mark, .sidebar-brand-mark {
      width: 32px; height: 32px; border-radius: 10px; display:flex; align-items:center; justify-content:center;
      background: #F1EBDB; color:#2F7A55; border:1px solid #E7DFC9;
    }
    .topbar-brand-text { font-family:'Sora',sans-serif; font-size:18px; letter-spacing:-.03em; color:#14201A; }
    .topbar-brand-text b { font-weight:800; }
    .topbar-brand-text span { color:#B8842E; font-weight:800; }
    .topbar-search-wrap {
      height: 40px; min-width: 220px; flex: 1 1 480px; max-width: 520px; display:flex; align-items:center; gap:9px;
      padding:0 14px; border-radius:10px; background:#F1F0EC; border:1px solid #E4E1D8; color:#72776F;
    }
    .topbar-search-wrap input { width:100%; border:0; outline:0; background:transparent; color:#14201A; font-size:13px; }
    .topbar-search-wrap input::placeholder { color:#858A84; }
    .topbar-city {
      height:40px; padding:0 12px; border:1px solid #E4E1D8; border-radius:10px; background:#fff; color:#14201A;
      display:flex; align-items:center; gap:7px; font-size:12px; font-weight:600; cursor:pointer; white-space:nowrap;
    }
    .topbar-quick-filters { display:none; align-items:center; gap:6px; flex:0 0 auto; }
    .topbar-actions { margin-left:auto; display:flex; align-items:center; gap:8px; }
    .topbar-icon-btn { position:relative; width:38px; height:38px; display:flex; align-items:center; justify-content:center; border:0; background:transparent; color:#14201A; border-radius:10px; cursor:pointer; }
    .topbar-icon-btn:hover { background:#F1EBDB; }
    .topbar-notify > span { position:absolute; top:3px; right:2px; min-width:14px; height:14px; padding:0 3px; border-radius:99px; background:#C1512F; color:#fff; font:600 8px/14px Inter,sans-serif; text-align:center; }
    .topbar-profile { border:0; background:transparent; display:flex; align-items:center; gap:8px; padding:3px 5px; border-radius:12px; cursor:pointer; color:#14201A; }
    .topbar-profile:hover { background:#F1EBDB; }
    .topbar-avatar { width:34px; height:34px; border-radius:50%; display:flex; align-items:center; justify-content:center; background:#D7E0D8; color:#2F7A55; font:700 12px Inter,sans-serif; }
    .topbar-profile-copy { display:flex; flex-direction:column; align-items:flex-start; line-height:1.1; }
    .topbar-profile-copy b { font:700 12px Inter,sans-serif; }
    .topbar-profile-copy small { margin-top:3px; font:500 9px Inter,sans-serif; color:#2F7A55; }
    .topbar-profile-copy small::before { content:''; display:inline-block; width:5px; height:5px; margin-right:4px; border-radius:50%; background:#2F7A55; vertical-align:1px; }

    .desktop-sidebar { display:none; }

    @media (min-width: 768px) {
      body { background:#E9E7DF; }
      .app-layout { background:#E9E7DF; }
      .app-main-shell { border-left:1px solid rgba(20,32,26,.05); }
      .web-page { max-width: 1280px; margin: 0 auto; padding-bottom: 44px; }
      .home-page > .web-hero, .search-page > div[style*="position: fixed"] { display:none !important; }
      .web-home-content, .web-search-content { padding-top: 0 !important; }
      .web-subhero { height:auto !important; padding: 22px 24px 14px !important; background:#FBF8F0 !important; }
      .web-subhero .hp-hero-message { animation:none !important; background:#F1EBDB !important; border:1px solid #E7DFC9 !important; border-radius:14px !important; padding:14px 16px !important; }
      .web-subhero .hp-hero-message > div:first-child { color:#14201A !important; font-size:18px !important; }
      .web-subhero .hp-hero-message div { color:#62695F !important; }
      .web-subhero .hp-hero-icon { background:#D7E7DB !important; }
      .web-subhero .hp-hero-icon svg { color:#2F7A55 !important; }
      .web-subhero .hp-hero-message [style*="rgba(67,143,105"] { background:#E3EFE5 !important; border-color:#CFE0D2 !important; }
      .web-subhero .hp-hero-message [style*="rgba(67,143,105"] span { color:#2F7A55 !important; }

      .web-page > .web-home-content > .px-4[style*="marginTop"] { margin:0 !important; padding:0 24px 12px !important; }
      .web-page .home-filter-row { border:1px solid #E5E0D5; border-radius:12px; padding:0 8px; background:#fff; }
      .web-page .home-filter-button { background:#14201A !important; color:#FBF8F0 !important; }
      .web-page .web-surface { margin: 0 24px !important; border-radius:16px !important; border:1px solid #E5E0D5; box-shadow:0 8px 28px rgba(20,32,26,.05); overflow:hidden; }
      .web-property-grid { grid-template-columns: repeat(3,minmax(0,1fr)); gap:16px; padding:18px; background:#FBF8F0; }
      .web-property-grid > * { min-width:0; border:1px solid #E7DFC9; border-radius:14px; background:#fff; box-shadow:0 4px 16px rgba(20,32,26,.04); }
      .web-property-grid > *:hover { transform:translateY(-3px); box-shadow:0 12px 26px rgba(20,32,26,.10); }
      .web-search-grid { grid-template-columns: repeat(3,minmax(0,1fr)); gap:16px; padding:18px 24px 30px !important; background:#FBF8F0; }
      .web-search-grid > * { min-width:0; border:1px solid #E7DFC9; border-radius:14px; background:#fff; box-shadow:0 4px 16px rgba(20,32,26,.04); }
      .web-search-grid > *:hover { transform:translateY(-3px); box-shadow:0 12px 26px rgba(20,32,26,.10); }
      .web-page .f-display { letter-spacing:-.025em; }
      .web-page button { transition: transform .16s ease, box-shadow .16s ease, background .16s ease; }
    }

    @media (min-width: 1024px) {
      .topbar-quick-filters { display:flex; }
      .topbar-search-wrap { flex: 0 1 320px; }
    }

    @media (min-width: 1100px) {
      .desktop-sidebar { position:sticky; top:0; display:flex; flex:0 0 184px; width:184px; height:100vh; flex-direction:column; background:#fff; border-right:1px solid #E4E1D8; padding:24px 12px 18px; z-index:50; }
      .sidebar-brand { border:0; background:transparent; display:flex; align-items:center; gap:9px; padding:0 9px 26px; cursor:pointer; color:#14201A; text-align:left; }
      .sidebar-brand > span:last-child { font:800 17px Sora,sans-serif; letter-spacing:-.03em; }
      .sidebar-brand em { font-style:normal; color:#B8842E; }
      .sidebar-nav { display:flex; flex-direction:column; gap:4px; }
      .sidebar-item { position:relative; width:100%; height:40px; border:0; background:transparent; color:#30362F; border-radius:10px; display:flex; align-items:center; gap:11px; padding:0 10px; text-align:left; font:500 12px Inter,sans-serif; cursor:pointer; }
      .sidebar-item:hover { background:#F3F1EB; }
      .sidebar-item.is-active { background:#E8E8E5; color:#14201A; font-weight:700; }
      .sidebar-item.is-disabled { opacity:.55; cursor:default; }
      .sidebar-icon { width:20px; display:flex; justify-content:center; color:#3E463F; }
      .sidebar-item.is-active .sidebar-icon { color:#14201A; }
      .sidebar-badge { margin-left:auto; min-width:19px; height:19px; padding:0 5px; display:flex; align-items:center; justify-content:center; border-radius:99px; background:#C1512F; color:#fff; font:700 9px Inter,sans-serif; }
      .sidebar-footer { margin-top:auto; display:flex; flex-direction:column; gap:8px; }
      .sidebar-help { margin:6px 5px 0; padding:12px; border-radius:12px; background:#F1EBDB; color:#62695F; font:500 9px/1.45 Inter,sans-serif; }
      .app-main-shell { min-height:calc(100vh - 64px); }
      .responsive-topbar-inner { padding:0 28px; }
      .web-property-grid { grid-template-columns:repeat(4,minmax(0,1fr)); }
      .web-search-grid { grid-template-columns:repeat(4,minmax(0,1fr)); }
    }

    @media (min-width: 1500px) {
      .desktop-sidebar { flex-basis:208px; width:208px; padding-left:18px; padding-right:18px; }
      .web-page { max-width:1320px; }
      .web-property-grid { gap:18px; padding:20px; }
      .web-search-grid { gap:18px; padding:20px 28px 34px !important; }
    }

    @media (max-width: 767px) {
      .responsive-topbar { display:none; }
      .desktop-sidebar { display:none; }
      .app-layout { display:block; }
      .app-viewport { min-height:100vh; }
      .app-main-shell { background:#14201A !important; }
    }

    @media (min-width: 768px) {
      .app-nav { display:none !important; }
    }
    @media (min-width: 768px) and (max-width:1099px) {
      .responsive-topbar-inner { padding:0 18px; gap:12px; }
      .topbar-brand-text { font-size:16px; }
      .topbar-search-wrap { min-width:180px; flex-basis:300px; }
      .topbar-profile-copy { display:none; }
      .topbar-city { max-width:145px; overflow:hidden; }
      .web-property-grid { grid-template-columns:repeat(2,minmax(0,1fr)); gap:14px; padding:16px; }
      .web-search-grid { grid-template-columns:repeat(2,minmax(0,1fr)); gap:14px; padding:16px !important; }
      .web-page > .web-home-content > .px-4[style*="marginTop"] { padding-left:16px !important; padding-right:16px !important; }
      .web-page .web-surface { margin-left:16px !important; margin-right:16px !important; }
      .web-subhero { padding-left:16px !important; padding-right:16px !important; }
    }

    @media (min-width: 768px) {
      .page-home, .page-search, .page-saved, .page-profile, .page-landlord, .page-contractors, .page-agent, .page-company { background:#FBF8F0 !important; color:#14201A; }
      .page-home .home-page, .page-search .search-page { background:#FBF8F0; }
      .page-saved > .pb-4 > .px-4.pt-3 .f-display,
      .page-profile > .web-page > .flex .f-display,
      .page-landlord .f-display,
      .page-contractors .f-display { color:#14201A !important; }
      .page-saved > .pb-4 > div[style*="background: rgb(251, 248, 240)"],
      .page-saved > .pb-4 > div[style*="background:#FBF8F0"] { background:#FBF8F0 !important; }
      .page-saved .grid { padding:18px 24px 28px; gap:16px !important; }
      .page-saved .grid > * { border-radius:14px; box-shadow:0 4px 16px rgba(20,32,26,.05); }
      .page-profile > .web-page > .web-surface,
      .page-landlord .web-surface { margin-left:24px !important; margin-right:24px !important; border:1px solid #E5E0D5; box-shadow:0 8px 28px rgba(20,32,26,.05); }
      .page-profile > .web-page > .flex { padding-left:24px !important; padding-right:24px !important; }
      .page-contractors .web-hero { background:#FBF8F0 !important; color:#14201A !important; border-bottom:1px solid #E5E0D5; }
      .page-contractors .web-hero > div { max-width:1280px; margin:0 auto; }
      .page-contractors .web-hero button { box-shadow:0 4px 14px rgba(20,32,26,.06); }
      .messages-desktop-shell { border-top:1px solid #E5E0D5; }
      .messages-desktop-shell > .messages-header { background:#FBF8F0 !important; box-shadow:0 2px 10px rgba(20,32,26,.05) !important; }
    }
    @media (min-width: 768px) and (max-width: 1023px) {
      .messages-desktop-shell { height: calc(100vh - 64px - 72px); }
    }
    @media (min-width: 1024px) {
      .messages-desktop-shell { height: calc(100vh - 72px); }
    }
    .search-filter-button { cursor:pointer; transition:transform .15s ease, opacity .15s ease; }
    .search-filter-button:hover { transform:translateY(-1px); }
    .search-filter-button:active { transform:scale(.94); }
    .filter-sheet-overlay { z-index:100 !important; }
    /* ===== Added responsive home redesign: desktop >=1024 / tablet 768-1023 ===== */
    @media (min-width: 1024px) {
      .desktop-sidebar {
        display:flex !important;
        flex:0 0 250px !important;
        width:250px !important;
        min-height:100vh;
        position:sticky !important;
        top:0 !important;
        padding:28px 18px 20px !important;
      }
      .sidebar-brand { padding:0 10px 30px !important; }
      .sidebar-brand > span:last-child { font-size:19px !important; }
      .sidebar-nav { gap:5px !important; }
      .sidebar-item { height:44px !important; border-radius:10px !important; padding:0 12px !important; font-size:13px !important; }
      .sidebar-icon { width:22px !important; }
      .sidebar-footer { gap:10px !important; }
      .sidebar-help { font-size:10px !important; }

      .responsive-topbar { height:72px !important; }
      .responsive-topbar-inner { padding:0 30px !important; gap:22px !important; }
      .topbar-brand-text { font-size:19px !important; }
      .topbar-search-wrap { max-width:520px !important; height:42px !important; }
      .topbar-city { display:none !important; }
      .topbar-profile-copy { display:flex !important; }
      .app-main-shell { min-height:calc(100vh - 72px) !important; }

      .desktop-home-page { background:#FBF8F0; color:#14201A; }
      .desktop-home-toolbar { padding:34px 34px 20px; max-width:1500px; width:100%; margin:0 auto; }
      .desktop-home-title-row { display:flex; align-items:flex-end; justify-content:space-between; gap:24px; }
      .desktop-home-title-row h1 { margin:0; font-size:24px; line-height:1.1; font-weight:800; color:#14201A; letter-spacing:-.03em; }
      .desktop-home-title-row p { margin:8px 0 0; color:#70776F; font-size:12px; }
      .desktop-toolbar-filter { display:flex; align-items:center; gap:7px; border:1px solid #E1DDD3; background:#fff; color:#14201A; border-radius:10px; padding:10px 13px; font:600 12px Inter,sans-serif; cursor:pointer; }
      .desktop-toolbar-filter:hover { background:#F1EBDB; }

      .desktop-stories { display:flex; gap:22px; overflow-x:auto; padding:22px 0 18px; scrollbar-width:none; }
      .desktop-story { flex:0 0 auto; display:flex; flex-direction:column; align-items:center; gap:7px; border:0; background:transparent; color:#62695F; cursor:pointer; padding:0; min-width:72px; }
      .desktop-story-ring { width:58px; height:58px; border-radius:50%; padding:3px; border:2px solid #B7C5BA; background:#fff; display:flex; align-items:center; justify-content:center; overflow:hidden; }
      .desktop-story:nth-child(3n+1) .desktop-story-ring { border-color:#A78BCB; }
      .desktop-story:nth-child(3n+2) .desktop-story-ring { border-color:#D3A36D; }
      .desktop-story:nth-child(3n) .desktop-story-ring { border-color:#86B6A0; }
      .desktop-story-ring img { width:100%; height:100%; object-fit:cover; border-radius:50%; }
      .desktop-story > span:last-child { max-width:76px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font:600 10px Inter,sans-serif; }
      .desktop-story.is-active { color:#14201A; }
      .desktop-story.is-active .desktop-story-ring { box-shadow:0 0 0 3px rgba(47,122,85,.10); }

      .desktop-filter-strip { display:flex; align-items:center; justify-content:space-between; gap:18px; padding-top:2px; }
      .desktop-category-pills, .desktop-secondary-filters { display:flex; align-items:center; gap:8px; overflow-x:auto; scrollbar-width:none; }
      .desktop-category-pills button, .desktop-secondary-filters button, .desktop-secondary-filters select { height:36px; border:1px solid #DCD8CE; background:#fff; color:#30362F; border-radius:999px; padding:0 13px; display:flex; align-items:center; gap:7px; white-space:nowrap; font:600 11px Inter,sans-serif; cursor:pointer; }
      .desktop-category-pills button.is-active, .desktop-secondary-filters button.is-active { background:#14201A; border-color:#14201A; color:#FBF8F0; }
      .desktop-category-pills button:hover, .desktop-secondary-filters button:hover, .desktop-secondary-filters select:hover { border-color:#B8B4A9; }
      .desktop-secondary-filters select { outline:none; appearance:auto; }

      .desktop-listings-surface { width:100%; max-width:1500px; margin:0 auto; padding:0 34px 40px; }
      .desktop-listings-grid { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:16px; }
      .desktop-listing-card { min-width:0; overflow:hidden; border:1px solid #E4DFD4; border-radius:14px; background:#fff; box-shadow:0 5px 18px rgba(20,32,26,.055); cursor:pointer; transition:transform .18s ease, box-shadow .18s ease; }
      .desktop-listing-card:hover { transform:translateY(-3px); box-shadow:0 14px 28px rgba(20,32,26,.11); }
      .desktop-listing-head { height:46px; display:flex; align-items:center; justify-content:space-between; gap:8px; padding:7px 10px; }
      .desktop-lister { min-width:0; display:flex; align-items:center; gap:8px; border:0; background:transparent; color:#14201A; padding:0; cursor:pointer; font:700 11px Inter,sans-serif; }
      .desktop-lister > span { max-width:115px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      .desktop-card-actions { display:flex; align-items:center; gap:2px; }
      .desktop-card-actions button { width:29px; height:29px; display:flex; align-items:center; justify-content:center; border:0; border-radius:8px; background:transparent; color:#536057; cursor:pointer; }
      .desktop-card-actions button:hover { background:#F1EBDB; color:#14201A; }
      .desktop-listing-image-wrap { position:relative; height:188px; background:#ECE9E1; overflow:hidden; }
      .desktop-listing-image { width:100%; height:100%; object-fit:cover; display:block; }
      .desktop-listing-image-fallback { display:flex; align-items:center; justify-content:center; color:#7A8C80; }
      .desktop-image-dots { position:absolute; left:50%; bottom:8px; transform:translateX(-50%); display:flex; gap:4px; padding:4px 6px; border-radius:99px; background:rgba(20,32,26,.42); }
      .desktop-image-dots span { width:5px; height:5px; border-radius:50%; background:rgba(255,255,255,.58); }
      .desktop-image-dots span.is-active { background:#fff; }
      .desktop-image-hit-row { position:absolute; inset:0; display:flex; }
      .desktop-image-hit-row button { flex:1; border:0; background:transparent; cursor:pointer; }
      .desktop-listing-body { padding:10px 11px 12px; }
      .desktop-price-row { display:flex; align-items:baseline; justify-content:space-between; gap:10px; }
      .desktop-price-row strong { color:#14201A; font:800 15px Sora,sans-serif; letter-spacing:-.02em; }
      .desktop-price-row strong span { margin-left:2px; color:#6D746D; font:600 10px Inter,sans-serif; }
      .desktop-type-label { max-width:100px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; color:#6D746D; font:600 9px Inter,sans-serif; }
      .desktop-listing-body h3 { margin:3px 0 4px; color:#14201A; font:700 12px/1.25 Inter,sans-serif; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      .desktop-location { display:flex; align-items:center; gap:4px; color:#697069; font:500 9.5px Inter,sans-serif; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      .desktop-amenities { display:flex; align-items:center; gap:8px; margin-top:7px; color:#4E584F; overflow:hidden; }
      .desktop-amenities span { display:flex; align-items:center; gap:3px; white-space:nowrap; font:600 9px Inter,sans-serif; }
      .desktop-card-buttons { display:grid; grid-template-columns:1.35fr 1fr; gap:7px; margin-top:10px; }
      .desktop-card-buttons button { min-height:31px; border-radius:999px; font:700 9px Inter,sans-serif; letter-spacing:.01em; cursor:pointer; }
      .desktop-request-btn { border:1px solid #14201A; background:#14201A; color:#FBF8F0; }
      .desktop-request-btn:hover { background:#26372D; }
      .desktop-details-btn { border:1px solid #D4D1C8; background:#F8F7F3; color:#14201A; }
      .desktop-details-btn:hover { background:#F1EBDB; }
      .desktop-empty-state { padding:70px 20px; text-align:center; color:#6D746D; }
      .desktop-empty-state h3 { margin:0; color:#14201A; font:800 17px Sora,sans-serif; }
      .desktop-empty-state p { margin:8px 0 16px; font:500 12px Inter,sans-serif; }
      .desktop-empty-state button { border:0; border-radius:999px; background:#14201A; color:#FBF8F0; padding:10px 16px; font:700 11px Inter,sans-serif; cursor:pointer; }
      .desktop-feed-footer { min-height:46px; display:flex; align-items:center; justify-content:center; color:#7A827A; font:500 10px Inter,sans-serif; }
    }

    @media (min-width: 1280px) {
      .desktop-sidebar { flex-basis:260px !important; width:260px !important; }
      .desktop-listings-grid { grid-template-columns:repeat(4,minmax(0,1fr)); gap:18px; }
      .desktop-listing-image-wrap { height:196px; }
    }

    @media (min-width: 768px) and (max-width: 1023px) {
      .responsive-topbar { display:block !important; height:64px !important; }
      .responsive-topbar-inner { padding:0 16px !important; gap:12px !important; }
      .topbar-city { display:none !important; }
      .topbar-profile-copy { display:none !important; }
      .topbar-search-wrap { min-width:0 !important; flex:1 1 auto !important; max-width:none !important; height:38px !important; }
      .topbar-brand-text { font-size:16px !important; }
      .topbar-brand-mark { width:30px !important; height:30px !important; }
      .app-main-shell { min-height:calc(100vh - 64px) !important; padding-bottom:72px; }
      .app-nav { display:none !important; }
      .tablet-bottom-nav { position:fixed; left:0; right:0; bottom:0; z-index:90; height:68px; display:grid; grid-template-columns:repeat(5,minmax(0,1fr)); align-items:center; padding:0 14px; background:#14201A; border-top:1px solid rgba(245,240,228,.08); box-shadow:0 -8px 24px rgba(20,32,26,.16); }
      .tablet-bottom-item { min-width:0; height:100%; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:3px; border:0; background:transparent; color:#7A8C80; cursor:pointer; }
      .tablet-bottom-item.is-active { color:#FBF8F0; }
      .tablet-bottom-icon { position:relative; display:flex; align-items:center; justify-content:center; }
      .tablet-bottom-icon b { position:absolute; top:-6px; right:-11px; min-width:16px; height:16px; padding:0 4px; border-radius:99px; background:#C1512F; color:#fff; font:700 8px/16px Inter,sans-serif; }
      .tablet-bottom-item small { font:600 8.5px Inter,sans-serif; }
      .tablet-bottom-fab { width:46px; height:46px; justify-self:center; border:0; border-radius:50%; display:flex; align-items:center; justify-content:center; background:#FBF8F0; color:#14201A; box-shadow:0 7px 20px rgba(0,0,0,.25); cursor:pointer; }
      .web-home-content { padding-top:0 !important; }
      .home-page > .web-home-content > .web-subhero { display:none !important; }
      .tablet-home-toolbar { padding:14px 16px 6px; background:#FBF8F0; }
      .tablet-story-row, .tablet-category-row { display:flex; align-items:center; gap:14px; overflow-x:auto; scrollbar-width:none; }
      .tablet-story-row { padding:4px 0 13px; }
      .tablet-story-row button { flex:0 0 68px; display:flex; flex-direction:column; align-items:center; gap:5px; border:0; background:transparent; color:#606860; padding:0; }
      .tablet-story-row button > span { width:54px; height:54px; padding:3px; display:flex; align-items:center; justify-content:center; border-radius:50%; border:2px solid #B7C5BA; background:#fff; overflow:hidden; }
      .tablet-story-row button:nth-child(3n+1) > span { border-color:#A78BCB; }
      .tablet-story-row button:nth-child(3n+2) > span { border-color:#D3A36D; }
      .tablet-story-row button > span img { width:100%; height:100%; object-fit:cover; border-radius:50%; }
      .tablet-story-row button small { max-width:68px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font:600 8px Inter,sans-serif; }
      .tablet-story-row button.is-active { color:#14201A; }
      .tablet-category-row { padding:2px 0 12px; }
      .tablet-category-row button { flex:0 0 auto; min-height:32px; padding:0 14px; border:1px solid #D9D6CC; border-radius:999px; background:#fff; color:#30362F; font:600 10px Inter,sans-serif; }
      .tablet-category-row button.is-active { background:#14201A; border-color:#14201A; color:#FBF8F0; }
      .web-page { max-width:none !important; margin:0 !important; padding-bottom:80px !important; }
      .web-property-grid { grid-template-columns:repeat(2,minmax(0,1fr)) !important; gap:12px !important; padding:12px 16px 26px !important; background:#FBF8F0 !important; }
      .web-property-grid > * { border-radius:14px !important; }
      .web-page .web-surface { margin:0 !important; border:0 !important; border-radius:0 !important; box-shadow:none !important; background:#FBF8F0 !important; }
      .web-page > .web-home-content > .px-4[style*="marginTop"] { display:none !important; }
      .web-page > .web-home-content > .flex.items-center.justify-between { display:none !important; }
    }

    .tablet-bottom-nav { display:none; }
    @media (min-width: 768px) and (max-width: 1023px) {
      .tablet-bottom-nav { display:grid !important; }
    }
    @media (min-width: 1024px) {
      .app-nav { display:none !important; }
      .tablet-bottom-nav { display:none !important; }
    }

    /* ===== Clean desktop homepage filter + green navigation refresh ===== */
    @media (min-width: 1024px) {
      .desktop-sidebar {
        background:#14201A !important;
        border-right:1px solid rgba(251,248,240,.10) !important;
        color:#FBF8F0 !important;
      }
      .desktop-sidebar .sidebar-brand { color:#FBF8F0 !important; }
      .desktop-sidebar .sidebar-brand em { color:#B8842E !important; }
      .desktop-sidebar .sidebar-brand-mark { background:#F1EBDB !important; color:#2F7A55 !important; border-color:rgba(251,248,240,.14) !important; }
      .desktop-sidebar .sidebar-item { color:rgba(251,248,240,.72) !important; }
      .desktop-sidebar .sidebar-item:hover { background:rgba(251,248,240,.08) !important; color:#FBF8F0 !important; }
      .desktop-sidebar .sidebar-item.is-active { background:#F1EBDB !important; color:#14201A !important; }
      .desktop-sidebar .sidebar-item.is-active .sidebar-icon { color:#2F7A55 !important; }
      .desktop-sidebar .sidebar-icon { color:rgba(251,248,240,.72) !important; }
      .desktop-sidebar .sidebar-badge { background:#C1512F !important; }
      .desktop-sidebar .sidebar-help { background:#F1EBDB !important; color:#4D5A50 !important; }
      .desktop-sidebar .sidebar-footer { color:#FBF8F0 !important; }

      .desktop-filter-shell {
        position:relative;
        margin:0 24px 10px;
        padding:0;
      }
      .desktop-filter-toolbar {
        min-height:58px;
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:16px;
        padding:9px 10px 9px 12px;
        background:#FFFFFF;
        border:1px solid #E4E0D6;
        border-radius:14px;
        box-shadow:0 4px 16px rgba(20,32,26,.045);
      }
      .desktop-filter-primary,
      .desktop-filter-secondary {
        display:flex;
        align-items:center;
        gap:7px;
        min-width:0;
      }
      .desktop-filter-primary { flex:1 1 auto; }
      .desktop-filter-secondary { flex:0 0 auto; margin-left:auto; }
      .desktop-filter-shell .desktop-filter-primary > button,
      .desktop-filter-shell .desktop-filter-secondary > button {
        height:36px;
        border-radius:9px;
        transition:background .15s ease, border-color .15s ease, transform .15s ease;
      }
      .desktop-filter-shell .desktop-filter-primary > button:not(.desktop-filter-verified):not(.desktop-filter-more) {
        background:#F6F5F1 !important;
        color:#26312A !important;
        border:1px solid #E2DED4;
      }
      .desktop-filter-shell .desktop-filter-primary > button:not(.desktop-filter-verified):not(.desktop-filter-more):hover {
        background:#F1EBDB !important;
        border-color:#D7CFBA;
      }
      .desktop-filter-verified {
        display:inline-flex;
        align-items:center;
        justify-content:center;
        gap:6px;
        padding:0 11px;
        border:1px solid #DDE4DE;
        background:#F5F8F5;
        color:#3F5948;
        font:600 10.5px Inter,sans-serif;
        cursor:pointer;
        white-space:nowrap;
      }
      .desktop-filter-verified:hover { background:#EAF2EC; border-color:#C8D8CC; }
      .desktop-filter-verified.is-active { background:#E4F0E6; border-color:#BBD0BF; color:#2F7A55; }
      .desktop-filter-more {
        position:relative;
        display:inline-flex;
        align-items:center;
        justify-content:center;
        gap:6px;
        padding:0 12px;
        border:1px solid #14201A;
        background:#14201A;
        color:#FBF8F0;
        font:700 10.5px Inter,sans-serif;
        cursor:pointer;
        white-space:nowrap;
      }
      .desktop-filter-more:hover { background:#26372D; transform:translateY(-1px); }
      .desktop-filter-more b {
        position:absolute;
        top:6px;
        right:7px;
        width:5px;
        height:5px;
        border-radius:50%;
        background:#B8842E;
      }
      .desktop-result-count {
        color:#687169;
        font:600 10px Inter,sans-serif;
        white-space:nowrap;
      }
      .desktop-filter-sort {
        display:inline-flex;
        align-items:center;
        gap:6px;
        padding:0 10px;
        border:1px solid #E2DED4;
        background:#FFFFFF;
        color:#26312A;
        font:600 10px Inter,sans-serif;
        cursor:pointer;
        white-space:nowrap;
      }
      .desktop-filter-sort:hover,
      .desktop-filter-sort.is-active { background:#F1EBDB; border-color:#D8CFBA; }
      .desktop-filter-clear {
        padding:0 5px;
        border:0;
        background:transparent;
        color:#7B827B;
        font:600 10px Inter,sans-serif;
        cursor:pointer;
      }
      .desktop-filter-clear:hover { color:#C1512F; }
      .desktop-result-strip {
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:10px;
        padding:2px 28px 12px;
        color:#697169;
        font:500 10px Inter,sans-serif;
      }
      .desktop-result-active {
        display:inline-flex;
        align-items:center;
        padding:4px 8px;
        border-radius:999px;
        background:#EAF2EC;
        color:#2F7A55;
        font-weight:700;
      }
      .desktop-filter-shell + .desktop-result-strip { margin-top:0; }

      .desktop-filter-shell + .desktop-result-strip + .web-surface { margin-top:0 !important; }
    }

    .filter-sheet-panel { box-sizing:border-box; }
    @media (max-width:767px) {
      .filter-sheet-panel { max-height:calc(100dvh - 18px) !important; overflow-y:auto !important; }
    }
    `}</style>
  );
}