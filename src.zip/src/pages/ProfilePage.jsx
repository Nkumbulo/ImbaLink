import { useState, useEffect, useRef } from "react";
import {
  ChevronDown,
  Settings,
  Building2,
  Wrench,
  Handshake,
  Landmark,
  ArrowRight,
  LogOut,
  Crown,
  X,
  Check,
  Lock,
  Camera,
} from "lucide-react";
import { T } from "../styles/tokens";
import Avatar from "../components/common/Avatar";
import { useAuth } from "../auth/AuthContext"; // adjust path if needed

function useMediaQuery(query) {
  const [matches, setMatches] = useState(
    () => typeof window !== "undefined" && window.matchMedia(query).matches
  );

  useEffect(() => {
    const media = window.matchMedia(query);
    const update = () => setMatches(media.matches);
    update();
    media.addEventListener?.("change", update);
    return () => media.removeEventListener?.("change", update);
  }, [query]);

  return matches;
}

const GOLD = T.gold ?? "#C9A24B";

// Ecosystem hubs — order controls render order below.
const HUBS = [
  {
    tab: "landlord",
    hubType: "landlord",
    dark: true,
    iconBg: T.brick,
    icon: Building2,
    title: "Landlord Hub",
    subtitle: "Listings, tenants & viewing requests",
  },
  {
    tab: "contractors",
    hubType: "contractor",
    iconBg: T.jacaranda,
    icon: Wrench,
    title: "Contractor Hub",
    subtitle: "Find maintenance & property services",
  },
  {
    tab: "agent",
    hubType: "agent",
    iconBg: GOLD,
    icon: Handshake,
    title: "Agent Hub",
    subtitle: "Manage listings & client leads",
  },
  {
    tab: "company",
    hubType: "company",
    iconBg: T.teal ?? "#3E7C7C",
    icon: Landmark,
    title: "Company Hub",
    subtitle: "Agency accounts & team management",
  },
];

const SETTINGS_ROWS = ["Verify my identity", "Notification preferences", "Report a problem", "Help & safety"];

const PRO_PLAN = { id: "monthly", label: "Pro", price: "$10/month" };

const PRO_ROLE_CONTENT = {
  tenant: {
    title: "Tenant Pro",
    subtitle: "Build trust before you contact landlords.",
    badge: "Verified Renter",
    benefits: [
      "A verified renter badge appears on your profile and enquiries.",
      "Landlords can see that your identity has been verified before responding.",
      "Stand out from unverified enquiries and make your profile more trustworthy.",
    ],
    idLabel: "Government-issued picture ID",
    idHelp: "Upload a clear photo of your national ID, passport or driver's licence.",
    details: "We'll use your ID to verify that you are a real person and match your account details.",
  },
  landlord: {
    title: "Landlord Pro",
    subtitle: "Show tenants that your property account is genuine.",
    badge: "Verified Landlord",
    benefits: [
      "A verified landlord badge gives tenants more confidence when viewing your listings.",
      "Help genuine property owners stand out from unverified accounts.",
      "Build trust when tenants enquire, request viewings or contact you.",
    ],
    idLabel: "Government-issued picture ID",
    idHelp: "Upload a clear photo of your national ID, passport or driver's licence.",
    details: "Your identity is checked against your landlord account details before the badge is issued.",
  },
  agent: {
    title: "Agent Pro",
    subtitle: "Give clients confidence that they are dealing with a verified property professional.",
    badge: "Verified Agent",
    benefits: [
      "A verified agent badge helps clients identify trusted property professionals.",
      "Make your profile and property enquiries more credible.",
      "Build confidence before clients share information or arrange viewings.",
    ],
    idLabel: "Government-issued picture ID",
    idHelp: "Upload a clear photo of your national ID, passport or driver's licence.",
    details: "Your identity is verified against your agent account before your verified badge is activated.",
  },
  company: {
    title: "Company Pro",
    subtitle: "Verify the person behind the company account and strengthen business trust.",
    badge: "Verified Company",
    benefits: [
      "A verified company badge helps customers recognise a genuine business account.",
      "Increase trust when managing listings, enquiries and client relationships.",
      "Show that the company account has completed Imbalink's verification process.",
    ],
    idLabel: "Authorised representative's picture ID",
    idHelp: "Upload a clear photo of the ID of the person authorised to represent this company.",
    details: "The authorised representative's identity is checked before the company verified badge is issued.",
  },
  contractor: {
    title: "Contractor Pro",
    subtitle: "Show property owners that your service account is genuine.",
    badge: "Verified Contractor",
    benefits: [
      "A verified contractor badge helps property owners identify trusted service providers.",
      "Stand out when responding to maintenance and property-service requests.",
      "Build confidence before customers arrange work with you.",
    ],
    idLabel: "Government-issued picture ID",
    idHelp: "Upload a clear photo of your national ID, passport or driver's licence.",
    details: "Your identity is verified against your contractor account before the badge is activated.",
  },
};

function getProRole(profile, accountLabel) {
  const label = typeof accountLabel === "string" ? accountLabel : "";
  if (label.startsWith("Company")) return "company";
  if (label.startsWith("Agent")) return "agent";
  if (label.startsWith("Landlord")) return "landlord";
  if (label.startsWith("Contractor")) return "contractor";
  return "tenant";
}

// Resolves a consistent identity from `profile` (persisted db profile) with
// `user` (live auth session) as a fallback — so the header, avatar, and sign-out
// button never disagree about who's signed in.
function resolveIdentity(profile, user) {
  const name = profile?.name || user?.name || profile?.firstName || user?.firstName || null;
  const firstName = profile?.firstName || user?.firstName || (profile?.name || user?.name || "").split(" ")[0] || null;
  const initial = (firstName || name || "U").charAt(0).toUpperCase();
  return { name, firstName, initial };
}

// Priority order when a user holds more than one role — highest listed wins.
function resolveAccountLabel({ companyRegistration, agentRegistration, landlordRegistration, contractorRegistration }) {
  if (companyRegistration) return "Company Account";
  if (agentRegistration) return "Agent Account";
  if (landlordRegistration) return "Landlord Account";
  if (contractorRegistration) return "Contractor Account";
  return "Tenant Account";
}

function Stat({ n, label, onClick }) {
  return (
    <button
      onClick={onClick}
      className="flex-1 flex flex-col items-center justify-center gap-0.5 rounded-xl py-2.5 transition-transform active:scale-95"
      style={{ background: T.paperDim, WebkitTapHighlightColor: "transparent" }}
    >
      <span className="f-display font-bold" style={{ color: T.ink, fontSize: 15 }}>{n}</span>
      <span className="f-body" style={{ color: T.ink60, fontSize: 10.5 }}>{label}</span>
    </button>
  );
}

function HubButton({ onClick, iconBg, icon: Icon, title, subtitle, dark, locked }) {
  return (
    <button
      onClick={locked ? undefined : onClick}
      disabled={locked}
      className="w-full rounded-2xl p-3.5 flex items-center gap-3 text-left mb-2"
      style={{
        background: dark && !locked ? T.ink : T.paperDim,
        color: dark && !locked ? T.paper : T.ink,
        opacity: locked ? 0.5 : 1,
        cursor: locked ? "not-allowed" : "pointer",
      }}
    >
      <span className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: locked ? T.ink60 : iconBg, color: T.paper }}>
        <Icon size={18}/>
      </span>
      <span className="flex-1 min-w-0">
        <span className="f-display font-semibold block" style={{ fontSize: 13 }}>{title}</span>
        <span className="f-body block mt-0.5" style={{ color: dark && !locked ? undefined : T.ink60, opacity: dark && !locked ? 0.65 : 1, fontSize: 10.5 }}>
          {subtitle}
        </span>
      </span>
      {locked ? <Lock size={14} style={{ color: T.ink60 }}/> : <ArrowRight size={16}/>}
    </button>
  );
}

function ProBadge({ isPro, onClick }) {
  if (isPro) {
    return (
      <span className="flex items-center gap-1 rounded-full pl-1.5 pr-2 py-0.5 shrink-0" style={{ background: `${GOLD}1F` }}>
        <Crown size={10.5} style={{ color: GOLD }}/>
        <span className="f-mono font-semibold" style={{ color: GOLD, fontSize: 9.5, letterSpacing: ".04em" }}>PRO</span>
      </span>
    );
  }
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-1 rounded-full pl-1.5 pr-2 py-0.5 shrink-0 transition-transform active:scale-95"
      style={{ background: `${GOLD}1F` }}
    >
      <Crown size={10.5} style={{ color: GOLD }}/>
      <span className="f-mono font-semibold" style={{ color: GOLD, fontSize: 9.5, letterSpacing: ".04em" }}>GO PRO</span>
    </button>
  );
}

function ProRegistrationModal({ profile, user, accountLabel, onClose, onSubmit }) {
  const { name: resolvedName } = resolveIdentity(profile, user);
  const role = getProRole(profile, accountLabel);
  const content = PRO_ROLE_CONTENT[role] || PRO_ROLE_CONTENT.tenant;

  const [fullName, setFullName] = useState(resolvedName || "");
  const [email, setEmail] = useState(profile?.email || user?.email || "");
  const [phone, setPhone] = useState(profile?.phone || user?.phone || "");
  const [idFile, setIdFile] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [visible, setVisible] = useState(false);
  const closeTimerRef = useRef(null);

  useEffect(() => {
    const raf = requestAnimationFrame(() => setVisible(true));
    return () => {
      cancelAnimationFrame(raf);
      if (closeTimerRef.current) clearTimeout(closeTimerRef.current);
    };
  }, []);

  useEffect(() => {
    if (!fullName && resolvedName) setFullName(resolvedName);
    if (!email && (profile?.email || user?.email)) setEmail(profile?.email || user?.email || "");
    if (!phone && (profile?.phone || user?.phone)) setPhone(profile?.phone || user?.phone || "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile, user]);

  const handleClose = () => {
    setVisible(false);
    closeTimerRef.current = setTimeout(onClose, 280);
  };

  const canSubmit = fullName.trim() && email.trim() && idFile && !submitting;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!canSubmit) return;

    setSubmitting(true);
    try {
      await onSubmit({
        fullName: fullName.trim(),
        email: email.trim(),
        phone: phone.trim(),
        accountType: role,
        verificationDocument: idFile,
      });
      setDone(true);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center"
      style={{
        background: "rgba(0,0,0,.5)",
        opacity: visible ? 1 : 0,
        transition: "opacity .28s ease",
      }}
    >
      <div
        className="w-full sm:max-w-sm max-h-[92vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl p-5"
        style={{
          background: T.paper,
          transform: visible ? "translateY(0)" : "translateY(100%)",
          transition: "transform .32s cubic-bezier(0.32, 0.72, 0, 1)",
        }}
      >
        {done ? (
          <div className="py-6 flex flex-col items-center text-center">
            <span className="w-14 h-14 rounded-full flex items-center justify-center mb-4" style={{ background: `${GOLD}1F` }}>
              <Check size={26} style={{ color: GOLD }} />
            </span>
            <div className="f-display font-bold" style={{ color: T.ink, fontSize: 16 }}>
              Verification submitted
            </div>
            <div className="f-body mt-1.5" style={{ color: T.ink60, fontSize: 12.5 }}>
              Your {content.badge} request is being reviewed. Your badge will appear once verification is approved.
            </div>
            <button
              onClick={handleClose}
              className="w-full mt-6 f-body font-semibold px-4 py-3 rounded-xl"
              style={{ background: T.ink, color: T.paper, fontSize: 13 }}
            >
              Done
            </button>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: `${GOLD}1F` }}>
                  <Crown size={16} style={{ color: GOLD }} />
                </span>
                <div>
                  <div className="f-display font-bold" style={{ color: T.ink, fontSize: 16 }}>
                    {content.title}
                  </div>
                  <div className="f-mono" style={{ color: GOLD, fontSize: 9, letterSpacing: ".06em" }}>
                    {content.badge.toUpperCase()}
                  </div>
                </div>
              </div>
              <button onClick={handleClose} style={{ color: T.ink60 }}>
                <X size={18} />
              </button>
            </div>

            <div className="f-body mt-3 mb-4" style={{ color: T.ink60, fontSize: 12.5 }}>
              {content.subtitle}
            </div>

            <div
              className="rounded-2xl p-3.5 mb-4"
              style={{ background: T.paperDim }}
            >
              <div className="f-display font-semibold" style={{ color: T.ink, fontSize: 13 }}>
                Why get verified?
              </div>
              <ul className="mt-2 space-y-2">
                {content.benefits.map((benefit) => (
                  <li key={benefit} className="flex items-start gap-2 f-body" style={{ color: T.ink, fontSize: 11.5 }}>
                    <Check size={13} style={{ color: GOLD, marginTop: 1, flexShrink: 0 }} />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div
              className="rounded-2xl p-3.5 mb-4 flex items-start gap-3"
              style={{ background: `${GOLD}12`, border: `1px solid ${GOLD}30` }}
            >
              <Camera size={18} style={{ color: GOLD, flexShrink: 0, marginTop: 1 }} />
              <div>
                <div className="f-display font-semibold" style={{ color: T.ink, fontSize: 12.5 }}>
                  Identity verification required
                </div>
                <div className="f-body mt-1" style={{ color: T.ink60, fontSize: 11.5 }}>
                  {content.details}
                </div>
              </div>
            </div>

            <div
              className="rounded-xl p-3 mb-4"
              style={{ background: T.paperDim }}
            >
              <div className="f-body font-semibold" style={{ color: T.ink, fontSize: 12 }}>
                Pro membership
              </div>
              <div className="f-body mt-0.5" style={{ color: T.ink60, fontSize: 11 }}>
                {PRO_PLAN.price} · Includes your {content.badge} verification process.
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              <input
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Full name"
                required
                className="w-full f-body px-3.5 py-3 rounded-xl outline-none"
                style={{ background: T.paperDim, color: T.ink, fontSize: 13 }}
              />

              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                type="email"
                placeholder="Email address"
                required
                className="w-full f-body px-3.5 py-3 rounded-xl outline-none"
                style={{ background: T.paperDim, color: T.ink, fontSize: 13 }}
              />

              <input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                type="tel"
                placeholder="Phone number (optional)"
                className="w-full f-body px-3.5 py-3 rounded-xl outline-none"
                style={{ background: T.paperDim, color: T.ink, fontSize: 13 }}
              />

              <label
                className="block rounded-xl p-3.5 cursor-pointer"
                style={{ background: T.paperDim, border: `1px dashed ${T.ink60}55` }}
              >
                <div className="flex items-center gap-2">
                  <Camera size={17} style={{ color: GOLD }} />
                  <div className="f-body font-semibold" style={{ color: T.ink, fontSize: 12.5 }}>
                    {content.idLabel}
                  </div>
                </div>
                <div className="f-body mt-1" style={{ color: T.ink60, fontSize: 10.5 }}>
                  {content.idHelp}
                </div>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => setIdFile(e.target.files?.[0] || null)}
                  className="w-full mt-3 f-body"
                  required
                  style={{ color: T.ink60, fontSize: 11 }}
                />
                {idFile && (
                  <div className="f-body mt-2 font-semibold" style={{ color: T.ink, fontSize: 10.5 }}>
                    Selected: {idFile.name}
                  </div>
                )}
              </label>

              <button
                type="submit"
                disabled={!canSubmit}
                className="w-full f-body font-semibold px-4 py-3.5 rounded-xl mt-1"
                style={{ background: T.ink, color: T.paper, fontSize: 13, opacity: canSubmit ? 1 : 0.5 }}
              >
                {submitting ? "Submitting…" : `Start ${content.badge} verification`}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}

export default function ProfilePage({
  saved,
  liked,
  threads,
  onNavigate,
  profile,
  proRegistration,
  onRegisterPro,
  landlordRegistration,
  agentRegistration,
  companyRegistration,
  contractorRegistration,
  activeHubType,
}) {
  const { signOut, user } = useAuth();
  const [showProModal, setShowProModal] = useState(false);
  const isTabletOrDesktop = useMediaQuery("(min-width: 768px)");

  // Defensive: these can briefly be undefined before useDatabase hydrates.
  const savedCount = saved?.size ?? 0;
  const likedCount = liked?.size ?? 0;
  const chatCount = threads ? Object.keys(threads).length : 0;

  const { name: displayName, firstName, initial } = resolveIdentity(profile, user);
  const isPro = !!proRegistration;
  const accountLabel = resolveAccountLabel({ companyRegistration, agentRegistration, landlordRegistration, contractorRegistration });

  const handleProSubmit = async (data) => {
    if (onRegisterPro) await onRegisterPro(data);
  };

  if (isTabletOrDesktop) {
    return (
      <div className="pb-8 web-page profile-desktop">
        <div className="px-4 pt-3">
          <div className="f-display font-bold" style={{ color: T.ink, fontSize: 24 }}>Profile</div>
        </div>

        <div className="web-surface profile-desktop-card" style={{ background: T.paper, borderRadius: 18, marginTop: 10 }}>
          <div className="profile-desktop-header">
            <div className="profile-desktop-identity">
              <Avatar grad={["#6E63B8", "#3E3670"]} letter={initial} size={84} />
              <div>
                <div className="profile-desktop-name">{displayName || "Profile"}</div>
                <div className="profile-desktop-meta">
                  <span>{accountLabel}</span>
                  <ProBadge isPro={isPro} onClick={() => setShowProModal(true)} />
                </div>
              </div>
            </div>
            <div className="profile-desktop-header-actions">
              <button className="profile-desktop-icon-btn" aria-label="Settings">
                <Settings size={18} />
              </button>
              <button className="profile-desktop-signout" onClick={signOut}>
                <LogOut size={15} />
                Sign out{firstName ? ` (${firstName})` : ""}
              </button>
            </div>
          </div>

          <div className="profile-desktop-stats">
            <Stat n={savedCount} label="Saved" onClick={() => onNavigate("saved", "saved")} />
            <Stat n={likedCount} label="Liked" onClick={() => onNavigate("saved", "liked")} />
            <Stat n={chatCount} label="Chats" onClick={() => onNavigate("messages")} />
          </div>

          <div className="profile-desktop-columns">
            <div className="profile-desktop-hubs">
              <div className="profile-desktop-section-title">Imbalink ecosystem</div>
              {activeHubType && (
                <div className="profile-desktop-hub-note">
                  You're registered as a {activeHubType}. One hub registration per account.
                </div>
              )}
              <div className="profile-hub-grid">
                {HUBS.map((hub) => (
                  <HubButton
                    key={hub.tab}
                    onClick={() => onNavigate(hub.tab)}
                    locked={!!activeHubType && activeHubType !== hub.hubType}
                    {...hub}
                  />
                ))}
              </div>
            </div>

            <div className="profile-desktop-settings">
              <div className="profile-desktop-section-title">Settings</div>
              <div className="profile-desktop-settings-list">
                {SETTINGS_ROWS.map((row) => (
                  <div key={row} className="profile-desktop-settings-row">
                    {row}
                    <ChevronDown size={14} style={{ transform: "rotate(-90deg)", color: T.ink60 }} />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {showProModal && (
          <ProRegistrationModal
            profile={profile}
            user={user}
            onClose={() => setShowProModal(false)}
            onSubmit={handleProSubmit}
          />
        )}
      </div>
    );
  }

  return (
    <div className="pb-8 web-page">
      <div className="flex items-center justify-between px-4 pt-3">
        <div className="f-display font-bold" style={{ color: T.paper, fontSize: 19 }}>{displayName || "Profile"}</div>
        <button style={{ color: T.paper }}><Settings size={19}/></button>
      </div>

      <div className="web-surface" style={{ background: T.paper, borderRadius: 18, marginTop: 10 }}>
        {/* Avatar + stats */}
        <div className="flex items-center gap-4 px-4 pt-5 pb-4">
          <Avatar grad={["#6E63B8", "#3E3670"]} letter={initial} size={64}/>
          <div className="flex-1 flex items-center gap-2">
            {/* second arg tells App.jsx which CollectionsPage sub-view to open */}
            <Stat n={savedCount} label="Saved" onClick={() => onNavigate("saved", "saved")}/>
            <Stat n={likedCount} label="Liked" onClick={() => onNavigate("saved", "liked")}/>
            <Stat n={chatCount} label="Chats" onClick={() => onNavigate("messages")}/>
          </div>
        </div>

        {/* Account type */}
        <div className="px-4 pb-4">
          <div className="flex items-center gap-2">
            <span className="f-body" style={{ color: T.ink60, fontSize: 12 }}>{accountLabel}</span>
            <ProBadge isPro={isPro} onClick={() => setShowProModal(true)}/>
          </div>
        </div>

        {/* Ecosystem hubs */}
        <div className="px-4 pb-2">
          <div className="f-mono mb-2" style={{ color: T.ink60, fontSize: 10, letterSpacing: ".14em" }}>IMBALINK ECOSYSTEM</div>
          {activeHubType && (
            <div className="f-body mb-2.5" style={{ color: T.ink60, fontSize: 11 }}>
              You're registered as a {activeHubType}. One hub registration per account.
            </div>
          )}
          {HUBS.map((hub) => (
            <HubButton
              key={hub.tab}
              onClick={() => onNavigate(hub.tab)}
              locked={!!activeHubType && activeHubType !== hub.hubType}
              {...hub}
            />
          ))}
        </div>

        {/* Settings rows */}
        <div className="px-4 pt-5 pb-6 space-y-2">
          {SETTINGS_ROWS.map((row, i) => (
            <div
              key={row}
              className="rise flex items-center justify-between f-body px-4 py-3.5 rounded-xl"
              style={{ background: T.paperDim, color: T.ink, animationDelay: `${i * 30}ms`, fontSize: 13 }}
            >
              {row}
              <ChevronDown size={14} style={{ transform: "rotate(-90deg)", color: T.ink60 }}/>
            </div>
          ))}
        </div>

        {/* Sign out */}
        <div className="px-4 pb-6">
          <button
            onClick={signOut}
            className="w-full flex items-center justify-center gap-2 f-body font-semibold px-4 py-3.5 rounded-xl"
            style={{ background: "rgba(184,61,49,.1)", color: T.brick, fontSize: 13 }}
          >
            <LogOut size={15}/>
            Sign out{firstName ? ` (${firstName})` : ""}
          </button>
        </div>
      </div>

      {showProModal && (
        <ProRegistrationModal
          profile={profile}
          user={user}
          onClose={() => setShowProModal(false)}
          onSubmit={handleProSubmit}
        />
      )}
    </div>
  );
}