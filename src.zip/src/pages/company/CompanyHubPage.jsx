import { useState } from "react";
import { Plus, Home, UsersRound, MessageCircle, ShieldCheck, ChevronRight, Clock3 } from "lucide-react";
import { T } from "../../styles/tokens";
import ListingForm from "../../components/landlord/ListingForm";
import CompanyRegistration from "../../components/company/CompanyRegistration";

export default function CompanyHubPage({ properties, teamMembers, threads, onCreateListing, onOpenProperty, companyRegistration, onRegisterCompany, profile }) {
  const [showForm, setShowForm] = useState(false);
  const [showRegistration, setShowRegistration] = useState(false);
  const companyListings = properties.filter(p => String(p.companyId || "") === String(profile?.id || "local-user"));
  const staff = teamMembers || [];
  const activeChats = Object.keys(threads).length;
  const verified = companyListings.filter(p => p.verification === "verified").length;

  const stats = [
    [companyListings.length, "Listings", Home],
    [staff.length, "Agents", UsersRound],
    [activeChats, "Messages", MessageCircle],
    [verified, "Verified", ShieldCheck]
  ];

  return (
    <div className="pb-8 web-page">
      <div className="px-4 pt-3 pb-4">
        <div className="f-display font-bold" style={{ color: T.paper, fontSize: 19 }}>Company Hub</div>
        <div className="f-body mt-1" style={{ color: "rgba(251,248,240,.62)", fontSize: 11.5 }}>Register first, then manage listings, your team and client conversations.</div>
        <button onClick={() => setShowRegistration(true)} className="w-full mt-3 rounded-2xl p-3 text-left" style={{background:T.paper,color:T.ink}}><div className="f-display font-semibold" style={{fontSize:12.5}}>{companyRegistration ? "Company registration" : "Register a company"}</div><div className="f-body mt-0.5" style={{fontSize:10,color:T.ink60}}>{companyRegistration ? `Status: ${companyRegistration.verificationStatus || "pending"}` : "Complete business and licensing checks before publishing a listing."}</div></button>
      </div>

      <div className="web-surface" style={{ background: T.paper, borderRadius: 18, minHeight: 600 }}>
        <div className="web-stats-grid grid grid-cols-4 gap-2 px-4 pt-5">
          {stats.map(([n, label, Icon]) => (
            <div key={label} className="rounded-2xl p-2.5 text-center" style={{ background: T.paperDim }}>
              <Icon size={15} className="mx-auto mb-1" style={{ color: T.jacaranda }}/>
              <div className="f-display font-bold" style={{ color: T.ink, fontSize: 15 }}>{n}</div>
              <div className="f-body" style={{ color: T.ink60, fontSize: 9.5 }}>{label}</div>
            </div>
          ))}
        </div>

        <div className="px-4 pt-5">
          <button disabled={!companyRegistration} onClick={() => setShowForm(true)} className="w-full rounded-2xl p-3.5 flex items-center justify-between" style={{ background: companyRegistration ? T.ink : T.ink60, color: T.paper, opacity: companyRegistration ? 1 : .65 }}>
            <div className="flex items-center gap-3"><span className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: T.brick }}><Plus size={18}/></span><div className="text-left"><div className="f-display font-semibold" style={{ fontSize: 13 }}>Add listing</div><div className="f-body opacity-65" style={{ fontSize: 10.5 }}>Publish a listing under your company</div></div></div>
            <ChevronRight size={17}/>
          </button>
        </div>

        <div className="px-4 pt-6">
          <div className="f-mono mb-2" style={{ color: T.ink60, fontSize: 10, letterSpacing: ".16em" }}>COMPANY LISTINGS</div>
          <div className="space-y-2">
            {companyListings.slice(0, 8).map(p => (
              <button key={p.id} onClick={() => onOpenProperty(p)} className="w-full text-left flex items-center gap-3 p-3 rounded-2xl" style={{ background: T.paperDim }}>
                <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0" style={{ background: `linear-gradient(135deg, ${p.grad?.[0] || T.jacaranda}, ${p.grad?.[1] || T.brick})` }}><Home size={19} color={T.paper}/></div>
                <div className="min-w-0 flex-1">
                  <div className="f-body font-semibold truncate" style={{ color: T.ink, fontSize: 12.5 }}>{p.title}</div>
                  <div className="f-body mt-0.5 truncate" style={{ color: T.ink60, fontSize: 10.5 }}>{p.suburb} · ${p.rent}/mo</div>
                </div>
                <span className="f-body px-2 py-1 rounded-full shrink-0" style={{ background: p.verification === "verified" ? "rgba(47,122,85,.12)" : "rgba(184,132,46,.13)", color: p.verification === "verified" ? T.msasa : T.ochre, fontSize: 9.5 }}>
                  {p.verification === "verified" ? "Verified" : "Pending"}
                </span>
              </button>
            ))}
          </div>
        </div>

        <div className="px-4 pt-6">
          <div className="f-mono mb-2" style={{ color: T.ink60, fontSize: 10, letterSpacing: ".16em" }}>TEAM MEMBERS</div>
          {staff.length === 0 ? (
            <div className="rounded-2xl p-4 flex items-center gap-3" style={{ background: T.paperDim }}>
              <Clock3 size={17} style={{ color: T.ink60 }}/>
              <span className="f-body" style={{ color: T.ink60, fontSize: 11.5 }}>No agents added to your team yet.</span>
            </div>
          ) : staff.slice(0, 4).map(member => (
            <div key={member.id} className="rounded-2xl p-3 mb-2 flex items-center gap-3" style={{ background: T.paperDim }}>
              <UsersRound size={17} style={{ color: T.jacaranda }}/>
              <div className="flex-1"><div className="f-body font-semibold" style={{ color: T.ink, fontSize: 12 }}>{member.name}</div><div className="f-body" style={{ color: T.ink60, fontSize: 10.5 }}>{member.role || "Agent"}</div></div>
              <span className="f-body font-semibold" style={{ color: T.jacarandaDeep, fontSize: 10 }}>Manage</span>
            </div>
          ))}
        </div>
      </div>

      {showForm && companyRegistration && <ListingForm onClose={() => setShowForm(false)} onCreate={(listing) => { onCreateListing(listing); setShowForm(false); }}/>}
      {showRegistration && <CompanyRegistration profile={profile} onClose={() => setShowRegistration(false)} onSubmit={async data => { await onRegisterCompany(data); setShowRegistration(false); }} />}
    </div>
  );
}
