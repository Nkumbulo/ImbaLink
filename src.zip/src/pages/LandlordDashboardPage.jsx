import { useEffect, useState } from "react";
import { Plus, Home, Eye, MessageCircle, ShieldCheck, ChevronRight, Clock3 } from "lucide-react";
import { T } from "../styles/tokens";
import ListingForm from "../components/landlord/ListingForm";
import LandlordRegistration from "../components/landlord/LandlordRegistration";

// Simple media query hook (same pattern used elsewhere)
function useMediaQuery(query) {
  const [matches, setMatches] = useState(
    () => typeof window !== "undefined" && window.matchMedia(query).matches
  );
  useEffect(() => {
    const media = window.matchMedia(query);
    const update = () => setMatches(media.matches);
    update();
    media.addEventListener?.("change", update);
    return () => media.removeEventListener?.("change", update);
  }, [query]);
  return matches;
}

export default function LandlordDashboardPage({
  properties,
  viewingRequested,
  threads,
  onCreateListing,
  onOpenProperty,
  landlordRegistration,
  onRegisterLandlord,
  profile,
}) {
  const [showForm, setShowForm] = useState(false);
  const [showRegistration, setShowRegistration] = useState(false);
  const isTabletOrDesktop = useMediaQuery("(min-width: 768px)");
  const isDesktop = useMediaQuery("(min-width: 1024px)");

  const myListings = properties.filter(
    (p) => String(p.userId || "") === String(profile?.id || "local-user")
  );
  const requested = Object.keys(viewingRequested).filter((id) => viewingRequested[id]);
  const activeChats = Object.keys(threads).length;
  const verified = myListings.filter((p) => p.verification === "verified").length;

  const stats = [
    [myListings.length, "Listings", Home],
    [requested.length, "Viewings", Eye],
    [activeChats, "Messages", MessageCircle],
    [verified, "Verified", ShieldCheck],
  ];

  // Layout adjustments for larger screens
  const containerStyle = {
    maxWidth: isDesktop ? 1200 : "100%",
    margin: isDesktop ? "0 auto" : undefined,
    padding: isTabletOrDesktop ? "24px" : "16px",
  };

  const registrationAndAddRowStyle = isTabletOrDesktop
    ? {
        display: "flex",
        gap: 16,
        marginBottom: 24,
      }
    : {};

  const registrationBtnStyle = isTabletOrDesktop
    ? { flex: 1, marginTop: 0 }
    : { marginTop: 12 };

  const addBtnStyle = isTabletOrDesktop
    ? { flex: 1, marginTop: 0 }
    : { marginTop: 16 };

  const statsGridStyle = isTabletOrDesktop
    ? { gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }
    : { gridTemplateColumns: "repeat(4, 1fr)", gap: 8 };

  const listingsAndRequestsRowStyle = isTabletOrDesktop
    ? {
        display: "grid",
        gridTemplateColumns: isDesktop ? "1.5fr 1fr" : "1fr",
        gap: 24,
        marginTop: 32,
      }
    : { marginTop: 24 };

  // On mobile the page sits on the app shell's dark background, so the
  // stats/listings section needs its own light card (as it always had)
  // for the muted ink60 labels inside it to stay readable. On tablet/
  // desktop the page background is already light, so no extra card is
  // needed there.
  const statsSectionWrapperProps = isTabletOrDesktop
    ? {}
    : {
        className: "web-surface",
        style: { background: T.paper, borderRadius: 18, margin: "24px -16px 0", padding: "20px 16px 24px" },
      };

  return (
    <div className="pb-8 web-page">
      <div style={containerStyle}>
        {/* Header */}
        <div className="f-display font-bold" style={{ color: T.paper, fontSize: isDesktop ? 24 : 19 }}>
          Landlord Hub
        </div>
        <div
          className="f-body mt-1"
          style={{ color: "rgba(251,248,240,.62)", fontSize: isDesktop ? 13 : 11.5 }}
        >
          Register first, then manage properties, viewings and tenant conversations.
        </div>

        {/* Registration and Add Property row (flex on larger screens) */}
        <div style={registrationAndAddRowStyle}>
          {/* Registration button */}
          <button
            onClick={() => setShowRegistration(true)}
            className="rounded-2xl p-3 text-left"
            style={{
              ...registrationBtnStyle,
              background: T.paper,
              color: T.ink,
              width: "100%",
            }}
          >
            <div className="f-display font-semibold" style={{ fontSize: isDesktop ? 14 : 12.5 }}>
              {landlordRegistration ? "Landlord registration" : "Register as a landlord"}
            </div>
            <div className="f-body mt-0.5" style={{ fontSize: isDesktop ? 11 : 10, color: T.ink60 }}>
              {landlordRegistration
                ? `Status: ${landlordRegistration.verificationStatus || "pending"}`
                : "Complete identity and authority checks before publishing a listing."}
            </div>
          </button>

          {/* Add Property button */}
          <button
            disabled={!landlordRegistration}
            onClick={() => setShowForm(true)}
            className="rounded-2xl p-3.5 flex items-center justify-between"
            style={{
              ...addBtnStyle,
              width: "100%",
              background: landlordRegistration ? T.ink : T.ink60,
              color: T.paper,
              opacity: landlordRegistration ? 1 : 0.65,
            }}
          >
            <div className="flex items-center gap-3">
              <span
                className="w-9 h-9 rounded-full flex items-center justify-center"
                style={{ background: T.brick }}
              >
                <Plus size={18} />
              </span>
              <div className="text-left">
                <div className="f-display font-semibold" style={{ fontSize: isDesktop ? 14 : 13 }}>
                  Add property
                </div>
                <div className="f-body opacity-65" style={{ fontSize: isDesktop ? 11 : 10.5 }}>
                  Publish a rental listing
                </div>
              </div>
            </div>
            <ChevronRight size={17} />
          </button>
        </div>

        {/* Stats grid + listings/requests: on mobile, wrapped in a light
            card (statsSectionWrapperProps) since the page itself sits on a
            dark background there; on tablet/desktop the wrapper is a no-op
            because the page background is already light. */}
        <div {...statsSectionWrapperProps}>
        <div className="grid" style={statsGridStyle}>
          {stats.map(([n, label, Icon]) => (
            <div
              key={label}
              className="rounded-2xl p-2.5 text-center"
              style={{ background: T.paperDim }}
            >
              <Icon size={isDesktop ? 20 : 15} className="mx-auto mb-1" style={{ color: T.jacaranda }} />
              <div className="f-display font-bold" style={{ color: T.ink, fontSize: isDesktop ? 18 : 15 }}>
                {n}
              </div>
              <div className="f-body" style={{ color: T.ink60, fontSize: isDesktop ? 11 : 9.5 }}>
                {label}
              </div>
            </div>
          ))}
        </div>

        {/* Listings and Viewing Requests two-column on larger screens */}
        <div style={listingsAndRequestsRowStyle}>
          {/* Your Listings */}
          <div>
            <div
              className="f-mono mb-2"
              style={{ color: T.ink60, fontSize: 10, letterSpacing: ".16em" }}
            >
              YOUR LISTINGS
            </div>
            <div className="space-y-2">
              {myListings.slice(0, 8).map((p) => (
                <button
                  key={p.id}
                  onClick={() => onOpenProperty(p)}
                  className="w-full text-left flex items-center gap-3 p-3 rounded-2xl"
                  style={{ background: T.paperDim }}
                >
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0"
                    style={{
                      background: `linear-gradient(135deg, ${p.grad?.[0] || T.jacaranda}, ${
                        p.grad?.[1] || T.brick
                      })`,
                    }}
                  >
                    <Home size={19} color={T.paper} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="f-body font-semibold truncate" style={{ color: T.ink, fontSize: 12.5 }}>
                      {p.title}
                    </div>
                    <div className="f-body mt-0.5 truncate" style={{ color: T.ink60, fontSize: 10.5 }}>
                      {p.suburb} · ${p.rent}/mo
                    </div>
                  </div>
                  <span
                    className="f-body px-2 py-1 rounded-full shrink-0"
                    style={{
                      background:
                        p.verification === "verified"
                          ? "rgba(47,122,85,.12)"
                          : "rgba(184,132,46,.13)",
                      color: p.verification === "verified" ? T.msasa : T.ochre,
                      fontSize: 9.5,
                    }}
                  >
                    {p.verification === "verified" ? "Verified" : "Pending"}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Viewing Requests */}
          <div>
            <div
              className="f-mono mb-2"
              style={{ color: T.ink60, fontSize: 10, letterSpacing: ".16em" }}
            >
              VIEWING REQUESTS
            </div>
            {requested.length === 0 ? (
              <div className="rounded-2xl p-4 flex items-center gap-3" style={{ background: T.paperDim }}>
                <Clock3 size={17} style={{ color: T.ink60 }} />
                <span className="f-body" style={{ color: T.ink60, fontSize: 11.5 }}>
                  No new viewing requests yet.
                </span>
              </div>
            ) : (
              requested.slice(0, 4).map((id) => {
                const p = properties.find((x) => x.id === Number(id));
                return p ? (
                  <div
                    key={id}
                    className="rounded-2xl p-3 mb-2 flex items-center gap-3"
                    style={{ background: T.paperDim }}
                  >
                    <Eye size={17} style={{ color: T.jacaranda }} />
                    <div className="flex-1">
                      <div className="f-body font-semibold" style={{ color: T.ink, fontSize: 12 }}>
                        {p.title}
                      </div>
                      <div className="f-body" style={{ color: T.ink60, fontSize: 10.5 }}>
                        Tenant requested a viewing
                      </div>
                    </div>
                    <span className="f-body font-semibold" style={{ color: T.jacarandaDeep, fontSize: 10 }}>
                      Review
                    </span>
                  </div>
                ) : null;
              })
            )}
          </div>
        </div>
        </div>
      </div>

      {showForm && landlordRegistration && (
        <ListingForm
          onClose={() => setShowForm(false)}
          onCreate={(listing) => {
            onCreateListing(listing);
            setShowForm(false);
          }}
        />
      )}
      {showRegistration && (
        <LandlordRegistration
          profile={profile}
          onClose={() => setShowRegistration(false)}
          onSubmit={async (data) => {
            await onRegisterLandlord(data);
            setShowRegistration(false);
          }}
        />
      )}
    </div>
  );
}