import { useMemo, useState } from "react";
import { Plus, Home, Eye, MessageCircle, ShieldCheck, ChevronRight, Clock3 } from "lucide-react";
import { T } from "../styles/tokens";
import ListingForm from "../components/landlord/ListingForm";
import LandlordRegistration from "../components/landlord/LandlordRegistration";

export default function LandlordDashboardPage({ properties, viewingRequested, threads, onCreateListing, onOpenProperty, landlordRegistration, onRegisterLandlord, profile }) {
  const [showForm, setShowForm] = useState(false);
  const [showRegistration, setShowRegistration] = useState(false);
  const myListings = properties.filter(p => String(p.userId || "") === String(profile?.id || "local-user"));
  const requested = Object.keys(viewingRequested).filter(id => viewingRequested[id]);
  const activeChats = Object.keys(threads).length;
  const verified = myListings.filter(p => p.verification === "verified").length;

  const stats = [
    [myListings.length, "Listings", Home],
    [requested.length, "Viewings", Eye],
    [activeChats, "Messages", MessageCircle],
    [verified, "Verified", ShieldCheck]
  ];

  return (
    <div className="pb-8 web-page">
      <div className="px-4 pt-3 pb-4">
        <div className="f-display font-bold" style={{ color: T.paper, fontSize: 19 }}>Landlord Hub</div>
        <div className="f-body mt-1" style={{ color: "rgba(251,248,240,.62)", fontSize: 11.5 }}>Register first, then manage properties, viewings and tenant conversations.</div>
        <button onClick={() => setShowRegistration(true)} className="w-full mt-3 rounded-2xl p-3 text-left" style={{background:T.paper,color:T.ink}}><div className="f-display font-semibold" style={{fontSize:12.5}}>{landlordRegistration ? "Landlord registration" : "Register as a landlord"}</div><div className="f-body mt-0.5" style={{fontSize:10,color:T.ink60}}>{landlordRegistration ? `Status: ${landlordRegistration.verificationStatus || "pending"}` : "Complete identity and authority checks before publishing a listing."}</div></button>
      </div>

      <div className="web-surface" style={{ background: T.paper, borderRadius: 18, minHeight: 600 }}>
        <div className="web-stats-grid grid grid-cols-4 gap-2 px-4 pt-5">
          {stats.map(([n, label, Icon]) => (
            <div key={label} className="rounded-2xl p-2.5 text-center" style={{ background: T.paperDim }}>
              <Icon size={15} className="mx-auto mb-1" style={{ color: T.jacaranda }}/>
              <div className="f-display font-bold" style={{ color: T.ink, fontSize: 15 }}>{n}</div>
              <div className="f-body" style={{ color: T.ink60, fontSize: 9.5 }}>{label}</div>
            </div>
          ))}
        </div>

        <div className="px-4 pt-5">
          <button disabled={!landlordRegistration} onClick={() => setShowForm(true)} className="w-full rounded-2xl p-3.5 flex items-center justify-between" style={{ background: landlordRegistration ? T.ink : T.ink60, color: T.paper, opacity: landlordRegistration ? 1 : .65 }}>
            <div className="flex items-center gap-3"><span className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: T.brick }}><Plus size={18}/></span><div className="text-left"><div className="f-display font-semibold" style={{ fontSize: 13 }}>Add property</div><div className="f-body opacity-65" style={{ fontSize: 10.5 }}>Publish a rental listing</div></div></div>
            <ChevronRight size={17}/>
          </button>
        </div>

        <div className="px-4 pt-6">
          <div className="f-mono mb-2" style={{ color: T.ink60, fontSize: 10, letterSpacing: ".16em" }}>YOUR LISTINGS</div>
          <div className="space-y-2">
            {myListings.slice(0, 8).map(p => (
              <button key={p.id} onClick={() => onOpenProperty(p)} className="w-full text-left flex items-center gap-3 p-3 rounded-2xl" style={{ background: T.paperDim }}>
                <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0" style={{ background: `linear-gradient(135deg, ${p.grad?.[0] || T.jacaranda}, ${p.grad?.[1] || T.brick})` }}><Home size={19} color={T.paper}/></div>
                <div className="min-w-0 flex-1">
                  <div className="f-body font-semibold truncate" style={{ color: T.ink, fontSize: 12.5 }}>{p.title}</div>
                  <div className="f-body mt-0.5 truncate" style={{ color: T.ink60, fontSize: 10.5 }}>{p.suburb} · ${p.rent}/mo</div>
                </div>
                <span className="f-body px-2 py-1 rounded-full shrink-0" style={{ background: p.verification === "verified" ? "rgba(47,122,85,.12)" : "rgba(184,132,46,.13)", color: p.verification === "verified" ? T.msasa : T.ochre, fontSize: 9.5 }}>
                  {p.verification === "verified" ? "Verified" : "Pending"}
                </span>
              </button>
            ))}
          </div>
        </div>

        <div className="px-4 pt-6">
          <div className="f-mono mb-2" style={{ color: T.ink60, fontSize: 10, letterSpacing: ".16em" }}>VIEWING REQUESTS</div>
          {requested.length === 0 ? (
            <div className="rounded-2xl p-4 flex items-center gap-3" style={{ background: T.paperDim }}>
              <Clock3 size={17} style={{ color: T.ink60 }}/>
              <span className="f-body" style={{ color: T.ink60, fontSize: 11.5 }}>No new viewing requests yet.</span>
            </div>
          ) : requested.slice(0, 4).map(id => {
            const p = properties.find(x => x.id === Number(id));
            return p ? <div key={id} className="rounded-2xl p-3 mb-2 flex items-center gap-3" style={{ background: T.paperDim }}>
              <Eye size={17} style={{ color: T.jacaranda }}/>
              <div className="flex-1"><div className="f-body font-semibold" style={{ color: T.ink, fontSize: 12 }}>{p.title}</div><div className="f-body" style={{ color: T.ink60, fontSize: 10.5 }}>Tenant requested a viewing</div></div>
              <span className="f-body font-semibold" style={{ color: T.jacarandaDeep, fontSize: 10 }}>Review</span>
            </div> : null;
          })}
        </div>
      </div>

      {showForm && landlordRegistration && <ListingForm onClose={() => setShowForm(false)} onCreate={(listing) => { onCreateListing(listing); setShowForm(false); }}/>}
      {showRegistration && <LandlordRegistration profile={profile} onClose={() => setShowRegistration(false)} onSubmit={async data => { await onRegisterLandlord(data); setShowRegistration(false); }} />}
    </div>
  );
}
