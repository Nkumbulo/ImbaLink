import { useEffect, useState } from "react";
import { Bookmark, Heart } from "lucide-react";
import { T } from "../styles/tokens";
import GridTile from "../components/property/GridTile";
export default function CollectionsPage({ properties, saved, liked, openProperty, initialView }){
  const [view,setView]=useState(initialView==="liked"?"liked":"saved");
  useEffect(()=>{ if(initialView) setView(initialView==="liked"?"liked":"saved"); },[initialView]);
  const list=properties.filter(p=>(view==="saved"?saved:liked).has(String(p.id)));
  return (<div className="pb-4"><div className="px-4 pt-3"><div className="f-display font-bold" style={{color:T.paper,fontSize:19}}>Collections</div></div><div style={{background:T.paper,borderTopLeftRadius:18,borderTopRightRadius:18,marginTop:10}}><div className="flex gap-4 px-4 pt-3" style={{borderBottom:`1px solid ${T.line}`}}>{[["saved","Saved",Bookmark],["liked","Liked",Heart]].map(([id,label,Icon])=>(<button key={id} onClick={()=>setView(id)} className="f-body font-medium pb-2.5 flex items-center gap-1.5" style={{color:view===id?T.ink:T.ink60,borderBottom:view===id?`2px solid ${T.brick}`:"2px solid transparent",fontSize:12.5}}><Icon size={13}/> {label}</button>))}</div>{list.length===0?(<div className="fade text-center py-16 f-body" style={{color:T.ink60,fontSize:13}}>{view==="saved"?"Tap the bookmark on a listing to save it here.":"Double-tap a photo or the heart to like it."}</div>):(<div className="grid grid-cols-3 mt-3" style={{gap:2}}>{list.map(p=><GridTile key={p.id} p={p} onOpen={openProperty}/>)}</div>)}</div></div>);
}
