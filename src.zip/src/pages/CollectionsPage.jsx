import { useEffect, useState } from "react";
import { Bookmark, Heart } from "lucide-react";
import { T } from "../styles/tokens";
import GridTile from "../components/property/GridTile";

function useMediaQuery(query) {
  const [matches, setMatches] = useState(
    () => typeof window !== "undefined" && window.matchMedia(query).matches
  );

  useEffect(() => {
    const media = window.matchMedia(query);
    const update = () => setMatches(media.matches);
    update();
    media.addEventListener?.("change", update);
    return () => media.removeEventListener?.("change", update);
  }, [query]);

  return matches;
}

const TABS = [
  ["saved", "Saved", Bookmark],
  ["liked", "Liked", Heart],
];

export default function CollectionsPage({ properties, saved, liked, openProperty, initialView }) {
  const isTabletOrDesktop = useMediaQuery("(min-width: 768px)");
  const [view, setView] = useState(initialView === "liked" ? "liked" : "saved");

  useEffect(() => {
    if (initialView) setView(initialView === "liked" ? "liked" : "saved");
  }, [initialView]);

  const list = properties.filter((p) => (view === "saved" ? saved : liked).has(String(p.id)));

  return (
    <div className="pb-4 web-page collections-page">
      <div className="px-4 pt-3">
        <div
          className="f-display font-bold"
          style={{
            color: isTabletOrDesktop ? T.ink : T.paper,
            fontSize: isTabletOrDesktop ? 24 : 19,
          }}
        >
          Collections
        </div>
      </div>

      <div
        className="web-surface"
        style={{
          background: T.paper,
          borderTopLeftRadius: 18,
          borderTopRightRadius: 18,
          marginTop: 10,
        }}
      >
        <div className="flex gap-4 px-4 pt-3" style={{ borderBottom: `1px solid ${T.line}` }}>
          {TABS.map(([id, label, Icon]) => (
            <button
              key={id}
              onClick={() => setView(id)}
              className="f-body font-medium pb-2.5 flex items-center gap-1.5"
              style={{
                color: view === id ? T.ink : T.ink60,
                borderBottom: view === id ? `2px solid ${T.brick}` : "2px solid transparent",
                fontSize: 12.5,
              }}
            >
              <Icon size={13} /> {label}
            </button>
          ))}
        </div>

        {list.length === 0 ? (
          <div className="fade text-center py-16 f-body" style={{ color: T.ink60, fontSize: 13 }}>
            {view === "saved"
              ? "Tap the bookmark on a listing to save it here."
              : "Double-tap a photo or the heart to like it."}
          </div>
        ) : (
          <div
            className="grid collections-grid"
            style={{ gridTemplateColumns: "repeat(3, 1fr)", gap: 2, marginTop: 12 }}
          >
            {list.map((p) => (
              <GridTile key={p.id} p={p} onOpen={openProperty} compactDesktop={isTabletOrDesktop} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
