import { useState, useEffect, useMemo, useRef, useCallback } from "react";
import { T } from "../styles/tokens";
import Avatar from "../components/common/Avatar";
import { useConversations, useConversationMessages } from "../hooks/useMessaging";
import {
  ArrowLeft,
  Send,
  Wrench,
  Search,
  CheckCheck,
  MessageCircle,
  Loader2,
} from "lucide-react";

const READ_COUNTS_STORAGE_KEY = "imbalink_message_read_counts";

function useMediaQuery(query) {
  const [matches, setMatches] = useState(
    () => typeof window !== "undefined" && window.matchMedia(query).matches
  );

  useEffect(() => {
    const media = window.matchMedia(query);
    const update = () => setMatches(media.matches);
    update();
    media.addEventListener?.("change", update);
    return () => media.removeEventListener?.("change", update);
  }, [query]);

  return matches;
}

// This page talks only to the useMessaging hooks (which talk only to
// messagingService, which talks only to whatever provider is active — see
// src/services/messaging/). It never imports a provider directly and never
// contains provider-specific code, so swapping the mock provider for a
// real backend later means changing one line in messagingService.js, not
// this component.
export default function MessagesPage({
  properties = [],
  contractors = [],
  currentUserId,
  contractorId,
  contractorName,
  templateMessage,
  propertyId,
  clearMessagesState,
  readCounts = {},
  setReadCounts,
}) {
  const [currentThreadId, setCurrentThreadId] = useState(null);
  const [currentThreadName, setCurrentThreadName] = useState("");
  const [currentThreadType, setCurrentThreadType] = useState(null);
  const [inputValue, setInputValue] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [inboxFilter, setInboxFilter] = useState("all");
  const [isInputFocused, setIsInputFocused] = useState(false);
  const [keyboardInset, setKeyboardInset] = useState(0);

  const messagesEndRef = useRef(null);
  const hasRestoredReadState = useRef(false);
  const isDesktop = useMediaQuery("(min-width: 768px)");

  /*
   * ------------------------------------------------------------
   * Thread helpers
   * ------------------------------------------------------------
   */

  const getThreadKey = useCallback(() => {
    if (
      currentThreadId === null ||
      currentThreadId === undefined ||
      currentThreadId === ""
    ) {
      return null;
    }

    return currentThreadType === "contractor"
      ? `contractor_${currentThreadId}`
      : String(currentThreadId);
  }, [currentThreadId, currentThreadType]);

  const currentThreadKey = getThreadKey();

  /*
   * ------------------------------------------------------------
   * Messaging data layer (see src/hooks/useMessaging.js)
   * ------------------------------------------------------------
   */

  const {
    conversations,
    loading: conversationsLoading,
    error: conversationsError,
    connectionState,
    refresh: refreshConversations,
  } = useConversations(currentUserId);

  const {
    messages: rawMessages,
    loading: messagesLoading,
    error: messagesError,
    sendMessage: sendThreadMessage,
    retryMessage,
  } = useConversationMessages(currentThreadKey, currentUserId);

  // Adapt canonical messages into the exact {id, from, text, ts} shape the
  // render below already uses, plus `status` for the sending/failed states.
  const currentMessages = useMemo(
    () =>
      rawMessages.map((m) => ({
        id: m.id,
        from: m.senderId === currentUserId ? "me" : "them",
        text: m.text,
        ts: m.createdAt,
        status: m.status,
      })),
    [rawMessages, currentUserId]
  );

  // Per-thread count of messages from the other participant, resolved by
  // the provider — used together with readCounts (below) to compute what's
  // actually unread, exactly like the previous threads-based calculation.
  const otherCountByThread = useMemo(() => {
    const map = {};
    conversations.forEach((c) => {
      map[c.id] = c.unreadCount || 0;
    });
    return map;
  }, [conversations]);

  /*
   * ------------------------------------------------------------
   * Restore persisted read state
   * ------------------------------------------------------------
   */

  useEffect(() => {
    if (
      hasRestoredReadState.current ||
      typeof window === "undefined" ||
      typeof setReadCounts !== "function"
    ) {
      return;
    }

    hasRestoredReadState.current = true;

    try {
      const saved = localStorage.getItem(
        READ_COUNTS_STORAGE_KEY
      );

      if (!saved) return;

      const parsed = JSON.parse(saved);

      if (
        !parsed ||
        typeof parsed !== "object" ||
        Array.isArray(parsed)
      ) {
        return;
      }

      setReadCounts((prev) => ({
        ...parsed,
        ...prev,
      }));
    } catch (error) {
      console.warn(
        "Unable to restore message read state:",
        error
      );
    }
  }, [setReadCounts]);

  /*
   * ------------------------------------------------------------
   * Unread counts
   * ------------------------------------------------------------
   */

  const getUnreadCount = useCallback(
    (threadKey) => {
      if (!threadKey) return 0;

      const totalOther = Number(otherCountByThread[threadKey] || 0);
      const read = Number(readCounts[threadKey] || 0);

      return Math.max(0, totalOther - read);
    },
    [otherCountByThread, readCounts]
  );

  /*
   * ------------------------------------------------------------
   * Persist read state
   * ------------------------------------------------------------
   */

  const persistReadCounts = useCallback((counts) => {
    if (typeof window === "undefined") return;

    try {
      localStorage.setItem(
        READ_COUNTS_STORAGE_KEY,
        JSON.stringify(counts)
      );
    } catch (error) {
      console.warn(
        "Unable to save message read state:",
        error
      );
    }
  }, []);

  /*
   * ------------------------------------------------------------
   * Mark one conversation as read
   * ------------------------------------------------------------
   */

  const markThreadAsRead = useCallback(
    (threadKey) => {
      if (
        !threadKey ||
        typeof setReadCounts !== "function"
      ) {
        return;
      }

      const totalOther = Number(otherCountByThread[threadKey] || 0);
      const currentRead = Number(
        readCounts[threadKey] || 0
      );

      if (currentRead >= totalOther) {
        return;
      }

      setReadCounts((prev) => {
        const updated = {
          ...prev,
          [threadKey]: totalOther,
        };

        persistReadCounts(updated);

        return updated;
      });
    },
    [
      otherCountByThread,
      readCounts,
      setReadCounts,
      persistReadCounts,
    ]
  );

  /*
   * ------------------------------------------------------------
   * Mark all as read
   * ------------------------------------------------------------
   */

  const markAllAsRead = useCallback(() => {
    if (
      typeof setReadCounts !== "function" ||
      conversations.length === 0
    ) {
      return;
    }

    const newReadCounts = {};

    conversations.forEach((conversation) => {
      newReadCounts[conversation.id] = Number(conversation.unreadCount || 0);
    });

    setReadCounts((prev) => {
      const updated = {
        ...prev,
        ...newReadCounts,
      };

      persistReadCounts(updated);

      return updated;
    });
  }, [
    conversations,
    setReadCounts,
    persistReadCounts,
  ]);

  /*
   * ------------------------------------------------------------
   * Keyboard / mobile viewport
   * ------------------------------------------------------------
   */

  useEffect(() => {
    if (
      typeof window === "undefined" ||
      !window.visualViewport ||
      !isInputFocused
    ) {
      setKeyboardInset(0);
      return;
    }

    const viewport = window.visualViewport;

    const handleResize = () => {
      const inset = Math.max(
        0,
        window.innerHeight - viewport.height
      );

      setKeyboardInset(inset);
    };

    viewport.addEventListener(
      "resize",
      handleResize
    );

    handleResize();

    return () => {
      viewport.removeEventListener(
        "resize",
        handleResize
      );
    };
  }, [isInputFocused]);

  /*
   * ------------------------------------------------------------
   * Mark opened conversation as read
   * ------------------------------------------------------------
   */

  useEffect(() => {
    if (
      currentThreadId === null ||
      currentThreadId === undefined
    ) {
      return;
    }

    const key = getThreadKey();

    if (key) {
      markThreadAsRead(key);
    }
  }, [
    currentThreadId,
    currentThreadType,
    getThreadKey,
    markThreadAsRead,
  ]);

  /*
   * ------------------------------------------------------------
   * Scroll to latest message
   * ------------------------------------------------------------
   */

  useEffect(() => {
    if (!messagesEndRef.current) return;

    messagesEndRef.current.scrollIntoView({
      behavior: "smooth",
      block: "end",
    });
  }, [currentMessages.length]);

  /*
   * ------------------------------------------------------------
   * Open contractor conversation
   * ------------------------------------------------------------
   */

  useEffect(() => {
    if (
      contractorId === null ||
      contractorId === undefined ||
      contractorId === ""
    ) {
      return;
    }

    setCurrentThreadId(contractorId);
    setCurrentThreadName(
      contractorName || "Contractor"
    );
    setCurrentThreadType("contractor");

    if (templateMessage) {
      setInputValue(templateMessage);
    }
  }, [
    contractorId,
    contractorName,
    templateMessage,
  ]);

  /*
   * ------------------------------------------------------------
   * Open property conversation
   * ------------------------------------------------------------
   */

  useEffect(() => {
    if (
      propertyId === null ||
      propertyId === undefined ||
      propertyId === ""
    ) {
      return;
    }

    const targetProperty = properties.find(
      (property) =>
        String(property?.id) ===
        String(propertyId)
    );

    if (targetProperty) {
      setCurrentThreadId(targetProperty.id);
      setCurrentThreadName(
        targetProperty.landlord || "Landlord"
      );
      setCurrentThreadType("property");
      setInputValue("");
    }

    if (
      typeof clearMessagesState === "function"
    ) {
      clearMessagesState();
    }
  }, [
    propertyId,
    properties,
    clearMessagesState,
  ]);

  /*
   * ------------------------------------------------------------
   * Time formatting
   * ------------------------------------------------------------
   */

  const formatConversationTime = useCallback(
    (ts) => {
      const timestamp = Number(ts);

      if (!Number.isFinite(timestamp)) {
        return "";
      }

      const diff = Math.max(
        0,
        Date.now() - timestamp
      );

      const seconds = Math.floor(
        diff / 1000
      );

      if (seconds < 60) return "now";

      const minutes = Math.floor(
        seconds / 60
      );

      if (minutes < 60) {
        return `${minutes}m`;
      }

      const hours = Math.floor(
        minutes / 60
      );

      if (hours < 24) {
        return `${hours}h`;
      }

      const days = Math.floor(
        hours / 24
      );

      if (days < 7) {
        return `${days}d`;
      }

      return new Date(
        timestamp
      ).toLocaleDateString();
    },
    []
  );

  const formatMessageTime = useCallback(
    (ts) => {
      const timestamp = Number(ts);

      if (!Number.isFinite(timestamp)) {
        return "";
      }

      const diff = Math.max(
        0,
        Date.now() - timestamp
      );

      const seconds = Math.floor(
        diff / 1000
      );

      const minutes = Math.floor(
        seconds / 60
      );

      const hours = Math.floor(
        minutes / 60
      );

      const days = Math.floor(
        hours / 24
      );

      if (days === 0) {
        if (hours === 0) {
          if (minutes === 0) {
            return "just now";
          }

          return `${minutes}m ago`;
        }

        return `${hours}h ago`;
      }

      if (days === 1) {
        return `yesterday at ${new Date(
          timestamp
        ).toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        })}`;
      }

      if (days < 7) {
        return `${days}d ago`;
      }

      return new Date(
        timestamp
      ).toLocaleDateString();
    },
    []
  );

  /*
   * ------------------------------------------------------------
   * Conversations (adapted from the messaging service into the
   * {type, p, last, id, threadKey, contractorId} shape the inbox
   * list below renders)
   * ------------------------------------------------------------
   */

  const convos = useMemo(() => {
    const raw = conversations
      .map((conversation) => {
        if (!conversation?.lastMessage) return null;

        const isContractor = conversation.type === "contractor";
        const last = {
          ts: conversation.lastMessage.createdAt,
          text: conversation.lastMessage.text,
          from: conversation.lastMessage.senderId === currentUserId ? "me" : "them",
        };

        const p = isContractor
          ? {
              id: conversation.contractorId,
              landlord: conversation.displayName,
              grad: ["#6E63B8", "#3E3670"], // unused (contractor rows render a Wrench icon instead of <Avatar>), kept for safety
            }
          : {
              id: conversation.propertyId,
              landlord: conversation.displayName,
              grad: conversation.displayAvatar?.grad || ["#6E63B8", "#3E3670"],
            };

        return {
          type: isContractor ? "contractor" : "property",
          p,
          last,
          id: conversation.id,
          threadKey: conversation.id,
          contractorId: isContractor ? conversation.contractorId : undefined,
        };
      })
      .filter(Boolean);

    let filtered = raw;

    const query = searchQuery.trim().toLowerCase();

    if (query) {
      filtered = filtered.filter(
        (conversation) =>
          String(
            conversation.p?.landlord ||
              ""
          )
            .toLowerCase()
            .includes(query)
      );
    }

    if (inboxFilter === "unread") {
      filtered = filtered.filter(
        (conversation) =>
          getUnreadCount(
            conversation.threadKey
          ) > 0
      );
    }

    return filtered;
  }, [
    conversations,
    currentUserId,
    searchQuery,
    inboxFilter,
    getUnreadCount,
  ]);

  /*
   * ------------------------------------------------------------
   * Send message
   * ------------------------------------------------------------
   */

  const handleSendMessage = () => {
    const text = inputValue.trim();

    if (!text) return;

    if (
      currentThreadId === null ||
      currentThreadId === undefined ||
      currentThreadId === ""
    ) {
      return;
    }

    // Optimistic update + retry-on-failure both happen inside the hook —
    // the input clears immediately, exactly like the previous behaviour.
    sendThreadMessage(text);
    setInputValue("");

    if (
      typeof clearMessagesState ===
      "function"
    ) {
      clearMessagesState();
    }
  };

  /*
   * ------------------------------------------------------------
   * Navigation
   * ------------------------------------------------------------
   */

  const handleBack = () => {
    setCurrentThreadId(null);
    setCurrentThreadName("");
    setCurrentThreadType(null);
    setInputValue("");
    setIsInputFocused(false);
  };

  const openThread = (conversation) => {
    if (!conversation) return;

    if (
      conversation.type ===
      "contractor"
    ) {
      setCurrentThreadId(
        conversation.contractorId
      );

      setCurrentThreadName(
        conversation.p.landlord ||
          "Contractor"
      );

      setCurrentThreadType(
        "contractor"
      );
    } else {
      setCurrentThreadId(
        conversation.p.id
      );

      setCurrentThreadName(
        conversation.p.landlord ||
          "Landlord"
      );

      setCurrentThreadType(
        "property"
      );
    }

    setInputValue("");
    setIsInputFocused(false);
  };

  /*
   * ------------------------------------------------------------
   * Render
   * ------------------------------------------------------------
   */

  return (
    <div
      className={isDesktop ? "messages-desktop-shell" : undefined}
      style={
        isDesktop
          ? {
              position: "relative",
              width: "100%",
              background: T.ink,
              display: "flex",
              flexDirection: "column",
              overflow: "hidden",
            }
          : {
              position: "fixed",
              top: 0,
              left: 0,
              right: 0,
              bottom: `calc(56px + env(safe-area-inset-bottom, 0px) + ${keyboardInset}px)`,
              background: T.ink,
              display: "flex",
              flexDirection: "column",
              zIndex: 1,
              overflow: "hidden",
            }
      }
    >
      {/* Header */}
      <div
        className="messages-header"
        style={{
          height:
            "calc(64px + env(safe-area-inset-top, 0px))",
          paddingTop:
            "env(safe-area-inset-top, 0px)",
          background:
            T.ink + "F2",
          backdropFilter:
            "blur(20px)",
          WebkitBackdropFilter:
            "blur(20px)",
          borderBottom:
            `1px solid ${T.line}`,
          display: "flex",
          alignItems: "center",
          paddingLeft: 16,
          paddingRight: 16,
          gap: 12,
          boxShadow:
            "0 2px 12px rgba(0,0,0,0.25)",
          flexShrink: 0,
        }}
      >
        {currentThreadId !== null &&
        currentThreadId !== undefined ? (
          <>
            <button
              onClick={handleBack}
              className="p-1.5 rounded-full hover:bg-white/10 transition-all active:scale-90"
              style={{
                border: "none",
                background:
                  "transparent",
                cursor: "pointer",
              }}
              aria-label="Back to messages"
            >
              <ArrowLeft
                size={22}
                color={T.paper}
              />
            </button>

            <div
              className="flex-1 font-semibold"
              style={{
                color: T.paper,
                fontSize: 18,
                letterSpacing:
                  "-0.3px",
                minWidth: 0,
                whiteSpace:
                  "nowrap",
                overflow: "hidden",
                textOverflow:
                  "ellipsis",
              }}
            >
              {currentThreadName}
            </div>
          </>
        ) : (
          <>
            <div
              className="font-bold"
              style={{
                color: T.paper,
                fontSize: 20,
                letterSpacing:
                  "-0.5px",
              }}
            >
              Messages
            </div>

            <div className="flex-1" />

            <button
              onClick={
                markAllAsRead
              }
              className="p-1.5 rounded-full hover:bg-white/10 transition-all active:scale-90"
              title="Mark all as read"
              aria-label="Mark all as read"
              style={{
                border: "none",
                background:
                  "transparent",
                cursor: "pointer",
              }}
            >
              <CheckCheck
                size={20}
                color={T.ink60}
              />
            </button>

            <div
              className="relative flex items-center"
              style={{
                width: 140,
              }}
            >
              <Search
                size={16}
                color={T.ink60}
                style={{
                  position:
                    "absolute",
                  left: 10,
                  pointerEvents:
                    "none",
                }}
              />

              <input
                type="text"
                placeholder="Search"
                value={
                  searchQuery
                }
                onChange={(event) =>
                  setSearchQuery(
                    event.target
                      .value
                  )
                }
                aria-label="Search conversations"
                style={{
                  width: "100%",
                  background:
                    "rgba(255,255,255,0.08)",
                  border:
                    `1px solid ${T.line}`,
                  borderRadius: 20,
                  padding:
                    "6px 12px 6px 34px",
                  color: T.paper,
                  fontSize: 16,
                  outline: "none",
                  transition:
                    "border-color 0.2s",
                }}
                onFocus={(event) => {
                  event.target.style.borderColor =
                    T.jacaranda;
                }}
                onBlur={(event) => {
                  event.target.style.borderColor =
                    T.line;
                }}
              />
            </div>
          </>
        )}
      </div>

      {/* Connection banner — hidden entirely while online, so there is no
          visual change from before in the normal case. */}
      {connectionState !== "online" && (
        <div
          style={{
            flexShrink: 0,
            padding: "6px 16px",
            textAlign: "center",
            fontSize: 11,
            fontWeight: 600,
            color: T.paper,
            background: connectionState === "offline" ? T.brick : T.jacaranda,
          }}
        >
          {connectionState === "offline"
            ? "You're offline — messages will send once you're back online."
            : "Reconnecting…"}
        </div>
      )}

      {/* Main content */}
      <div
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          minHeight: 0,
          background:
            T.paperDim,
          boxShadow:
            "0 -8px 30px rgba(0,0,0,0.4)",
          overflow: "hidden",
        }}
      >
        {currentThreadId !== null &&
        currentThreadId !== undefined ? (
          <div
            className="flex-1 flex flex-col"
            style={{
              minHeight: 0,
            }}
          >
            {/* Messages */}
            <div
              className="flex-1 px-4 py-4 overflow-y-auto"
              style={{
                flex: 1,
                overflowY: "auto",
                background:
                  T.paperDim,
                WebkitOverflowScrolling:
                  "touch",
              }}
            >
              {messagesLoading && currentMessages.length === 0 ? (
                <MessageAreaStatus
                  icon={Loader2}
                  spin
                  label="Loading messages…"
                />
              ) : messagesError && currentMessages.length === 0 ? (
                <MessageAreaStatus
                  icon={MessageCircle}
                  label="Couldn't load messages."
                  sublabel={messagesError}
                />
              ) : currentMessages.length ===
              0 ? (
                <MessageAreaStatus
                  icon={MessageCircle}
                  label="No messages yet"
                  sublabel="Send a message to start the conversation."
                />
              ) : (
                <div className="space-y-2">
                  {currentMessages.map(
                    (msg, idx) => {
                      if (!msg) {
                        return null;
                      }

                      const isMe =
                        msg.from ===
                        "me";

                      const messageKey =
                        msg.id ??
                        `${msg.ts ?? "message"}-${idx}`;

                      return (
                        <div
                          key={
                            messageKey
                          }
                          className={`flex ${
                            isMe
                              ? "justify-end"
                              : "justify-start"
                          } animate-fadeIn`}
                          style={{
                            animationDuration:
                              "0.2s",
                            animationFillMode:
                              "both",
                          }}
                        >
                          <div
                            style={{
                              display:
                                "flex",
                              alignItems:
                                "flex-end",
                              gap: 10,
                              maxWidth:
                                "85%",
                            }}
                          >
                            {!isMe && (
                              <div
                                style={{
                                  width: 36,
                                  height: 36,
                                  borderRadius:
                                    "50%",
                                  background:
                                    T.jacaranda +
                                    "20",
                                  border:
                                    `2px solid ${T.jacaranda}60`,
                                  display:
                                    "flex",
                                  alignItems:
                                    "center",
                                  justifyContent:
                                    "center",
                                  flexShrink: 0,
                                  fontWeight: 700,
                                  fontSize: 16,
                                  color:
                                    T.jacaranda,
                                }}
                              >
                                {currentThreadName?.[0] ||
                                  "?"}
                              </div>
                            )}

                            <div
                              style={{
                                background:
                                  isMe
                                    ? T.jacaranda
                                    : T.paper,
                                color:
                                  isMe
                                    ? T.paper
                                    : T.ink,
                                padding:
                                  "12px 16px",
                                borderRadius:
                                  isMe
                                    ? "20px 20px 4px 20px"
                                    : "20px 20px 20px 4px",
                                boxShadow:
                                  isMe
                                    ? "0 4px 14px rgba(108,56,255,0.35)"
                                    : "0 2px 10px rgba(0,0,0,0.08)",
                                fontSize: 16,
                                lineHeight:
                                  1.55,
                                wordBreak:
                                  "break-word",
                                maxWidth:
                                  "100%",
                              }}
                            >
                              {msg.text}

                              {msg.status === "failed" ? (
                                <button
                                  type="button"
                                  onClick={() => retryMessage(msg.id)}
                                  style={{
                                    display: "block",
                                    width: "100%",
                                    fontSize: 10.5,
                                    marginTop: 5,
                                    textAlign: isMe ? "right" : "left",
                                    background: "transparent",
                                    border: "none",
                                    padding: 0,
                                    color: isMe ? "#FFD9CC" : T.brick,
                                    cursor: "pointer",
                                    fontWeight: 700,
                                  }}
                                >
                                  Failed to send · Tap to retry
                                </button>
                              ) : (
                                <div
                                  style={{
                                    fontSize: 10.5,
                                    opacity:
                                      isMe
                                        ? 0.8
                                        : 0.55,
                                    marginTop: 5,
                                    color:
                                      isMe
                                        ? T.paper
                                        : T.ink60,
                                    textAlign:
                                      isMe
                                        ? "right"
                                        : "left",
                                  }}
                                >
                                  {msg.status === "sending"
                                    ? "Sending…"
                                    : formatMessageTime(
                                        msg.ts
                                      )}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    }
                  )}

                  <div
                    ref={
                      messagesEndRef
                    }
                    style={{
                      height: 1,
                      scrollMarginBottom:
                        16,
                    }}
                  />
                </div>
              )}
            </div>

            {/* Message input */}
            <div
              style={{
                borderTop:
                  `1px solid ${T.line}`,
                background:
                  T.paper,
                padding:
                  "12px 16px",
                paddingBottom:
                  "max(12px, env(safe-area-inset-bottom, 0px))",
                flexShrink: 0,
              }}
            >
              <form
                onSubmit={(event) => {
                  event.preventDefault();
                  handleSendMessage();
                }}
                style={{
                  display:
                    "flex",
                  gap: 10,
                  alignItems:
                    "center",
                }}
              >
                <input
                  value={
                    inputValue
                  }
                  onChange={(event) =>
                    setInputValue(
                      event.target
                        .value
                    )
                  }
                  placeholder="Type a message…"
                  onFocus={() =>
                    setIsInputFocused(
                      true
                    )
                  }
                  onBlur={() =>
                    setIsInputFocused(
                      false
                    )
                  }
                  aria-label="Message"
                  style={{
                    flex: 1,
                    background:
                      T.paperDim,
                    border:
                      `1px solid ${T.line}`,
                    borderRadius:
                      24,
                    padding:
                      "12px 16px",
                    fontSize: 16,
                    color: T.ink,
                    outline: "none",
                    transition:
                      "box-shadow 0.2s, border-color 0.2s",
                    boxShadow:
                      "inset 0 1px 3px rgba(0,0,0,0.04)",
                  }}
                  onFocusCapture={(
                    event
                  ) => {
                    event.target.style.boxShadow =
                      `0 0 0 2px ${T.jacaranda}40`;

                    event.target.style.borderColor =
                      T.jacaranda;
                  }}
                  onBlurCapture={(
                    event
                  ) => {
                    event.target.style.boxShadow =
                      "inset 0 1px 3px rgba(0,0,0,0.04)";

                    event.target.style.borderColor =
                      T.line;
                  }}
                />

                <button
                  type="submit"
                  disabled={
                    !inputValue.trim()
                  }
                  aria-label="Send message"
                  style={{
                    width: 48,
                    height: 48,
                    borderRadius:
                      "50%",
                    background:
                      T.jacaranda,
                    border: "none",
                    display:
                      "flex",
                    alignItems:
                      "center",
                    justifyContent:
                      "center",
                    cursor:
                      inputValue.trim()
                        ? "pointer"
                        : "default",
                    transition:
                      "transform 0.15s, opacity 0.15s",
                    boxShadow:
                      "0 4px 12px rgba(108,56,255,0.35)",
                    flexShrink: 0,
                    opacity:
                      inputValue.trim()
                        ? 1
                        : 0.5,
                  }}
                  className="active:scale-90"
                >
                  <Send
                    size={22}
                    color={T.paper}
                  />
                </button>
              </form>
            </div>
          </div>
        ) : (
          /* Inbox */
          <>
            <div
              style={{
                display:
                  "flex",
                gap: 8,
                padding:
                  "12px 16px",
                borderBottom:
                  `1px solid ${T.line}`,
                flexShrink: 0,
              }}
            >
              {[
                "all",
                "unread",
              ].map(
                (filter) => (
                  <button
                    key={filter}
                    onClick={() =>
                      setInboxFilter(
                        filter
                      )
                    }
                    style={{
                      padding:
                        "6px 16px",
                      borderRadius:
                        20,
                      fontSize: 12,
                      fontWeight: 600,
                      border:
                        `1px solid ${
                          inboxFilter ===
                          filter
                            ? T.jacaranda
                            : T.line
                        }`,
                      background:
                        inboxFilter ===
                        filter
                          ? T.jacaranda
                          : "transparent",
                      color:
                        inboxFilter ===
                        filter
                          ? T.paper
                          : T.ink60,
                      cursor:
                        "pointer",
                      transition:
                        "all 0.15s",
                    }}
                    className="hover:opacity-80 active:scale-95"
                  >
                    {filter ===
                    "all"
                      ? "All"
                      : "Unread"}

                    {filter ===
                      "unread" && (
                      <span
                        style={{
                          marginLeft: 4,
                          fontSize: 10,
                          opacity: 0.8,
                        }}
                      >
                        (
                        {convos.reduce(
                          (
                            sum,
                            conversation
                          ) =>
                            sum +
                            getUnreadCount(
                              conversation.threadKey
                            ),
                          0
                        )}
                        )
                      </span>
                    )}
                  </button>
                )
              )}
            </div>

            {conversationsLoading && conversations.length === 0 ? (
              <InboxStatus
                icon={Loader2}
                spin
                label="Loading conversations…"
              />
            ) : conversationsError && conversations.length === 0 ? (
              <InboxStatus
                icon={MessageCircle}
                label="Couldn't load conversations."
                sublabel={conversationsError}
                actionLabel="Try again"
                onAction={refreshConversations}
              />
            ) : convos.length ===
            0 ? (
              <InboxStatus
                icon={MessageCircle}
                label={
                  searchQuery
                    ? "No conversations match your search."
                    : inboxFilter ===
                      "unread"
                    ? "No unread messages."
                    : "No conversations yet."
                }
                sublabel="Tap the message icon on a listing to start one."
              />
            ) : (
              <div
                style={{
                  flex: 1,
                  overflowY:
                    "auto",
                  padding:
                    "4px 0",
                  WebkitOverflowScrolling:
                    "touch",
                }}
              >
                {convos.map(
                  (
                    conversation
                  ) => {
                    const {
                      p,
                      last,
                      threadKey,
                    } =
                      conversation;

                    const unread =
                      getUnreadCount(
                        threadKey
                      );

                    return (
                      <div
                        key={
                          conversation.id
                        }
                        onClick={() =>
                          openThread(
                            conversation
                          )
                        }
                        style={{
                          display:
                            "flex",
                          alignItems:
                            "center",
                          gap: 14,
                          padding:
                            "12px 16px",
                          cursor:
                            "pointer",
                          transition:
                            "background 0.15s",
                          borderBottom:
                            `1px solid ${T.line}`,
                          position:
                            "relative",
                        }}
                        className="hover:bg-black/5 active:bg-black/10"
                        role="button"
                        tabIndex={0}
                        onKeyDown={(
                          event
                        ) => {
                          if (
                            event.key ===
                              "Enter" ||
                            event.key ===
                              " "
                          ) {
                            event.preventDefault();

                            openThread(
                              conversation
                            );
                          }
                        }}
                      >
                        {conversation.type ===
                        "contractor" ? (
                          <div
                            style={{
                              width: 52,
                              height: 52,
                              borderRadius:
                                "50%",
                              background:
                                T.jacaranda +
                                "20",
                              border:
                                `2px solid ${T.jacaranda}40`,
                              display:
                                "flex",
                              alignItems:
                                "center",
                              justifyContent:
                                "center",
                              flexShrink: 0,
                            }}
                          >
                            <Wrench
                              size={24}
                              color={
                                T.jacaranda
                              }
                            />
                          </div>
                        ) : (
                          <Avatar
                            grad={
                              p.grad
                            }
                            letter={
                              p.landlord?.[0] ||
                              "?"
                            }
                            size={52}
                          />
                        )}

                        <div
                          style={{
                            flex: 1,
                            minWidth: 0,
                          }}
                        >
                          <div
                            style={{
                              display:
                                "flex",
                              alignItems:
                                "center",
                              justifyContent:
                                "space-between",
                              gap: 8,
                            }}
                          >
                            <div
                              style={{
                                fontWeight:
                                  unread >
                                  0
                                    ? 700
                                    : 600,
                                color:
                                  T.ink,
                                fontSize: 15,
                                whiteSpace:
                                  "nowrap",
                                overflow:
                                  "hidden",
                                textOverflow:
                                  "ellipsis",
                                minWidth:
                                  0,
                              }}
                            >
                              {
                                p.landlord
                              }
                            </div>

                            {/* Timestamp */}
                            <div
                              style={{
                                color:
                                  unread >
                                  0
                                    ? T.jacaranda
                                    : T.ink60,
                                fontSize: 11,
                                fontWeight:
                                  unread >
                                  0
                                    ? 700
                                    : 500,
                                flexShrink:
                                  0,
                                whiteSpace:
                                  "nowrap",
                                letterSpacing:
                                  unread >
                                  0
                                    ? "0.1px"
                                    : "0",
                              }}
                            >
                              {formatConversationTime(
                                last?.ts
                              )}
                            </div>
                          </div>

                          <div
                            style={{
                              color:
                                unread >
                                0
                                  ? T.ink
                                  : T.ink60,
                              fontSize: 13,
                              fontWeight:
                                unread >
                                0
                                  ? 500
                                  : 400,
                              whiteSpace:
                                "nowrap",
                              overflow:
                                "hidden",
                              textOverflow:
                                "ellipsis",
                              marginTop: 2,
                            }}
                          >
                            {last?.from ===
                              "me" &&
                              "You: "}

                            {last?.text ||
                              ""}
                          </div>
                        </div>

                        {unread >
                          0 && (
                          <UnreadBadge
                            count={
                              unread
                            }
                          />
                        )}
                      </div>
                    );
                  }
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function UnreadBadge({ count }) {
  if (count <= 0) return null;

  return (
    <div
      aria-label={`${count} unread message${
        count === 1
          ? ""
          : "s"
      }`}
      style={{
        minWidth:
          count > 9 ? 24 : 20,
        height: 20,
        borderRadius: 999,
        background:
          T.jacaranda,
        color: T.paper,
        fontSize: 11,
        fontWeight: 600,
        padding: "0 6px",
        display: "flex",
        alignItems:
          "center",
        justifyContent:
          "center",
        boxShadow:
          "0 2px 8px rgba(108,56,255,0.4)",
        flexShrink: 0,
      }}
    >
      {count > 9
        ? "9+"
        : count}
    </div>
  );
}

// Shared "nothing to show yet" treatment for the inbox panel — used for the
// empty state, the loading state, and the error state so all three look
// like the same design language instead of three different one-offs.
function InboxStatus({ icon: Icon, label, sublabel, spin, actionLabel, onAction }) {
  return (
    <div
      style={{
        flex: 1,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        color: T.ink60,
        fontSize: 14,
        textAlign: "center",
        padding: "0 24px",
      }}
    >
      <Icon
        size={56}
        color={T.ink60}
        className={spin ? "spin" : undefined}
        style={{ opacity: 0.2, marginBottom: 16 }}
      />
      <div style={{ fontWeight: 500 }}>{label}</div>
      {sublabel && (
        <div style={{ fontSize: 12, marginTop: 4, opacity: 0.7 }}>{sublabel}</div>
      )}
      {actionLabel && (
        <button
          type="button"
          onClick={onAction}
          style={{
            marginTop: 14,
            border: `1px solid ${T.jacaranda}`,
            background: "transparent",
            color: T.jacaranda,
            borderRadius: 999,
            padding: "6px 18px",
            fontSize: 12,
            fontWeight: 600,
            cursor: "pointer",
          }}
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}

// Same idea as InboxStatus but sized/positioned for the (already-scrollable)
// message list area instead of the full inbox panel.
function MessageAreaStatus({ icon: Icon, label, sublabel, spin }) {
  return (
    <div
      className="text-center py-16"
      style={{ color: T.ink60, fontSize: 14 }}
    >
      <Icon
        size={40}
        color={T.ink60}
        className={spin ? "spin" : undefined}
        style={{ opacity: 0.3, marginBottom: 12 }}
      />
      <div>{label}</div>
      {sublabel && (
        <div style={{ fontSize: 12, marginTop: 4, opacity: 0.7 }}>{sublabel}</div>
      )}
    </div>
  );
}
