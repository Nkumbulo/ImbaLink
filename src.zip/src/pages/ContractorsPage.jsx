import { useMemo, useState } from "react";
import ContractorRegistration from "../components/contractor/ContractorRegistration";
import {
  Search,
  Star,
  ShieldCheck,
  Phone,
  MapPin,
  Wrench,
  Heart,
  ArrowLeft,
  MessageCircle,
  CheckCircle2,
  Briefcase,
} from "lucide-react";
import { T } from "../styles/tokens";
import { db } from "../services/database";

export default function ContractorsPage({
  contractors = [],
  liked = new Set(),
  setLiked,
  registration,
  onRegister,
  profile,
  setTab,
  setMessagesState,
}) {
  const [showRegistration, setShowRegistration] =
    useState(false);

  const [selectedContractor, setSelectedContractor] =
    useState(null);

  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");

  const categories = useMemo(() => {
    return [
      "All",
      ...Array.from(
        new Set(
          contractors
            .map((contractor) => contractor?.category)
            .filter(Boolean)
        )
      ),
    ];
  }, [contractors]);

  const results = useMemo(() => {
    const normalizedQuery = query
      .trim()
      .toLowerCase();

    return contractors.filter((contractor) => {
      if (!contractor) return false;

      const text = [
        contractor.name,
        contractor.business,
        contractor.category,
        contractor.area,
        contractor.description,
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();

      const matchesSearch =
        !normalizedQuery ||
        text.includes(normalizedQuery);

      const matchesCategory =
        category === "All" ||
        contractor.category === category;

      return (
        matchesSearch &&
        matchesCategory
      );
    });
  }, [
    contractors,
    query,
    category,
  ]);

  const toggleLike = (id) => {
    const key = String(id);

    setLiked?.((current) => {
      const next = new Set(
        current || []
      );

      const willLike =
        !next.has(key);

      if (willLike) {
        next.add(key);
      } else {
        next.delete(key);
      }

      db.setContractorLike(
        key,
        willLike
      ).catch((error) => {
        console.error(
          "Failed to update contractor like:",
          error
        );
      });

      return next;
    });
  };

  const handleRequestQuote = async (
    contractor
  ) => {
    if (!contractor) return;

    const contractorName =
      contractor.business ||
      contractor.name ||
      "Contractor";

    const message = `Quote requested from ImbaLink for ${contractorName}`;

    try {
      await db.createQuoteRequest({
        contractorId: contractor.id,
        contractorName,
        requesterType: "tenant",
        message,
      });

      setMessagesState?.({
        contractorId:
          contractor.id,
        contractorName,
        templateMessage:
          message,
      });

      setTab?.("messages");
    } catch (error) {
      console.error(
        "Failed to request quote:",
        error
      );
    }
  };

  const openContractorProfile = (
    contractor
  ) => {
    if (!contractor) return;

    setSelectedContractor(
      contractor
    );

    window.scrollTo({
      top: 0,
      behavior: "instant",
    });
  };

  const closeContractorProfile = () => {
    setSelectedContractor(null);

    window.scrollTo({
      top: 0,
      behavior: "instant",
    });
  };

  /*
   * ------------------------------------------------------------
   * CONTRACTOR PROFILE VIEW
   * ------------------------------------------------------------
   */

  if (selectedContractor) {
    const contractor =
      selectedContractor;

    const contractorKey =
      String(contractor.id);

    const isLiked =
      liked?.has(contractorKey);

    const displayedRating =
      Math.min(
        5,
        Number(
          contractor.rating || 0
        ) + (isLiked ? 0.1 : 0)
      );

    const businessName =
      contractor.business ||
      contractor.name ||
      "Contractor";

    const contractorName =
      contractor.name ||
      "Contractor";

    return (
      <div
        className="web-page pb-10"
        style={{
          minHeight: "100vh",
          background: T.paperDim,
        }}
      >
        {/* Profile header */}
        <div
          style={{
            background: T.ink,
            color: T.paper,
            paddingTop:
              "env(safe-area-inset-top, 0px)",
            position: "sticky",
            top: 0,
            zIndex: 20,
            boxShadow:
              "0 4px 20px rgba(0,0,0,0.18)",
          }}
        >
          <div
            style={{
              height: 64,
              padding:
                "0 16px",
              display: "flex",
              alignItems:
                "center",
              gap: 12,
            }}
          >
            <button
              onClick={
                closeContractorProfile
              }
              aria-label="Back to contractors"
              className="w-10 h-10 rounded-full flex items-center justify-center active:scale-90"
              style={{
                background:
                  "rgba(255,255,255,0.08)",
                border: "none",
                color: T.paper,
                cursor:
                  "pointer",
              }}
            >
              <ArrowLeft
                size={21}
              />
            </button>

            <div
              className="f-display font-semibold truncate"
              style={{
                fontSize: 17,
                color: T.paper,
                flex: 1,
              }}
            >
              Contractor profile
            </div>

            <button
              onClick={() =>
                toggleLike(
                  contractor.id
                )
              }
              aria-label={
                isLiked
                  ? "Unlike contractor"
                  : "Like contractor"
              }
              className="w-10 h-10 rounded-full flex items-center justify-center active:scale-90"
              style={{
                background:
                  "rgba(255,255,255,0.08)",
                border: "none",
                cursor:
                  "pointer",
              }}
            >
              <Heart
                size={19}
                color={
                  isLiked
                    ? T.brick
                    : T.paper
                }
                fill={
                  isLiked
                    ? T.brick
                    : "none"
                }
              />
            </button>
          </div>
        </div>

        {/* Hero profile section */}
        <div
          style={{
            background: T.ink,
            padding:
              "8px 20px 30px",
            color: T.paper,
          }}
        >
          <div
            style={{
              maxWidth: 1000,
              margin:
                "0 auto",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems:
                  "center",
                gap: 18,
              }}
            >
              <div
                style={{
                  width: 82,
                  height: 82,
                  borderRadius: 24,
                  background:
                    T.jacaranda,
                  display: "flex",
                  alignItems:
                    "center",
                  justifyContent:
                    "center",
                  flexShrink: 0,
                  boxShadow:
                    "0 10px 30px rgba(108,56,255,0.25)",
                }}
              >
                <Wrench
                  size={34}
                  color={T.paper}
                />
              </div>

              <div
                style={{
                  minWidth: 0,
                  flex: 1,
                }}
              >
                <div
                  style={{
                    display:
                      "flex",
                    alignItems:
                      "center",
                    gap: 7,
                    flexWrap:
                      "wrap",
                  }}
                >
                  <h1
                    className="f-display"
                    style={{
                      margin: 0,
                      fontSize: 24,
                      fontWeight: 700,
                      color:
                        T.paper,
                      lineHeight: 1.1,
                    }}
                  >
                    {businessName}
                  </h1>

                  {contractor.verified && (
                    <ShieldCheck
                      size={19}
                      color={
                        T.msasa
                      }
                    />
                  )}
                </div>

                <div
                  className="f-body"
                  style={{
                    marginTop: 6,
                    color:
                      "rgba(251,248,240,.65)",
                    fontSize: 12,
                  }}
                >
                  {contractorName}
                </div>

                <div
                  style={{
                    display:
                      "flex",
                    alignItems:
                      "center",
                    gap: 10,
                    marginTop: 10,
                    flexWrap:
                      "wrap",
                  }}
                >
                  <span
                    style={{
                      display:
                        "flex",
                      alignItems:
                        "center",
                      gap: 4,
                      fontSize: 11,
                      color:
                        T.paper,
                    }}
                  >
                    <Star
                      size={13}
                      fill={
                        T.ochre
                      }
                      color={
                        T.ochre
                      }
                    />
                    {displayedRating.toFixed(
                      1
                    )}
                  </span>

                  {contractor.category && (
                    <span
                      style={{
                        padding:
                          "4px 9px",
                        borderRadius:
                          999,
                        background:
                          "rgba(255,255,255,0.09)",
                        color:
                          "rgba(251,248,240,.8)",
                        fontSize: 10,
                      }}
                    >
                      {
                        contractor.category
                      }
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main profile content */}
        <div
          style={{
            maxWidth: 1000,
            margin:
              "0 auto",
            padding:
              "16px",
          }}
        >
          {/* Verification banner */}
          {contractor.verified && (
            <div
              style={{
                display:
                  "flex",
                alignItems:
                  "center",
                gap: 10,
                padding:
                  "12px 14px",
                borderRadius: 16,
                background:
                  T.msasa + "15",
                border:
                  `1px solid ${T.msasa}35`,
                marginBottom:
                  14,
              }}
            >
              <div
                style={{
                  width: 34,
                  height: 34,
                  borderRadius:
                    "50%",
                  background:
                    T.msasa + "20",
                  display:
                    "flex",
                  alignItems:
                    "center",
                  justifyContent:
                    "center",
                  flexShrink: 0,
                }}
              >
                <ShieldCheck
                  size={18}
                  color={
                    T.msasa
                  }
                />
              </div>

              <div>
                <div
                  className="f-body font-semibold"
                  style={{
                    color:
                      T.ink,
                    fontSize: 12,
                  }}
                >
                  Verified contractor
                </div>

                <div
                  className="f-body"
                  style={{
                    color:
                      T.ink60,
                    fontSize: 10.5,
                    marginTop: 2,
                  }}
                >
                  This contractor
                  has completed
                  ImbaLink's
                  verification
                  process.
                </div>
              </div>
            </div>
          )}

          {/* Quick information */}
          <div
            className="grid grid-cols-2 gap-3"
            style={{
              marginBottom:
                14,
            }}
          >
            <div
              style={{
                background:
                  T.paper,
                border:
                  `1px solid ${T.line}`,
                borderRadius: 18,
                padding:
                  "14px",
              }}
            >
              <div
                style={{
                  width: 32,
                  height: 32,
                  borderRadius:
                    10,
                  background:
                    T.paperDim,
                  display:
                    "flex",
                  alignItems:
                    "center",
                  justifyContent:
                    "center",
                  marginBottom:
                    8,
                }}
              >
                <MapPin
                  size={16}
                  color={
                    T.jacaranda
                  }
                />
              </div>

              <div
                className="f-body"
                style={{
                  fontSize: 10,
                  color:
                    T.ink60,
                }}
              >
                Service area
              </div>

              <div
                className="f-body font-semibold"
                style={{
                  fontSize: 12,
                  color:
                    T.ink,
                  marginTop: 3,
                }}
              >
                {contractor.area ||
                  "Zimbabwe"}
              </div>
            </div>

            <div
              style={{
                background:
                  T.paper,
                border:
                  `1px solid ${T.line}`,
                borderRadius: 18,
                padding:
                  "14px",
              }}
            >
              <div
                style={{
                  width: 32,
                  height: 32,
                  borderRadius:
                    10,
                  background:
                    T.paperDim,
                  display:
                    "flex",
                  alignItems:
                    "center",
                  justifyContent:
                    "center",
                  marginBottom:
                    8,
                }}
              >
                <Briefcase
                  size={16}
                  color={
                    T.jacaranda
                  }
                />
              </div>

              <div
                className="f-body"
                style={{
                  fontSize: 10,
                  color:
                    T.ink60,
                }}
              >
                Service
              </div>

              <div
                className="f-body font-semibold"
                style={{
                  fontSize: 12,
                  color:
                    T.ink,
                  marginTop: 3,
                  whiteSpace:
                    "nowrap",
                  overflow:
                    "hidden",
                  textOverflow:
                    "ellipsis",
                }}
              >
                {contractor.category ||
                  "Property services"}
              </div>
            </div>
          </div>

          {/* About */}
          <section
            style={{
              background:
                T.paper,
              border:
                `1px solid ${T.line}`,
              borderRadius: 20,
              padding:
                "18px",
              marginBottom:
                14,
            }}
          >
            <h2
              className="f-display"
              style={{
                margin: 0,
                fontSize: 15,
                color:
                  T.ink,
              }}
            >
              About this contractor
            </h2>

            <p
              className="f-body"
              style={{
                margin:
                  "8px 0 0",
                color:
                  T.ink60,
                fontSize: 12,
                lineHeight:
                  1.7,
              }}
            >
              {contractor.description ||
                `${businessName} provides professional ${contractor.category || "property"} services through ImbaLink.`}
            </p>
          </section>

          {/* Rating card */}
          <section
            style={{
              background:
                T.paper,
              border:
                `1px solid ${T.line}`,
              borderRadius: 20,
              padding:
                "18px",
              marginBottom:
                14,
            }}
          >
            <div
              style={{
                display:
                  "flex",
                alignItems:
                  "center",
                justifyContent:
                  "space-between",
              }}
            >
              <div>
                <h2
                  className="f-display"
                  style={{
                    margin: 0,
                    fontSize: 15,
                    color:
                      T.ink,
                  }}
                >
                  Contractor rating
                </h2>

                <div
                  className="f-body"
                  style={{
                    marginTop: 4,
                    fontSize: 10.5,
                    color:
                      T.ink60,
                  }}
                >
                  Based on
                  ImbaLink
                  recommendations
                </div>
              </div>

              <div
                style={{
                  display:
                    "flex",
                  alignItems:
                    "center",
                  gap: 5,
                }}
              >
                <Star
                  size={18}
                  fill={T.ochre}
                  color={
                    T.ochre
                  }
                />

                <span
                  className="f-display font-bold"
                  style={{
                    fontSize: 20,
                    color:
                      T.ink,
                  }}
                >
                  {displayedRating.toFixed(
                    1
                  )}
                </span>
              </div>
            </div>
          </section>

          {/* Contact */}
          <section
            style={{
              background:
                T.paper,
              border:
                `1px solid ${T.line}`,
              borderRadius: 20,
              padding:
                "18px",
              marginBottom:
                20,
            }}
          >
            <h2
              className="f-display"
              style={{
                margin: 0,
                fontSize: 15,
                color:
                  T.ink,
              }}
            >
              Contact
            </h2>

            <div
              className="f-body"
              style={{
                marginTop: 8,
                fontSize: 12,
                color:
                  T.ink60,
              }}
            >
              {contractor.phone ||
                "Phone number not available"}
            </div>
          </section>

          {/* Action buttons */}
          <div
            style={{
              display:
                "grid",
              gridTemplateColumns:
                contractor.phone
                  ? "1fr 1fr"
                  : "1fr",
              gap: 10,
              position:
                "sticky",
              bottom: 12,
              zIndex: 5,
            }}
          >
            {contractor.phone && (
              <a
                href={`tel:${contractor.phone}`}
                className="flex items-center justify-center gap-2 rounded-full f-body font-semibold"
                style={{
                  minHeight: 50,
                  background:
                    T.ink,
                  color:
                    T.paper,
                  textDecoration:
                    "none",
                  fontSize: 12,
                  boxShadow:
                    "0 6px 20px rgba(0,0,0,0.18)",
                }}
              >
                <Phone
                  size={16}
                />
                Call contractor
              </a>
            )}

            <button
              onClick={() =>
                handleRequestQuote(
                  contractor
                )
              }
              className="flex items-center justify-center gap-2 rounded-full f-body font-semibold active:scale-[0.98]"
              style={{
                minHeight: 50,
                background:
                  T.jacaranda,
                color:
                  T.paper,
                border: "none",
                cursor:
                  "pointer",
                fontSize: 12,
                boxShadow:
                  "0 6px 20px rgba(108,56,255,0.25)",
              }}
            >
              <MessageCircle
                size={16}
              />
              Request a quote
            </button>
          </div>
        </div>
      </div>
    );
  }

  /*
   * ------------------------------------------------------------
   * CONTRACTOR LIST VIEW
   * ------------------------------------------------------------
   */

  return (
    <div
      className="pb-8 web-page"
      style={{
        minHeight: "100vh",
        background: T.paperDim,
      }}
    >
      {/* Sticky header */}
      <div
        className="web-hero web-sticky-header"
        style={{
          position: "sticky",
          top: 0,
          zIndex: 10,
          width: "100%",
          paddingTop:
            "env(safe-area-inset-top, 0px)",
        }}
      >
        <div
          style={{
            padding:
              "12px 16px 16px",
          }}
        >
          <div
            className="f-display font-bold"
            style={{
              color: T.paper,
              fontSize: 19,
            }}
          >
            Contractors
          </div>

          <div
            className="f-body"
            style={{
              color:
                "rgba(251,248,240,.62)",
              fontSize: 11.5,
              marginTop: 4,
            }}
          >
            Find trusted people for
            repairs, maintenance and
            property upgrades.
          </div>

          <button
            onClick={() =>
              setShowRegistration(
                true
              )
            }
            className="w-full rounded-2xl p-3 text-left"
            style={{
              background:
                T.paper,
              color: T.ink,
              border: "none",
              cursor:
                "pointer",
              marginTop: 12,
            }}
          >
            <div
              className="f-display font-semibold"
              style={{
                fontSize: 12.5,
              }}
            >
              {registration
                ? "Manage contractor registration"
                : "Register as a contractor"}
            </div>

            <div
              className="f-body"
              style={{
                fontSize: 10,
                color: T.ink60,
                marginTop: 2,
              }}
            >
              {registration
                ? `Application status: ${
                    registration.verificationStatus ||
                    "pending"
                  }`
                : "Create your contractor profile and submit it for verification."}
            </div>
          </button>
        </div>
      </div>

      {/* Content */}
      <div
        style={{
          background:
            T.paper,
          borderTopLeftRadius: 18,
          borderTopRightRadius: 18,
          minHeight: 600,
          overflow: "hidden",
        }}
      >
        {/* Search & filters */}
        <div
          className="px-4 pt-4"
          style={{
            background: T.paper,
          }}
        >
          <div
            className="flex items-center gap-2 h-10 px-3.5 rounded-full"
            style={{
              background:
                T.paperDim,
              border:
                `1px solid ${T.line}`,
            }}
          >
            <Search
              size={15}
              style={{
                color: T.ink60,
                flexShrink: 0,
              }}
            />

            <input
              value={query}
              onChange={(event) =>
                setQuery(
                  event.target.value
                )
              }
              placeholder="Search contractors or services"
              aria-label="Search contractors"
              className="f-body bg-transparent outline-none flex-1"
              style={{
                color: T.ink,
                fontSize: 16,
                minWidth: 0,
              }}
            />
          </div>

          <div
            className="flex gap-1.5 mt-3 overflow-x-auto noscroll pb-1"
            style={{
              scrollbarWidth:
                "none",
            }}
          >
            {categories.map(
              (item) => (
                <button
                  key={item}
                  onClick={() =>
                    setCategory(
                      item
                    )
                  }
                  className="f-body font-medium px-3 py-1.5 rounded-full whitespace-nowrap active:scale-95"
                  style={{
                    background:
                      category ===
                      item
                        ? T.jacaranda
                        : T.paperDim,
                    color:
                      category ===
                      item
                        ? T.paper
                        : T.ink,
                    fontSize: 10.5,
                    border: "none",
                    cursor:
                      "pointer",
                  }}
                >
                  {item}
                </button>
              )
            )}
          </div>
        </div>

        {/* Contractor grid */}
        <div
          className="web-contractor-grid px-4 pt-4 grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3"
          style={{
            paddingBottom:
              24,
          }}
        >
          {results.map(
            (contractor) => {
              const contractorKey =
                String(
                  contractor.id
                );

              const isLiked =
                liked?.has(
                  contractorKey
                );

              const displayedRating =
                Math.min(
                  5,
                  Number(
                    contractor.rating ||
                      0
                  ) +
                    (isLiked
                      ? 0.1
                      : 0)
                );

              return (
                <div
                  key={
                    contractor.id
                  }
                  className="web-contractor-card rounded-2xl p-3.5"
                  onClick={() =>
                    openContractorProfile(
                      contractor
                    )
                  }
                  role="button"
                  tabIndex={0}
                  onKeyDown={(
                    event
                  ) => {
                    if (
                      event.key ===
                        "Enter" ||
                      event.key ===
                        " "
                    ) {
                      event.preventDefault();

                      openContractorProfile(
                        contractor
                      );
                    }
                  }}
                  style={{
                    background:
                      T.paperDim,
                    cursor:
                      "pointer",
                  }}
                >
                  <div
                    className="flex gap-3"
                  >
                    <div
                      className="w-12 h-12 rounded-2xl flex items-center justify-center shrink-0"
                      style={{
                        background:
                          T.ink,
                      }}
                    >
                      <Wrench
                        size={19}
                        color={
                          T.paper
                        }
                      />
                    </div>

                    <div
                      className="min-w-0 flex-1"
                    >
                      <div
                        className="flex items-center gap-1.5"
                      >
                        <div
                          className="f-body font-semibold truncate"
                          style={{
                            color:
                              T.ink,
                            fontSize: 13,
                          }}
                        >
                          {contractor.business ||
                            contractor.name ||
                            "Contractor"}
                        </div>

                        {contractor.verified && (
                          <ShieldCheck
                            size={
                              13
                            }
                            style={{
                              color:
                                T.msasa,
                              flexShrink: 0,
                            }}
                          />
                        )}
                      </div>

                      <div
                        className="f-body mt-0.5"
                        style={{
                          color:
                            T.ink60,
                          fontSize: 10.5,
                        }}
                      >
                        {contractor.name ||
                          "Contractor"}

                        {contractor.category
                          ? ` · ${contractor.category}`
                          : ""}
                      </div>

                      <div
                        className="flex items-center gap-3 mt-1.5 f-body"
                        style={{
                          color:
                            T.ink60,
                          fontSize: 10,
                        }}
                      >
                        <span className="flex items-center gap-1">
                          <MapPin
                            size={10}
                          />
                          {contractor.area ||
                            "Zimbabwe"}
                        </span>

                        <span className="flex items-center gap-1">
                          <Star
                            size={10}
                            fill={
                              T.ochre
                            }
                            style={{
                              color:
                                T.ochre,
                            }}
                          />

                          {displayedRating.toFixed(
                            1
                          )}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={(
                        event
                      ) => {
                        event.stopPropagation();

                        toggleLike(
                          contractor.id
                        );
                      }}
                      aria-label={
                        isLiked
                          ? "Unlike contractor"
                          : "Like contractor"
                      }
                      className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 active:scale-90"
                      style={{
                        background:
                          T.paper,
                        border:
                          "none",
                        cursor:
                          "pointer",
                      }}
                    >
                      <Heart
                        size={18}
                        color={
                          isLiked
                            ? T.brick
                            : T.ink
                        }
                        fill={
                          isLiked
                            ? T.brick
                            : "none"
                        }
                        strokeWidth={
                          1.8
                        }
                      />
                    </button>
                  </div>

                  <p
                    className="f-body leading-relaxed mt-3"
                    style={{
                      color:
                        T.ink60,
                      fontSize: 11.5,
                      display:
                        "-webkit-box",
                      WebkitLineClamp: 2,
                      WebkitBoxOrient:
                        "vertical",
                      overflow:
                        "hidden",
                    }}
                  >
                    {contractor.description ||
                      `Professional ${
                        contractor.category ||
                        "property"
                      } services.`}
                  </p>

                  <div
                    className="flex gap-2 mt-3"
                    onClick={(
                      event
                    ) =>
                      event.stopPropagation()
                    }
                  >
                    <a
                      href={
                        contractor.phone
                          ? `tel:${contractor.phone}`
                          : undefined
                      }
                      onClick={(
                        event
                      ) => {
                        if (
                          !contractor.phone
                        ) {
                          event.preventDefault();
                        }
                      }}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-full f-body font-semibold"
                      style={{
                        background:
                          T.ink,
                        color:
                          T.paper,
                        fontSize: 11.5,
                        textDecoration:
                          "none",
                        opacity:
                          contractor.phone
                            ? 1
                            : 0.5,
                      }}
                    >
                      <Phone
                        size={13}
                      />
                      Call
                    </a>

                    <button
                      onClick={() =>
                        handleRequestQuote(
                          contractor
                        )
                      }
                      className="flex-1 px-3 py-2.5 rounded-full f-body font-semibold"
                      style={{
                        background:
                          T.paper,
                        color:
                          T.ink,
                        border:
                          `1px solid ${T.line}`,
                        fontSize: 11.5,
                        cursor:
                          "pointer",
                      }}
                    >
                      Request quote
                    </button>
                  </div>
                </div>
              );
            }
          )}

          {results.length ===
            0 && (
            <div
              className="text-center py-14 f-body"
              style={{
                color:
                  T.ink60,
                fontSize: 12,
                gridColumn:
                  "1 / -1",
              }}
            >
              <Wrench
                size={38}
                style={{
                  opacity: 0.2,
                  margin:
                    "0 auto 12px",
                }}
              />

              <div
                style={{
                  fontWeight: 500,
                  color:
                    T.ink,
                }}
              >
                No contractors
                found
              </div>

              <div
                style={{
                  marginTop: 4,
                  opacity: 0.7,
                }}
              >
                Try a different
                search or
                category.
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Registration modal */}
      {showRegistration && (
        <ContractorRegistration
          profile={profile}
          onClose={() =>
            setShowRegistration(
              false
            )
          }
          onSubmit={async (data) => {
            try {
              await onRegister?.(
                data
              );
              setShowRegistration(
                false
              );
            } catch (error) {
              console.error(
                "Contractor registration failed:",
                error
              );
            }
          }}
        />
      )}
    </div>
  );
}