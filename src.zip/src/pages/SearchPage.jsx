import {
  Search,
  SlidersHorizontal,
  ShieldCheck,
  X,
  ChevronDown,
  ArrowUpDown,
  Check,
  RotateCcw,
} from "lucide-react";
import { useRef, useState, useLayoutEffect, useEffect, useMemo } from "react";
import { T } from "../styles/tokens";
import GridTile from "../components/property/GridTile";
import PostCard from "../components/property/PostCard";
import ToggleSwitch from "../components/common/ToggleSwitch";

const HEADER_TRANSITION_MS = 320;

const BEDS_OPTIONS = ["Any", "1", "2", "3", "4", "5+"];

const SORT_OPTIONS = [
  { key: "newest", label: "Newest" },
  { key: "price_asc", label: "Price: Low to High" },
  { key: "price_desc", label: "Price: High to Low" },
];

function FilterPill({ label, active, onClick, icon: Icon = ChevronDown, emoji }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="f-body font-medium px-3 py-1.5 rounded-full whitespace-nowrap shrink-0 active:scale-95 flex items-center gap-1"
      style={{
        background: active ? T.jacaranda : T.paperDim,
        color: active ? T.paper : T.ink,
        fontSize: 11.5,
        border: `1px solid ${active ? T.jacaranda : T.line}`,
        cursor: "pointer",
      }}
    >
      {label}
      {emoji ? (
        <span
          style={{
            fontSize: 11,
            lineHeight: 1,
            display: "inline-flex",
            transform: "translateY(0.5px)",
          }}
        >
          {emoji}
        </span>
      ) : (
        <Icon size={12} style={{ opacity: 0.7 }} />
      )}
    </button>
  );
}


function useMediaQuery(query) {
  const [matches, setMatches] = useState(() =>
    typeof window !== "undefined" && window.matchMedia(query).matches
  );

  useEffect(() => {
    const media = window.matchMedia(query);
    const update = () => setMatches(media.matches);
    update();
    media.addEventListener?.("change", update);
    return () => media.removeEventListener?.("change", update);
  }, [query]);

  return matches;
}

export default function SearchPage({
  properties,
  query,
  setQuery,
  filters,
  setFilters,
  setShowFilters,
  results,
  openProperty,
  city,
  isActive = true,
  liked,
  saved,
  toggleLike,
  toggleSave,
  onOpenLister,
  viewingRequested,
  onRequestViewing,
  onSend,
  onOpenMessage,
}) {
  const isTabletOrDesktop = useMediaQuery("(min-width: 768px)");
  const isDesktopLayout = useMediaQuery("(min-width: 1024px)");
  const pageRef = useRef(null);
  const headerRef = useRef(null);
  const dropdownRef = useRef(null);
  const savedScrollRef = useRef(0);
  const [headerHeight, setHeaderHeight] = useState(108);
  const [leaving, setLeaving] = useState(false);
  const [activeCard, setActiveCard] = useState(null);
  const [openDropdown, setOpenDropdown] = useState(null);
  const [sort, setSort] = useState("newest");
  const [randomSeed, setRandomSeed] = useState(0); // new: triggers random shuffle

  useLayoutEffect(() => {
    const el = headerRef.current;
    if (!el) return;
    const update = () => setHeaderHeight(el.offsetHeight);
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  useLayoutEffect(() => {
    if (isActive) setLeaving(false);
  }, [isActive]);

  useEffect(() => {
    if (!openDropdown) return;
    const handlePointerDown = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setOpenDropdown(null);
      }
    };
    document.addEventListener("mousedown", handlePointerDown);
    document.addEventListener("touchstart", handlePointerDown);
    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
      document.removeEventListener("touchstart", handlePointerDown);
    };
  }, [openDropdown]);

  const handleOpenProperty = (property) => {
    setActiveCard(null);
    setLeaving(true);
    window.setTimeout(() => openProperty(property), HEADER_TRANSITION_MS);
  };

  const propertyTypes = [
    "All",
    ...Array.from(
      new Set(
        (city === "All" ? properties : properties.filter((p) => p.city === city))
          .map((p) => p.type)
          .filter(Boolean)
      )
    ),
  ];

  const priceCeiling = useMemo(() => {
    const max = Math.max(1000, ...properties.map((p) => Number(p.price) || 0));
    return Math.ceil(max / 100) * 100;
  }, [properties]);

  const activeFilterCount =
    (filters.type !== "All" ? 1 : 0) +
    (filters.beds && filters.beds !== "Any" ? 1 : 0) +
    (filters.maxPrice < priceCeiling ? 1 : 0) +
    (filters.suburb !== "All" ? 1 : 0) +
    (filters.verifiedOnly ? 1 : 0);

  const isAnyFilterActive = activeFilterCount > 0;

  // Compute sorted results
  const sortedResults = useMemo(() => {
    // If randomSeed > 0 and no filters and default sort, shuffle results
    if (
      randomSeed > 0 &&
      !isAnyFilterActive &&
      sort === "newest"
    ) {
      const shuffled = [...results];
      for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
      }
      return shuffled;
    }

    // Otherwise apply normal sorting
    if (sort === "price_asc") {
      return [...results].sort(
        (a, b) => (Number(a.price) || 0) - (Number(b.price) || 0)
      );
    }
    if (sort === "price_desc") {
      return [...results].sort(
        (a, b) => (Number(b.price) || 0) - (Number(a.price) || 0)
      );
    }
    return results;
  }, [results, sort, randomSeed, isAnyFilterActive]);

  const searchPlaceholder = useMemo(() => {
    if (filters.suburb !== "All") return `Search in ${filters.suburb}`;
    if (city !== "All") return `Search in ${city}`;
    return "Search suburb, type, landlord";
  }, [filters.suburb, city]);

  const clearAll = () => {
    // If no filters active and sort is default, randomise instead of reset
    if (!isAnyFilterActive && sort === "newest") {
      setRandomSeed((s) => s + 1); // trigger a new shuffle
      return;
    }

    // Normal reset
    setFilters((f) => ({
      ...f,
      suburb: "All",
      type: "All",
      beds: "Any",
      maxPrice: priceCeiling,
      verifiedOnly: false,
      active: false,
    }));
    setSort("newest");
    setQuery("");
    setOpenDropdown(null);
    setRandomSeed(0); // clear any random seed
    if (savedScrollRef.current) {
      window.scrollTo({ top: savedScrollRef.current, behavior: "smooth" });
      savedScrollRef.current = 0;
    }
  };

  const toggleDropdown = (key) => setOpenDropdown((cur) => (cur === key ? null : key));

  const handleSuburbClick = (suburb) => {
    savedScrollRef.current = window.scrollY || document.querySelector(".app-main-shell")?.scrollTop || 0;
    setFilters((f) => ({
      ...f,
      suburb: f.suburb === suburb ? "All" : suburb,
      active: true,
    }));
    setActiveCard(null);
    setOpenDropdown(null);
    setRandomSeed(0); // any filter change cancels random order
  };

  return (
    <div ref={pageRef} className="pb-8 web-page search-page" style={{ position: "relative" }}>
      <div
        ref={headerRef}
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          zIndex: 100,
          background: T.paper,
          transform: leaving ? "translateY(-100%)" : "translateY(0)",
          transition: `transform ${HEADER_TRANSITION_MS}ms cubic-bezier(0.22, 1, 0.36, 1)`,
          willChange: "transform",
        }}
      >
        <div className="px-4" style={{ paddingTop: "max(12px, env(safe-area-inset-top, 0px))", paddingBottom: 10 }}>
          <div className="flex items-center gap-2">
            <div
              className="flex-1 flex items-center gap-2 h-10 px-3.5 rounded-full"
              style={{ background: T.paperDim, border: `1px solid ${T.line}`, minWidth: 0 }}
            >
              <Search size={15} style={{ color: T.ink60, flexShrink: 0 }} />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={searchPlaceholder}
                className="f-body bg-transparent outline-none flex-1"
                style={{ color: T.ink, fontSize: 14, minWidth: 0 }}
              />
              {query && (
                <button
                  type="button"
                  onClick={() => setQuery("")}
                  aria-label="Clear search"
                  style={{
                    border: "none",
                    background: "transparent",
                    padding: 3,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                    flexShrink: 0,
                  }}
                >
                  <X size={14} color={T.ink60} />
                </button>
              )}
            </div>

            <button
              type="button"
              onClick={() => setShowFilters(true)}
              aria-label="Open filters"
              className="active:scale-90"
              style={{
                width: 40,
                height: 40,
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0,
                background: isAnyFilterActive ? T.jacaranda : T.ink,
                border: "none",
                cursor: "pointer",
                transition: "transform 0.15s ease",
              }}
            >
              <SlidersHorizontal size={16} color={isAnyFilterActive ? T.paper : T.paper} />
            </button>
          </div>

          <div ref={dropdownRef} style={{ position: "relative", marginTop: 8 }}>
            <div className="flex items-center gap-1.5 overflow-x-auto noscroll" style={{ paddingBottom: 2, scrollbarWidth: "none", WebkitOverflowScrolling: "touch" }}>
              <FilterPill label="Type" active={filters.type !== "All"} onClick={() => toggleDropdown("type")} />
              <FilterPill label="Beds" active={!!filters.beds && filters.beds !== "Any"} onClick={() => toggleDropdown("beds")} />
              <FilterPill label="Price" active={filters.maxPrice < priceCeiling} onClick={() => toggleDropdown("price")} />

              <button
                type="button"
                onClick={clearAll}
                aria-label="Reset filters"
                className="active:scale-95 flex items-center justify-center shrink-0"
                style={{
                  width: 28,
                  height: 28,
                  borderRadius: "50%",
                  background: isAnyFilterActive ? T.jacaranda : T.paperDim,
                  border: `1px solid ${isAnyFilterActive ? T.jacaranda : T.line}`,
                  cursor: "pointer",
                }}
              >
                <RotateCcw size={13} color={isAnyFilterActive ? T.paper : T.ink} />
              </button>

              <button
                type="button"
                onClick={() => toggleDropdown("sort")}
                aria-label="Sort"
                className="active:scale-95 flex items-center justify-center shrink-0"
                style={{
                  width: 28,
                  height: 28,
                  borderRadius: "50%",
                  marginLeft: "auto",
                  background: sort !== "newest" ? T.jacaranda : T.paperDim,
                  border: `1px solid ${sort !== "newest" ? T.jacaranda : T.line}`,
                  cursor: "pointer",
                }}
              >
                <ArrowUpDown size={13} color={sort !== "newest" ? T.paper : T.ink} />
              </button>
            </div>

            {openDropdown === "type" && (
              <div className="fade" style={{ position: "absolute", top: "calc(100% + 6px)", left: 0, zIndex: 20, background: T.paper, border: `1px solid ${T.line}`, borderRadius: 14, padding: 6, minWidth: 160, boxShadow: "0 8px 24px rgba(0,0,0,0.12)" }}>
                {propertyTypes.map((t) => {
                  const selected = filters.type === t;
                  return (
                    <button key={t} type="button" onClick={() => { setFilters((f) => ({ ...f, type: t })); setOpenDropdown(null); setRandomSeed(0); }} className="f-body w-full flex items-center justify-between px-3 py-2 rounded-lg" style={{ background: selected ? T.paperDim : "transparent", color: T.ink, fontSize: 12.5, border: "none", textAlign: "left", cursor: "pointer" }}>
                      {t}
                      {selected && <Check size={13} color={T.jacaranda} />}
                    </button>
                  );
                })}
              </div>
            )}

            {openDropdown === "beds" && (
              <div className="fade" style={{ position: "absolute", top: "calc(100% + 6px)", left: 0, zIndex: 20, background: T.paper, border: `1px solid ${T.line}`, borderRadius: 14, padding: 6, minWidth: 140, boxShadow: "0 8px 24px rgba(0,0,0,0.12)" }}>
                {BEDS_OPTIONS.map((b) => {
                  const selected = (filters.beds || "Any") === b;
                  return (
                    <button key={b} type="button" onClick={() => { setFilters((f) => ({ ...f, beds: b })); setOpenDropdown(null); setRandomSeed(0); }} className="f-body w-full flex items-center justify-between px-3 py-2 rounded-lg" style={{ background: selected ? T.paperDim : "transparent", color: T.ink, fontSize: 12.5, border: "none", textAlign: "left", cursor: "pointer" }}>
                      {b === "Any" ? "Any beds" : `${b} bed${b === "1" ? "" : "s"}+`}
                      {selected && <Check size={13} color={T.jacaranda} />}
                    </button>
                  );
                })}
              </div>
            )}

            {openDropdown === "price" && (
              <div className="fade" style={{ position: "absolute", top: "calc(100% + 6px)", left: 0, right: 0, zIndex: 20, background: T.paper, border: `1px solid ${T.line}`, borderRadius: 14, padding: 14, boxShadow: "0 8px 24px rgba(0,0,0,0.12)" }}>
                <div className="f-body flex items-center justify-between" style={{ fontSize: 12, color: T.ink60 }}>
                  <span>Max price</span>
                  <span className="font-semibold" style={{ color: T.ink }}>${filters.maxPrice}/mo</span>
                </div>
                <input type="range" min={0} max={priceCeiling} step={10} value={filters.maxPrice} onChange={(e) => { setFilters((f) => ({ ...f, maxPrice: Number(e.target.value) })); setRandomSeed(0); }} style={{ width: "100%", marginTop: 8 }} />
                <button type="button" onClick={() => setOpenDropdown(null)} className="f-body font-semibold w-full mt-2 py-2 rounded-full" style={{ background: T.jacaranda, color: T.paper, fontSize: 12, border: "none", cursor: "pointer" }}>Apply</button>
              </div>
            )}

            {openDropdown === "sort" && (
              <div className="fade" style={{ position: "absolute", top: "calc(100% + 6px)", right: 0, zIndex: 20, background: T.paper, border: `1px solid ${T.line}`, borderRadius: 14, padding: 6, minWidth: 190, boxShadow: "0 8px 24px rgba(0,0,0,0.12)" }}>
                {SORT_OPTIONS.map((opt) => {
                  const selected = sort === opt.key;
                  return (
                    <button key={opt.key} type="button" onClick={() => { setSort(opt.key); setOpenDropdown(null); setRandomSeed(0); }} className="f-body w-full flex items-center justify-between px-3 py-2 rounded-lg" style={{ background: selected ? T.paperDim : "transparent", color: T.ink, fontSize: 12.5, border: "none", textAlign: "left", cursor: "pointer" }}>
                      {opt.label}
                      {selected && <Check size={13} color={T.jacaranda} />}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <div className="flex items-center justify-between" style={{ marginTop: 8 }}>
            <span className="f-body" style={{ color: T.ink60, fontSize: 11.5 }}>
              {sortedResults.length} results
              {activeFilterCount > 0 && (
                <>
                  {" "}·{" "}
                  <span className="font-semibold" style={{ color: T.ink }}>
                    {activeFilterCount} filter{activeFilterCount === 1 ? "" : "s"}
                  </span>
                </>
              )}
            </span>
            <div className="flex items-center gap-1.5">
              <ShieldCheck size={12} style={{ color: filters.verifiedOnly ? T.msasa : T.ink60 }} />
              <span className="f-body font-medium" style={{ color: filters.verifiedOnly ? T.msasa : T.ink60, fontSize: 11 }}>Verified only</span>
              <ToggleSwitch on={filters.verifiedOnly} onToggle={() => { setFilters((f) => ({ ...f, verifiedOnly: !f.verifiedOnly })); setRandomSeed(0); }} />
            </div>
          </div>
        </div>
      </div>

      <div className="web-search-content" style={{ paddingTop: `calc(${headerHeight}px + env(safe-area-inset-top, 0px))`, background: T.paper, minHeight: 500 }}>
        {sortedResults.length === 0 ? (
          <div className="fade text-center py-14 px-6" style={{ minHeight: 300 }}>
            <div className="f-body" style={{ color: T.ink60, fontSize: 13 }}>No matches — try adjusting your filters or search.</div>
            <button type="button" onClick={clearAll} className="f-body font-semibold mt-3 px-4 py-2 rounded-full" style={{ background: T.paperDim, color: T.ink, fontSize: 12, border: "none", cursor: "pointer" }}>Clear filters</button>
          </div>
        ) : (
          <div className="web-search-grid px-4" style={{ paddingTop: 8 }} role="list">
            {sortedResults.map((property, index) => (
              <div key={property.id}>
                {isTabletOrDesktop ? (
                  <PostCard
                    p={property}
                    index={index}
                    liked={liked?.has ? liked.has(String(property.id)) : false}
                    saved={saved?.has ? saved.has(String(property.id)) : false}
                    onToggleLike={toggleLike}
                    onToggleSave={toggleSave}
                    onOpen={handleOpenProperty}
                    onOpenLister={onOpenLister}
                    viewingRequested={!!viewingRequested?.[property.id]}
                    onRequestViewing={() => onRequestViewing?.(property.id)}
                    onSend={onSend}
                    onOpenMessage={onOpenMessage}
                    showDistance={false}
                    compactDesktop={isDesktopLayout}
                  />
                ) : (
                  <GridTile
                    p={property}
                    onOpen={setActiveCard}
                    onSuburbClick={handleSuburbClick}
                    activeSuburb={filters.suburb}
                  />
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {activeCard && (
        <PostCard
          key={activeCard.id}
          p={activeCard}
          index={0}
          liked={liked?.has ? liked.has(String(activeCard.id)) : false}
          saved={saved?.has ? saved.has(String(activeCard.id)) : false}
          onToggleLike={toggleLike}
          onToggleSave={toggleSave}
          onOpen={handleOpenProperty}
          onOpenLister={onOpenLister}
          viewingRequested={!!viewingRequested?.[activeCard.id]}
          onRequestViewing={() => onRequestViewing?.(activeCard.id)}
          onSend={onSend}
          onOpenMessage={onOpenMessage}
          showDistance={false}
          hideCard
          autoOpen
          scrollLockElement={pageRef.current}
          onSheetClose={() => setActiveCard(null)}
        />
      )}
    </div>
  );
}