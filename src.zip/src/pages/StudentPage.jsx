import React, { useMemo, useState } from "react";
import {
  ArrowRight,
  BadgeCheck,
  BedDouble,
  Bus,
  CalendarDays,
  Check,
  ChevronDown,
  GraduationCap,
  Heart,
  Home,
  MapPin,
  MessageCircle,
  Plus,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Users,
  Wifi,
  X,
} from "lucide-react";
import { T } from "../styles/tokens";

const UNIVERSITIES = [
  "University of Zimbabwe",
  "Harare Institute of Technology",
  "Midlands State University",
  "National University of Science and Technology",
  "Chinhoyi University of Technology",
  "Great Zimbabwe University",
  "Africa University",
  "Women's University in Africa",
];

const AREAS = ["Any area", "Mt Pleasant", "Avondale", "Belgravia", "Ardbennie", "Kuwadzana", "CBD"];

const ROOMMATES = [
  { id: 1, name: "Tadiwa", university: "University of Zimbabwe", area: "Mt Pleasant", budget: "$180–$220", looking: "1 roommate", verified: true },
  { id: 2, name: "Nyasha", university: "Harare Institute of Technology", area: "Avondale", budget: "$150–$200", looking: "2 roommates", verified: true },
  { id: 3, name: "Rudo", university: "University of Zimbabwe", area: "Belgravia", budget: "$200–$250", looking: "1 roommate", verified: false },
];

const fallbackHomes = [
  { id: "student-demo-1", title: "Student-friendly 2 bedroom apartment", rent: 400, city: "Harare", suburb: "Mt Pleasant", beds: 2, type: "Apartment", amenities: ["wifi", "water", "security"], studentFriendly: true, shareable: true, distance: "1.3 km from UZ" },
  { id: "student-demo-2", title: "Affordable room near campus", rent: 180, city: "Harare", suburb: "Avondale", beds: 1, type: "Room", amenities: ["water", "security"], studentFriendly: true, shareable: false, distance: "2.1 km from UZ" },
  { id: "student-demo-3", title: "Furnished student cottage", rent: 320, city: "Harare", suburb: "Belgravia", beds: 2, type: "Cottage", amenities: ["wifi", "parking"], studentFriendly: true, shareable: true, distance: "2.4 km from UZ" },
];

function formatRent(value) {
  const n = Number(value);
  return Number.isFinite(n) ? `$${n.toLocaleString()}/month` : "Price on request";
}

function StudentHomeCard({ property, onOpen, onShare, liked, saved, toggleLike, toggleSave }) {
  const rent = Number(property?.rent);
  const shareCost = Number.isFinite(rent) && property?.beds > 1 ? Math.round(rent / Number(property.beds)) : null;

  return (
    <article className="student-home-card">
      <div className="student-home-visual">
        <div className="student-home-placeholder">
          <Home size={30} strokeWidth={1.5} />
        </div>
        <div className="student-home-badges">
          {property?.studentFriendly !== false && <span><GraduationCap size={11} /> Student friendly</span>}
          {property?.shareable && <span><Users size={11} /> Shareable</span>}
        </div>
        <button type="button" className={`student-round-action ${liked ? "is-liked" : ""}`} onClick={() => toggleLike?.(property.id)} aria-label="Like property">
          <Heart size={16} fill={liked ? "currentColor" : "none"} />
        </button>
      </div>
      <div className="student-home-body">
        <div className="student-card-topline">
          <span>{property?.type || "Property"}</span>
          <button type="button" onClick={() => toggleSave?.(property.id)} className={`student-save ${saved ? "is-saved" : ""}`}>
            {saved ? "Saved" : "Save"}
          </button>
        </div>
        <h3>{property?.title || "Student accommodation"}</h3>
        <p className="student-muted"><MapPin size={13} /> {property?.suburb || property?.city || "Harare"} · {property?.distance || "Near campus"}</p>
        <div className="student-home-price">
          <strong>{formatRent(property?.rent)}</strong>
          {shareCost && <small>≈ ${shareCost}/person if shared</small>}
        </div>
        <div className="student-mini-features">
          {property?.beds && <span><BedDouble size={13} /> {property.beds} beds</span>}
          {(property?.amenities || []).some((a) => String(a).toLowerCase().includes("wifi")) && <span><Wifi size={13} /> Wi-Fi</span>}
          <span><ShieldCheck size={13} /> Safety info</span>
        </div>
        <div className="student-card-actions">
          <button type="button" className="student-primary-btn" onClick={() => onOpen?.(property)}>View home <ArrowRight size={14} /></button>
          {property?.shareable && <button type="button" className="student-secondary-btn" onClick={() => onShare?.(property)}><Users size={14} /> Share</button>}
        </div>
      </div>
    </article>
  );
}

export default function StudentPage({
  properties = [],
  liked,
  saved,
  toggleLike,
  toggleSave,
  openProperty,
  setTab,
  user,
}) {
  const [university, setUniversity] = useState(UNIVERSITIES[0]);
  const [area, setArea] = useState("Any area");
  const [studentView, setStudentView] = useState("homes");
  const [showUniversity, setShowUniversity] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [shareProperty, setShareProperty] = useState(null);
  const [interested, setInterested] = useState(new Set());

  const homes = useMemo(() => {
    const source = Array.isArray(properties) ? properties : [];
    const relevant = source
      .filter((p) => p && (!p.studentFriendly || p.studentFriendly === true || p.shareable))
      .filter((p) => area === "Any area" || String(p.suburb || "").toLowerCase() === area.toLowerCase())
      .slice(0, 6);

    return relevant.length ? relevant : fallbackHomes.filter((p) => area === "Any area" || p.suburb === area);
  }, [properties, area]);

  const openShare = (property) => {
    setShareProperty(property);
    setShowShareModal(true);
  };

  const toggleInterested = (id) => {
    setInterested((current) => {
      const next = new Set(current);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  return (
    <main className="student-page">
      <style>{`
        .student-page{min-height:100%;background:#FBF8F0;color:${T.ink};padding-bottom:80px}
        .student-container{max-width:1180px;margin:0 auto;padding:0 28px}
        .student-hero{position:relative;overflow:hidden;background:${T.ink};color:${T.paper};border-radius:0 0 28px 28px;padding:48px 28px 34px}
        .student-hero-inner{max-width:1180px;margin:0 auto;display:grid;grid-template-columns:minmax(0,1.35fr) minmax(280px,.65fr);gap:36px;align-items:end}
        .student-eyebrow{display:inline-flex;align-items:center;gap:7px;font-size:11px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#D9C4A1;margin-bottom:14px}
        .student-hero h1{font-size:clamp(34px,4vw,56px);line-height:1.02;letter-spacing:-.045em;margin:0 0 14px;max-width:700px}
        .student-hero p{margin:0;color:rgba(251,248,240,.68);font-size:15px;line-height:1.6;max-width:600px}
        .student-hero-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:24px}
        .student-hero-btn{border:0;border-radius:12px;padding:13px 16px;font-weight:700;display:inline-flex;align-items:center;gap:8px;cursor:pointer}
        .student-hero-btn.primary{background:#F1EBDB;color:${T.ink}}
        .student-hero-btn.ghost{background:rgba(255,255,255,.08);color:${T.paper};border:1px solid rgba(255,255,255,.12)}
        .student-campus-card{background:rgba(251,248,240,.07);border:1px solid rgba(251,248,240,.13);border-radius:18px;padding:16px}
        .student-campus-label{font-size:10px;text-transform:uppercase;letter-spacing:.08em;color:rgba(251,248,240,.5);font-weight:700;margin-bottom:8px}
        .student-select{position:relative}
        .student-select button{width:100%;display:flex;align-items:center;justify-content:space-between;gap:10px;background:#fff;border:0;border-radius:11px;padding:12px;color:${T.ink};font-weight:650;text-align:left;cursor:pointer}
        .student-select-menu{position:absolute;top:calc(100% + 7px);left:0;right:0;z-index:30;background:#fff;border-radius:12px;padding:6px;box-shadow:0 18px 45px rgba(0,0,0,.25)}
        .student-select-menu button{padding:10px;border-radius:8px;background:transparent;font-size:12px}
        .student-select-menu button:hover{background:#F3F0E8}
        .student-section{padding:30px 0 0}
        .student-section-head{display:flex;align-items:end;justify-content:space-between;gap:20px;margin-bottom:16px}
        .student-section-head h2{font-size:22px;letter-spacing:-.025em;margin:0}
        .student-section-head p{font-size:12px;color:rgba(20,32,26,.58);margin:5px 0 0}
        .student-link-btn{border:0;background:none;font-weight:700;font-size:12px;color:#356D50;cursor:pointer;display:inline-flex;align-items:center;gap:5px}
        .student-filters{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px}
        .student-filter{display:inline-flex;align-items:center;gap:7px;background:#fff;border:1px solid rgba(20,32,26,.1);border-radius:10px;padding:9px 11px;font-size:12px;color:${T.ink};font-weight:600}
        .student-filter select{border:0;background:transparent;outline:0;font:inherit;color:inherit}
        .student-homes-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}
        .student-home-card{background:#fff;border:1px solid rgba(20,32,26,.09);border-radius:18px;overflow:hidden;box-shadow:0 6px 22px rgba(20,32,26,.035)}
        .student-home-visual{height:190px;background:#E9E4D8;position:relative;overflow:hidden}
        .student-home-placeholder{height:100%;display:flex;align-items:center;justify-content:center;color:rgba(20,32,26,.24)}
        .student-home-badges{position:absolute;left:11px;top:11px;display:flex;gap:5px;flex-wrap:wrap}
        .student-home-badges span{display:inline-flex;align-items:center;gap:4px;background:rgba(251,248,240,.94);padding:6px 8px;border-radius:7px;font-size:9px;font-weight:750}
        .student-round-action{position:absolute;right:10px;top:10px;width:34px;height:34px;border:0;border-radius:50%;background:rgba(251,248,240,.94);display:grid;place-items:center;color:${T.ink};cursor:pointer}
        .student-round-action.is-liked{color:#7A3040}
        .student-home-body{padding:15px}
        .student-card-topline{display:flex;align-items:center;justify-content:space-between;font-size:10px;color:rgba(20,32,26,.5);text-transform:uppercase;font-weight:700;letter-spacing:.05em}
        .student-home-body h3{font-size:16px;line-height:1.2;margin:7px 0}
        .student-muted{display:flex;align-items:center;gap:5px;color:rgba(20,32,26,.58);font-size:11px;margin:0}
        .student-save{border:0;background:none;color:#356D50;font-size:10px;font-weight:700;cursor:pointer}
        .student-save.is-saved{color:${T.ink}}
        .student-home-price{display:flex;align-items:baseline;justify-content:space-between;gap:8px;margin:14px 0 9px}
        .student-home-price strong{font-size:15px}
        .student-home-price small{font-size:9px;color:rgba(20,32,26,.5);text-align:right}
        .student-mini-features{display:flex;gap:8px;flex-wrap:wrap;color:rgba(20,32,26,.58);font-size:9px}
        .student-mini-features span{display:inline-flex;align-items:center;gap:4px}
        .student-card-actions{display:flex;gap:7px;margin-top:14px}
        .student-primary-btn,.student-secondary-btn{flex:1;border-radius:9px;padding:9px 10px;font-size:10px;font-weight:750;display:inline-flex;align-items:center;justify-content:center;gap:5px;cursor:pointer}
        .student-primary-btn{background:${T.ink};color:${T.paper};border:1px solid ${T.ink}}
        .student-secondary-btn{background:#fff;color:${T.ink};border:1px solid rgba(20,32,26,.12)}
        .student-share-banner{background:#E9EFE8;border:1px solid rgba(53,109,80,.15);border-radius:18px;padding:20px;display:flex;align-items:center;justify-content:space-between;gap:20px;margin-top:30px}
        .student-share-copy{display:flex;gap:12px;align-items:flex-start}
        .student-share-icon{width:40px;height:40px;border-radius:11px;background:#D6E5D8;display:grid;place-items:center;color:#356D50;flex-shrink:0}
        .student-share-banner h3{margin:0 0 4px;font-size:16px}
        .student-share-banner p{margin:0;color:rgba(20,32,26,.58);font-size:11px;line-height:1.5}
        .student-share-cta{white-space:nowrap;background:${T.ink};color:${T.paper};border:0;border-radius:10px;padding:11px 13px;font-size:11px;font-weight:750;cursor:pointer}
        .student-tabs{display:flex;gap:5px;background:#EEEAE0;border-radius:11px;padding:4px;width:max-content}
        .student-tab{border:0;background:transparent;padding:8px 11px;border-radius:8px;font-size:11px;font-weight:700;color:rgba(20,32,26,.55);cursor:pointer}
        .student-tab.active{background:#fff;color:${T.ink};box-shadow:0 2px 8px rgba(20,32,26,.07)}
        .student-roommate-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}
        .student-roommate-card{background:#fff;border:1px solid rgba(20,32,26,.09);border-radius:16px;padding:16px}
        .student-person{display:flex;align-items:center;gap:10px}
        .student-avatar{width:42px;height:42px;border-radius:50%;background:#E9E4D8;display:grid;place-items:center;font-weight:800}
        .student-person h3{font-size:14px;margin:0 0 2px}
        .student-person p{font-size:10px;color:rgba(20,32,26,.55);margin:0}
        .student-roommate-meta{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin:14px 0}
        .student-meta-box{background:#F7F4EC;border-radius:9px;padding:9px}
        .student-meta-box small{display:block;color:rgba(20,32,26,.48);font-size:8px;margin-bottom:3px}
        .student-meta-box b{font-size:10px}
        .student-interest{width:100%;border:1px solid rgba(20,32,26,.12);background:#fff;border-radius:9px;padding:9px;font-size:10px;font-weight:750;cursor:pointer}
        .student-interest.active{background:${T.ink};color:${T.paper};border-color:${T.ink}}
        .student-how{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
        .student-step{background:#fff;border:1px solid rgba(20,32,26,.08);border-radius:14px;padding:15px}
        .student-step-num{font-size:10px;font-weight:800;color:#356D50;margin-bottom:12px}
        .student-step h3{font-size:12px;margin:0 0 5px}
        .student-step p{font-size:10px;line-height:1.5;color:rgba(20,32,26,.55);margin:0}
        .student-modal-backdrop{position:fixed;inset:0;z-index:100;background:rgba(8,15,11,.55);display:grid;place-items:center;padding:20px}
        .student-modal{background:#FBF8F0;width:min(500px,100%);border-radius:18px;padding:20px;box-shadow:0 24px 70px rgba(0,0,0,.3)}
        .student-modal-head{display:flex;justify-content:space-between;align-items:flex-start;gap:15px}
        .student-modal h2{font-size:20px;margin:0 0 5px}
        .student-modal p{font-size:11px;line-height:1.5;color:rgba(20,32,26,.58);margin:0}
        .student-close{border:0;background:#EDE8DC;width:32px;height:32px;border-radius:50%;display:grid;place-items:center;cursor:pointer}
        .student-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:18px}
        .student-form-field{display:flex;flex-direction:column;gap:5px}
        .student-form-field.full{grid-column:1/-1}
        .student-form-field label{font-size:9px;font-weight:750;color:rgba(20,32,26,.6)}
        .student-form-field input,.student-form-field select{border:1px solid rgba(20,32,26,.12);border-radius:9px;padding:10px;background:#fff;font-size:11px;outline:none}
        .student-form-submit{width:100%;margin-top:14px;border:0;background:${T.ink};color:${T.paper};border-radius:10px;padding:11px;font-weight:750;cursor:pointer}
        @media(max-width:900px){.student-hero-inner{grid-template-columns:1fr}.student-homes-grid,.student-roommate-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.student-how{grid-template-columns:repeat(2,1fr)}}
        @media(max-width:640px){.student-container{padding:0 15px}.student-hero{padding:28px 15px 24px;border-radius:0 0 20px 20px}.student-hero h1{font-size:34px}.student-hero p{font-size:13px}.student-hero-actions{display:grid;grid-template-columns:1fr}.student-hero-btn{justify-content:center}.student-campus-card{margin-top:2px}.student-section{padding-top:24px}.student-section-head{align-items:flex-start;flex-direction:column;gap:10px}.student-homes-grid,.student-roommate-grid,.student-how{grid-template-columns:1fr}.student-home-visual{height:180px}.student-share-banner{align-items:flex-start;flex-direction:column}.student-share-cta{width:100%}.student-tabs{width:100%}.student-tab{flex:1}.student-form-grid{grid-template-columns:1fr}.student-form-field.full{grid-column:auto}}
      `}</style>

      <section className="student-hero">
        <div className="student-hero-inner">
          <div>
            <div className="student-eyebrow"><GraduationCap size={14} /> ImbaLink Students</div>
            <h1>Find your student home. Find your people.</h1>
            <p>Student-friendly accommodation, shareable homes and people looking to rent together — built around the way students actually find housing.</p>
            <div className="student-hero-actions">
              <button type="button" className="student-hero-btn primary" onClick={() => { setStudentView("homes"); document.getElementById("student-homes")?.scrollIntoView({ behavior: "smooth" }); }}>
                <Search size={16} /> Find accommodation
              </button>
              <button type="button" className="student-hero-btn ghost" onClick={() => { setStudentView("roommates"); document.getElementById("student-roommates")?.scrollIntoView({ behavior: "smooth" }); }}>
                <Users size={16} /> Find someone to share with
              </button>
            </div>
          </div>

          <div className="student-campus-card">
            <div className="student-campus-label">Your university</div>
            <div className="student-select">
              <button type="button" onClick={() => setShowUniversity((v) => !v)}>
                <span><GraduationCap size={14} style={{ verticalAlign: "middle", marginRight: 6 }} />{university}</span>
                <ChevronDown size={15} />
              </button>
              {showUniversity && (
                <div className="student-select-menu">
                  {UNIVERSITIES.map((item) => (
                    <button key={item} type="button" onClick={() => { setUniversity(item); setShowUniversity(false); }}>
                      {item}{item === university && <Check size={13} />}
                    </button>
                  ))}
                </div>
              )}
            </div>
            <div style={{ marginTop: 10, color: "rgba(251,248,240,.55)", fontSize: 10 }}>
              We’ll prioritize homes and students relevant to your campus.
            </div>
          </div>
        </div>
      </section>

      <div className="student-container">
        <section id="student-homes" className="student-section">
          <div className="student-section-head">
            <div>
              <h2>Accommodation around your campus</h2>
              <p>Start with places students can actually use, share and afford.</p>
            </div>
            <button type="button" className="student-link-btn" onClick={() => setTab?.("search")}>Explore all listings <ArrowRight size={13} /></button>
          </div>

          <div className="student-filters">
            <div className="student-filter"><MapPin size={13} /><select value={area} onChange={(e) => setArea(e.target.value)} aria-label="Student area"><option>Any area</option>{AREAS.slice(1).map((item) => <option key={item}>{item}</option>)}</select></div>
            <div className="student-filter"><SlidersHorizontal size={13} /><span>Student-friendly</span></div>
            <div className="student-filter"><Users size={13} /><span>Shareable homes</span></div>
          </div>

          <div className="student-homes-grid">
            {homes.map((property) => (
              <StudentHomeCard
                key={property.id}
                property={property}
                onOpen={openProperty}
                onShare={openShare}
                liked={liked?.has?.(String(property.id))}
                saved={saved?.has?.(String(property.id))}
                toggleLike={toggleLike}
                toggleSave={toggleSave}
              />
            ))}
          </div>

          <div className="student-share-banner">
            <div className="student-share-copy">
              <div className="student-share-icon"><Users size={20} /></div>
              <div>
                <h3>Found a place but can't afford it alone?</h3>
                <p>Create a share request for that exact property. Other students can discover it, express interest and chat with you before you approach the landlord together.</p>
              </div>
            </div>
            <button type="button" className="student-share-cta" onClick={() => openShare(homes[0] || fallbackHomes[0])}><Plus size={14} style={{ verticalAlign: "middle", marginRight: 4 }} /> Create share request</button>
          </div>
        </section>

        <section id="student-roommates" className="student-section">
          <div className="student-section-head">
            <div>
              <h2>Students looking to rent together</h2>
              <p>Connect around budget, campus and preferred area — not random social profiles.</p>
            </div>
            <div className="student-tabs">
              <button type="button" className={`student-tab ${studentView === "homes" ? "active" : ""}`} onClick={() => setStudentView("homes")}>Homes</button>
              <button type="button" className={`student-tab ${studentView === "roommates" ? "active" : ""}`} onClick={() => setStudentView("roommates")}>Roommates</button>
            </div>
          </div>

          <div className="student-roommate-grid">
            {ROOMMATES.map((person) => (
              <article className="student-roommate-card" key={person.id}>
                <div className="student-person">
                  <div className="student-avatar">{person.name.charAt(0)}</div>
                  <div>
                    <h3>{person.name} {person.verified && <BadgeCheck size={12} style={{ verticalAlign: "middle" }} />}</h3>
                    <p>{person.university}</p>
                  </div>
                </div>
                <div className="student-roommate-meta">
                  <div className="student-meta-box"><small>Area</small><b>{person.area}</b></div>
                  <div className="student-meta-box"><small>Budget</small><b>{person.budget}</b></div>
                  <div className="student-meta-box"><small>Looking for</small><b>{person.looking}</b></div>
                  <div className="student-meta-box"><small>Status</small><b>{person.verified ? "Verified student" : "New member"}</b></div>
                </div>
                <button type="button" className={`student-interest ${interested.has(person.id) ? "active" : ""}`} onClick={() => toggleInterested(person.id)}>
                  {interested.has(person.id) ? <><Check size={13} /> Interest sent</> : <><MessageCircle size={13} /> I'm interested</>}
                </button>
              </article>
            ))}
          </div>
        </section>

        <section className="student-section">
          <div className="student-section-head">
            <div>
              <h2>How shared renting works</h2>
              <p>Turn “I like this place” into a joint rental plan.</p>
            </div>
          </div>
          <div className="student-how">
            {[
              ["01", "Find a home", "Browse student-friendly properties and see whether sharing is allowed."],
              ["02", "Find a roommate", "Create a request or respond to another student interested in the same home."],
              ["03", "Chat first", "Talk inside ImbaLink and make sure the arrangement works for both of you."],
              ["04", "Approach the landlord", "Create a rental group and send a joint request to the property's landlord."],
            ].map(([number, title, text]) => (
              <div className="student-step" key={number}>
                <div className="student-step-num">{number}</div>
                <h3>{title}</h3>
                <p>{text}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="student-section">
          <div className="student-share-banner" style={{ marginTop: 0 }}>
            <div className="student-share-copy">
              <div className="student-share-icon"><ShieldCheck size={20} /></div>
              <div>
                <h3>Built around trust</h3>
                <p>Keep roommate conversations inside ImbaLink, look for verified students where available, and use the property details before paying anyone.</p>
              </div>
            </div>
            <button type="button" className="student-share-cta" onClick={() => setTab?.("profile")}>Complete my profile <ArrowRight size={13} /></button>
          </div>
        </section>
      </div>

      {showShareModal && (
        <div className="student-modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && setShowShareModal(false)}>
          <div className="student-modal" role="dialog" aria-modal="true" aria-label="Create share request">
            <div className="student-modal-head">
              <div>
                <h2>Find someone to share</h2>
                <p>{shareProperty?.title || "This property"}{shareProperty?.rent ? ` · ${formatRent(shareProperty.rent)}` : ""}</p>
              </div>
              <button type="button" className="student-close" onClick={() => setShowShareModal(false)} aria-label="Close"><X size={15} /></button>
            </div>
            <div className="student-form-grid">
              <div className="student-form-field">
                <label>UNIVERSITY</label>
                <select defaultValue={university}><option>{university}</option></select>
              </div>
              <div className="student-form-field">
                <label>PEOPLE NEEDED</label>
                <select defaultValue="1"><option>1 roommate</option><option>2 roommates</option><option>3 roommates</option></select>
              </div>
              <div className="student-form-field">
                <label>YOUR BUDGET</label>
                <input defaultValue={shareProperty?.rent ? `$${Math.round(Number(shareProperty.rent) / Math.max(2, Number(shareProperty.beds) || 2))}` : "$200"} />
              </div>
              <div className="student-form-field">
                <label>MOVE-IN</label>
                <input type="date" />
              </div>
              <div className="student-form-field full">
                <label>WHAT ARE YOU LOOKING FOR?</label>
                <input placeholder="e.g. quiet, clean, another student, female roommate..." />
              </div>
            </div>
            <button type="button" className="student-form-submit" onClick={() => { setShowShareModal(false); alert("Your share request is ready to publish. Connect this action to your database when you enable student requests."); }}>
              Publish share request
            </button>
          </div>
        </div>
      )}
    </main>
  );
}
